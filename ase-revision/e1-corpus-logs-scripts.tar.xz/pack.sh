#!/bin/bash
# Archive what is already finished, on node-local disk, leaving batch 2's output untouched.
set -e
OUT=/tmp/rba2-e1/archive
mkdir -p $OUT
cd /tmp/rba2-e1/campaigns
tar -cf - $(ls -d *_gpt4.1mini_rep*) | xz -T16 -3 > $OUT/e1-batch1-campaigns-gpt4.1mini.tar.xz
cd ~/e1
tar -cf - seeds | xz -T16 -3 > $OUT/e1-seeds.tar.xz
tar -cf - generate.log campaign-gpt.log bench58-arms *.py *.sh | xz -T16 -3 > $OUT/e1-corpus-logs-scripts.tar.xz
cd $OUT && sha256sum *.tar.xz > SHA256SUMS && ls -l
