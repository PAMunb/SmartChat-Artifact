#!/usr/bin/env python3
"""
Classify every E1 trial from its log, and derive the contracts to exclude from the analysis.

    ./classify-trials.py --campaigns /tmp/rba2-e1/campaigns [--csv trials.csv]

Each trial ends in one of three states:

  ok        the fuzzer printed its final statistics block
  crash     the fuzzer raised an unhandled exception (all observed ones come from Smartian's
            seed handling, and an empty seed directory is one way to trigger it)
  died      neither -- the process disappeared without an exception, which under a 6 GB cap
            means the OOM killer

Trials that do not reach 'ok' stop fuzzing early, so they under-report bugs and coverage.
They cluster in the renamed arms, so keeping them would produce an A > B, C gap caused by
tool limits rather than by memorization. The campaign-level answer is to exclude the affected
*contracts from all three arms alike*: a contract is dropped everywhere if any single trial of
it, in any arm, model or repetition, is not 'ok'. The exclusion list and the per-arm failure
counts both belong in the paper -- crashes concentrated in the opaque arm are themselves a
result.
"""
import argparse
import csv
import os
import re
from collections import defaultdict


def classify(log_path):
    if not os.path.isfile(log_path):
        return "missing", None
    txt = open(log_path, errors="ignore").read()
    stamps = re.findall(r"^\[(\d+):(\d+):(\d+):(\d+)\]", txt, re.M)
    # [dd:hh:mm:ss] since the campaign started; the last one is how far the fuzzer got.
    last = None
    if stamps:
        d, h, m, s = (int(x) for x in stamps[-1])
        last = ((d * 24 + h) * 60 + m) * 60 + s
    if "Unhandled exception" in txt:
        return "crash", last
    if "Done, clean up" in txt:
        return "ok", last
    return "died", last


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--campaigns", required=True, help="campaign output directory")
    ap.add_argument("--csv", default=None, help="write the per-trial table here")
    args = ap.parse_args()

    rows = []
    for tag in sorted(os.listdir(args.campaigns)):
        tag_dir = os.path.join(args.campaigns, tag)
        if not os.path.isdir(tag_dir):
            continue
        arm, _, rest = tag.partition("_")
        model, _, rep = rest.rpartition("_rep")
        for contract in sorted(os.listdir(tag_dir)):
            state, secs = classify(os.path.join(tag_dir, contract, "log.txt"))
            rows.append(dict(arm=arm, model=model, rep=rep, contract=contract,
                             state=state, last_second=secs))

    per_tag = defaultdict(lambda: defaultdict(int))
    for r in rows:
        per_tag[f"{r['arm']}_{r['model']}_rep{r['rep']}"][r["state"]] += 1
    print(f"{'configuration':28s} {'ok':>5s} {'crash':>6s} {'died':>5s} {'missing':>8s}")
    for tag in sorted(per_tag):
        c = per_tag[tag]
        print(f"{tag:28s} {c['ok']:5d} {c['crash']:6d} {c['died']:5d} {c['missing']:8d}")

    bad = sorted({r["contract"] for r in rows if r["state"] in ("crash", "died")})
    print(f"\n{len(bad)} contract(s) to exclude from all arms:")
    for contract in bad:
        where = [f"{r['arm']}/{r['model']}/rep{r['rep']}:{r['state']}"
                 for r in rows if r["contract"] == contract and r["state"] != "ok"]
        print(f"  {contract}  {', '.join(where)}")

    if args.csv:
        with open(args.csv, "w", newline="") as f:
            w = csv.DictWriter(f, fieldnames=list(rows[0]))
            w.writeheader()
            w.writerows(rows)
        print(f"\nper-trial table -> {args.csv}")


if __name__ == "__main__":
    main()
