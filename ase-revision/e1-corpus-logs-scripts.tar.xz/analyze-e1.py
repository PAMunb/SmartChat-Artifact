#!/usr/bin/env python3
"""
Analyse the E1 campaigns: per-arm bug detection, coverage and time to detection.

    ./analyze-e1.py --campaigns /tmp/rba2-e1/campaigns \
                    --bug-csv SmartChat-Artifact/benchmarks/assets/B1-bug.csv

Metrics follow the artifact's own scripts (`scripts/common.py`, `plot_b1_bug.py`) so the
numbers read against the published ones:

  detected   a contract counts as detected when its log contains "IntegerBug at"; Bench58 is
             an integer-overflow benchmark and its ground truth (B1-bug.csv) marks every
             contract as vulnerable
  ttd        seconds from campaign start to that first alarm, from the [dd:hh:mm:ss] stamp
             preceding it -- exactly parse_fuzz_log's rule
  coverage   "Covered Instructions" in the final statistics block

Contracts excluded by classify-trials.py (a trial that crashed or died in any arm) are
dropped from *every* arm, so the arms stay comparable; see experiment-spec.md 3.4.1.

Arms are compared on the repetition as the unit of observation (n = 5 per arm), with a
two-sided Mann-Whitney U-test, the same test the paper uses. The per-contract paired view is
printed alongside, because with five repetitions the test has little power and the paired
counts are often the more informative statement.
"""
import argparse
import os
import re
from collections import defaultdict

ALARM = "IntegerBug at"
STAMP = re.compile(r"\[(\d+):(\d+):(\d+):(\d+)\]")


def parse_trial(log_path):
    """-> (state, detected, ttd_seconds, covered_instructions)"""
    if not os.path.isfile(log_path):
        return "missing", False, None, None
    buf = open(log_path, errors="ignore").read()
    state = ("crash" if "Unhandled exception" in buf
             else "ok" if "Done, clean up" in buf else "died")

    ttd = None
    idx = buf.find(ALARM)
    if idx != -1:
        head = buf[:idx]
        start, end = head.rfind("["), head.rfind("]")
        d, h, m, s = (int(x) for x in head[start + 1:end].split(":"))
        ttd = ((d * 24 + h) * 60 + m) * 60 + s

    cov = re.findall(r"Covered Instructions: (\d+)", buf)
    return state, idx != -1, ttd, int(cov[-1]) if cov else None


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--campaigns", required=True)
    ap.add_argument("--bug-csv", required=True, help="benchmarks/assets/B1-bug.csv")
    ap.add_argument("--model", default="gpt4.1mini", help="model tag, or smartian-dfa")
    ap.add_argument("--keep-all", action="store_true",
                    help="skip the exclusion of contracts that failed in some arm")
    args = ap.parse_args()

    ground_truth = [line.split(",")[0] for line in open(args.bug_csv) if line.strip()]

    # trials[(arm, rep)][contract] = (state, detected, ttd, cov)
    trials = defaultdict(dict)
    for tag in sorted(os.listdir(args.campaigns)):
        tag_dir = os.path.join(args.campaigns, tag)
        if not os.path.isdir(tag_dir) or f"_{args.model}_rep" not in tag:
            continue
        arm = tag.split("_")[0]
        rep = int(tag.rsplit("_rep", 1)[1])
        for contract in sorted(os.listdir(tag_dir)):
            trials[(arm, rep)][contract] = parse_trial(
                os.path.join(tag_dir, contract, "log.txt"))

    arms = sorted({arm for arm, _ in trials})
    reps = sorted({rep for _, rep in trials})

    # Only a trial the fuzzer actually ran and failed disqualifies its contract. A trial the
    # campaign has not reached yet is 'missing', and excluding those would empty the table
    # while the run is still in progress.
    excluded = set()
    if not args.keep_all:
        for cell in trials.values():
            excluded |= {c for c, (state, *_) in cell.items() if state in ("crash", "died")}
    kept = [c for c in ground_truth if c not in excluded]
    print(f"{len(ground_truth)} contracts, {len(excluded)} excluded, {len(kept)} analysed")
    if excluded:
        print("  excluded: " + ", ".join(sorted(excluded)))

    print(f"\n{'arm':>4s} {'rep':>4s} {'detected':>9s} {'mean TTD (s)':>13s} {'mean cov':>9s}")
    per_arm = defaultdict(list)
    for arm in arms:
        for rep in reps:
            cell = trials.get((arm, rep))
            if not cell:
                continue
            rows = [cell[c] for c in kept if c in cell]
            if not rows:
                continue
            # A repetition the campaign has not finished would drag its arm's mean down, so
            # it is shown for progress but kept out of the means and the tests.
            partial = len(rows) < len(kept) or any(r[0] == "missing" for r in rows)
            det = [r for r in rows if r[1]]
            ttds = [r[2] for r in det if r[2] is not None]
            covs = [r[3] for r in rows if r[3] is not None]
            mean_ttd = sum(ttds) / len(ttds) if ttds else float("nan")
            mean_cov = sum(covs) / len(covs) if covs else float("nan")
            print(f"{arm:>4s} {rep:>4d} {len(det):>4d}/{len(rows):<4d} "
                  f"{mean_ttd:>13.1f} {mean_cov:>9.1f}"
                  + ("   (incomplete, not counted)" if partial else ""))
            if not partial:
                per_arm[arm].append((len(det), mean_ttd, mean_cov))

    print("\nper-arm means over repetitions")
    for arm in arms:
        vals = per_arm[arm]
        if not vals:
            continue
        n = len(vals)
        print(f"  {arm}: detected {sum(v[0] for v in vals) / n:.1f}, "
              f"TTD {sum(v[1] for v in vals) / n:.1f} s, "
              f"coverage {sum(v[2] for v in vals) / n:.1f}  (n={n} repetitions)")

    try:
        from scipy.stats import mannwhitneyu
    except ImportError:
        print("\n(scipy not available: skipping the Mann-Whitney tests)")
        return

    # Effect sizes, not just p-values. With five repetitions a Mann-Whitney test can only
    # rule out large differences, so "p > 0.05" must never be read as equivalence -- the very
    # inversion Reviewer 2 objects to in the published RQ2 table. A12 says how big the
    # difference is; the sign of (A12 - 0.5) says which arm is ahead.
    def a12(xs, ys):
        gt = sum(1 for x in xs for y in ys if x > y)
        eq = sum(1 for x in xs for y in ys if x == y)
        return (gt + 0.5 * eq) / (len(xs) * len(ys))

    def magnitude(a):
        d = abs(a - 0.5)
        return ("negligible" if d < 0.06 else "small" if d < 0.14
                else "medium" if d < 0.21 else "large")

    print("\nMann-Whitney U (two-sided) and Vargha-Delaney, repetition as the unit")
    for i, a in enumerate(arms):
        for b in arms[i + 1:]:
            for k, name in ((0, "detected"), (1, "TTD"), (2, "coverage")):
                xs = [v[k] for v in per_arm[a]]
                ys = [v[k] for v in per_arm[b]]
                if len(xs) < 2 or len(ys) < 2:
                    continue
                p = mannwhitneyu(xs, ys, alternative="two-sided").pvalue
                est = a12(xs, ys)
                print(f"  {a} vs {b}, {name:9s}: p = {p:.3f}, A12 = {est:.2f} "
                      f"({magnitude(est)})")
    print("\nn = 5 per arm: the smallest attainable two-sided p is 0.0079 and A12 moves in "
          "steps of 0.04.")


if __name__ == "__main__":
    main()
