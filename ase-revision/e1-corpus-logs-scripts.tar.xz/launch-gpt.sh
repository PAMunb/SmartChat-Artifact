#!/bin/bash
# First batch of E1: SmartChat with GPT-4.1-mini seeds, three arms, five repetitions.
cd ~/e1
mkdir -p /tmp/rba2-e1
exec ./run-campaigns.py --arms bench58-arms --seeds seeds --out /tmp/rba2-e1/campaigns \
  --models gpt4.1mini --cores 0-31 --mems 0
