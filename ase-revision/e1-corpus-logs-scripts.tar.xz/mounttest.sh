#!/bin/bash
cd ~/e1; C=2018-10299; A=$PWD/bench58-arms/A/$C
echo "== rw mount"
docker run --rm -v $A:/tgt smartchat-artifact bash -c \
  "timeout 90 dotnet /home/test/tools/Smartian/build/Smartian.dll fuzz --useothersoracle -t 60 -p /tgt/$C.bin -a /tgt/$C.abi -v 1 -o /tmp/o 2>&1 | grep -E 'Total Executions|Covered Instr'; echo 'files left behind:'; ls /tgt"
echo "== ro file mount + copy inside"
docker run --rm -v $A/$C.bin:/ro/$C.bin:ro -v $A/$C.abi:/ro/$C.abi:ro smartchat-artifact bash -c \
  "mkdir -p /home/test/t && cp /ro/* /home/test/t/ && timeout 90 dotnet /home/test/tools/Smartian/build/Smartian.dll fuzz --useothersoracle -t 60 -p /home/test/t/$C.bin -a /home/test/t/$C.abi -v 1 -o /tmp/o 2>&1 | grep -E 'Total Executions|Covered Instr'"
echo "== done"
