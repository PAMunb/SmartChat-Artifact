#!/usr/bin/env bash
#
# Generate LLM seeds for the three arms of experiment E1.
#
# Run this inside the SmartChat environment (the genai4fuzz CLI and its Slither/solc
# toolchain must be on PATH), with the provider API keys exported:
#
#   export OPENAI_API_KEY=...        # for gpt4.1mini
#   export SAMBANOVA_API_KEY=...     # for Llama3.3-70B
#   ./generate-seeds.sh bench58-arms out-seeds 5
#
# Each (arm, model, repetition) is an independent job, 30 in all, run JOBS at a time
# (default 6). genai4fuzz writes prompts and responses next to the contract, so every job
# works on its own copy of the arm; sharing one directory would let a job archive another's
# responses. The bound is the providers' rate limits, not the machine. A job that finished is
# marked done and skipped on rerun, so an interrupted run can simply be restarted.
#
# Configuration mirrors RQ2: the ABI-only prompt (V1), temperature 0.4, ten test cases of at
# least four transactions each.
#
# All three arms are generated in the same session. Arm A's seeds are archived in the artifact
# from the original campaigns and could in principle be reused, but the model served behind a
# given API name changes over time, so seeds generated a year apart would confound model drift
# with the effect we are trying to measure. Regenerating all three is cheap and removes that.
#
# Five independent seed sets are generated per arm, one per campaign repetition. The paper's
# protocol reuses a single seed set across its five repetitions, so those repetitions capture
# only the stochasticity of the fuzzer; pairing repetition i with seed set i makes them capture
# the stochasticity of generation as well, at no additional campaign cost. Without this, a
# difference between arms could be sampling noise in a single LLM response rather than an
# effect of the renaming. The deviation from the paper's protocol must be stated when the
# results are reported.

set -euo pipefail

ARMS_DIR="$(cd "${1:?usage: generate-seeds.sh <arms-dir> <out-dir> [repetitions]}" && pwd)"
OUT_DIR="${2:?usage: generate-seeds.sh <arms-dir> <out-dir> [repetitions]}"
REPS="${3:-5}"
JOBS="${JOBS:-6}"

mkdir -p "${OUT_DIR}"
OUT_DIR="$(cd "${OUT_DIR}" && pwd)"

TEMPERATURE=0.4
TOTAL_TESTS=10
TOTAL_TXS=4
PROMPT=V1

# provider:model pairs, matching the RQ2 configurations
MODELS=(
  "gpt:gpt4.1mini"
  "sambanova:Llama3.3-70B"
)

run_job() {
  local arm="$1" provider="$2" model="$3" rep="$4"
  local tag="${arm}_${model}_rep${rep}"
  local seed_out="${OUT_DIR}/${tag}"
  local raw_out="${OUT_DIR}/raw/${tag}"
  local work="${OUT_DIR}/work/${tag}"
  local log="${OUT_DIR}/logs/${tag}.log"

  [ -f "${seed_out}/.done" ] && { echo "skip ${tag}"; return 0; }

  rm -rf "${work}" "${seed_out}" "${raw_out}"
  mkdir -p "${work}" "${seed_out}" "${raw_out}" "$(dirname "${log}")"
  cp -r "${ARMS_DIR}/${arm}/." "${work}/"

  {
    for contract_dir in "${work}"/*/; do
      contract="$(basename "${contract_dir}")"
      [ -f "${contract_dir}/${contract}.abi" ] || continue

      # run_llm writes the prompt and the raw response next to the contract
      genai4fuzz run_llm "${contract_dir}" "${provider}" "${model}" \
        "${TEMPERATURE}" "${TOTAL_TESTS}" "${TOTAL_TXS}" "${PROMPT}" \
        || echo "!! generation failed: ${contract}"

      # Convert this contract's response into the fuzzer's seed format
      genai4fuzz convert_to_smartian "${contract_dir}" "${seed_out}" "${model}" \
        || echo "!! conversion failed: ${contract}"

      # Keep the raw prompt and response
      mkdir -p "${raw_out}/${contract}"
      find "${contract_dir}" -maxdepth 1 \( -name '*_prompt_*' -o -name '*_testcase_*' \) \
        -exec mv {} "${raw_out}/${contract}/" \;
    done
  } > "${log}" 2>&1

  rm -rf "${work}"
  touch "${seed_out}/.done"
  echo "done ${tag} ($(grep -c '^!!' "${log}" || true) failures, see ${log})"
}
export -f run_job
export ARMS_DIR OUT_DIR TEMPERATURE TOTAL_TESTS TOTAL_TXS PROMPT

for rep in $(seq 1 "${REPS}"); do
  for arm in A B C; do
    for pair in "${MODELS[@]}"; do
      echo "${arm} ${pair%%:*} ${pair##*:} ${rep}"
    done
  done
done | xargs -P "${JOBS}" -L 1 bash -c 'run_job "$@"' _

echo
echo "seeds  -> ${OUT_DIR}/<arm>_<model>_rep<n>/"
echo "raw    -> ${OUT_DIR}/raw/<arm>_<model>_rep<n>/"
echo "logs   -> ${OUT_DIR}/logs/"
