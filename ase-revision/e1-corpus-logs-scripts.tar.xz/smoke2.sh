#!/bin/bash
cd ~/e1
date
time ./run-campaigns.py --arms bench58-arms --seeds seeds --out smoke2 --models gpt4.1mini --cores 0-2 --mems 0 --timelimit 180 --limit 3
echo "=== results"
for d in smoke2/*/*/; do
  echo "== $d"
  grep -E "Total Executions|Covered Edges|Covered Instructions" $d/log.txt
  echo "cov lines: $(wc -l < $d/cov.txt), last: $(tail -1 $d/cov.txt), testcases: $(ls $d/testcase | wc -l)"
done
date
