#!/bin/bash
cd ~/e1
docker rm -f $(docker ps -q --filter name=e1-) >/dev/null 2>&1
rm -rf smoke-campaigns
date
time ./run-campaigns.py --arms bench58-arms --seeds seeds --out smoke-campaigns \
  --models gpt4.1mini --cores 0-2 --mems 0 --timelimit 180 --limit 3
echo "=== results"
for d in smoke-campaigns/*/*/; do
  echo "== $d"
  ls $d
  grep -E "Total Executions|Covered Instructions|Covered Edges" $d/log.txt
  echo "cov.txt: $(wc -l < $d/cov.txt) lines, last: $(tail -1 $d/cov.txt)"
done
