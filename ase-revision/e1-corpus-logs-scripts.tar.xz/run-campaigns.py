#!/usr/bin/env python3
"""
Campaign orchestrator for experiment E1 (identifier renaming on Bench58).

    ./run-campaigns.py --arms bench58-arms --seeds out-seeds --out campaigns [--jobs 60]
    ./run-campaigns.py ... --cores 0-31 --mems 0     # one socket of cluster-node11

Runs 9 configurations -- three arms (A original, B synonym-renamed, C opaque-renamed) times
three tools (SmartChat with GPT4.1-Mini seeds, SmartChat with Llama3.3-70B seeds, and Smartian
with its own data-flow seeds) -- over 58 contracts and 5 repetitions: 2,610 one-hour trials.

Why not scripts/run_experiment.py: it hardcodes MAX_INSTANCE_NUM = 20 and runs contracts in
fixed batches, waiting for the slowest of each batch. With 58 contracts that is three
sequential batches per configuration-repetition, so 45 runs take roughly 148 hours even on a
machine with far more than 20 cores. Scheduling every trial through one queue keeps all cores
busy and brings the same work down to about 44 hours on 60 cores.

Repetition i consumes seed set i. Running all five repetitions against one seed set would
silently discard the point of generating five, since the repetitions would then capture only
the fuzzer's stochasticity and not the generator's.

Resumable: a trial whose output already holds a completed log is skipped, so a spot-instance
preemption costs at most the trials in flight.

Two container runtimes are supported. Docker matches the published setup; Apptainer is there
because HPC clusters rarely allow Docker, which needs root. Under SLURM, prefer --print-tasks
and an array job: the 2,610 trials are independent one-core, one-hour units, which is exactly
what array jobs are for, and the scheduler then handles pinning and requeueing.
"""
import argparse
import json
import os
import queue
import shutil
import subprocess
import sys
import threading
import time

IMAGE = "smartchat-artifact"
ARMS = ["A", "B", "C"]
MODELS = ["gpt4.1mini", "Llama3.3-70B"]
SMARTCHAT_OPTS = "--uselllmseeds --nosdfa --noddfa --withbuggain"
TIMELIMIT = 3600          # seconds; matches the published protocol
REPS = 5

print_lock = threading.Lock()


def log(msg):
    with print_lock:
        print(f"[{time.strftime('%H:%M:%S')}] {msg}", flush=True)


def run(cmd, **kw):
    return subprocess.run(cmd, shell=isinstance(cmd, str), capture_output=True, text=True, **kw)


def trial_done(outdir):
    """A trial counts as finished only if the fuzzer wrote a log and the replayer a cov file.

    Both must be non-empty: a container that dies immediately still leaves the two files
    behind, and an existence-only check would mark such a trial done and skip it on the
    next run -- silently turning a broken campaign into a short one.
    """
    def nonempty(name):
        p = os.path.join(outdir, name)
        return os.path.isfile(p) and os.path.getsize(p) > 0

    return nonempty("log.txt") and nonempty("cov.txt")


def build_trials(args):
    contracts = sorted(d for d in os.listdir(os.path.join(args.arms, "A"))
                       if os.path.isdir(os.path.join(args.arms, "A", d)))
    trials = []
    for rep in range(1, REPS + 1):
        for arm in ARMS:
            for model in MODELS + ["smartian-dfa"]:
                for contract in contracts:
                    tag = f"{arm}_{model}_rep{rep}"
                    outdir = os.path.join(args.out, tag, contract)
                    if trial_done(outdir):
                        continue
                    seeds = (None if model == "smartian-dfa"
                             else os.path.join(args.seeds, tag, contract, "seeds"))
                    trials.append(dict(arm=arm, model=model, rep=rep, contract=contract,
                                       tag=tag, outdir=outdir, seeds=seeds))
    if getattr(args, "models", None):
        trials = [t for t in trials if t["model"] in args.models]
    if getattr(args, "only", None):
        trials = [t for t in trials if f"{t['tag']}/{t['contract']}" == args.only]
    return trials, contracts


def parse_cpu_list(spec):
    """'0-3,8' -> [0, 1, 2, 3, 8], the syntax lscpu and cpuset use."""
    cpus = []
    for part in spec.split(","):
        lo, _, hi = part.partition("-")
        cpus.extend(range(int(lo), int(hi or lo) + 1))
    return cpus


def trial_paths(t, args):
    base = os.path.join(args.arms, t["arm"], t["contract"])
    return (os.path.abspath(os.path.join(base, f"{t['contract']}.bin")),
            os.path.abspath(os.path.join(base, f"{t['contract']}.abi")),
            os.path.abspath(t["seeds"]) if t["seeds"] else None)


def inner_command(t, timelimit=TIMELIMIT):
    opts = SMARTCHAT_OPTS if t["model"] != "smartian-dfa" else ""
    seed_arg = "-s /home/test/in/seeds" if t["seeds"] else ""
    # Everything the trial reads or writes lives inside the container; only the finished
    # output is copied to the bind mount at the end. The host directories are on an NFS home,
    # and the fuzzer reads the bytecode through mmap: from the mount it silently performs zero
    # executions, and the replayer crawls over the test cases it has to re-read. Keeping the
    # working set local also spares the NFS server 32 concurrent writers, which would
    # otherwise add noise to the very timings this experiment measures. The replayer's own
    # OUTDIR is hardcoded to /home/test/output, so that is the directory we keep local.
    return (f"mkdir -p /home/test/in /home/test/output && cp -r /ro/. /home/test/in/ && "
            f"dotnet /home/test/tools/Smartian/build/Smartian.dll fuzz "
            f"--useothersoracle -t {timelimit} -p /home/test/in/target.bin "
            f"-a /home/test/in/target.abi -v 1 {opts} -o /home/test/output {seed_arg} "
            f"> /home/test/output/log.txt 2>&1 ; "
            # Replay to produce the per-minute coverage file the analysis scripts read.
            f"/home/test/scripts/run_replayer.sh smartian /home/test/in/target.bin "
            f"/home/test/in/target.abi {t['contract']} 1 >> /home/test/output/log.txt 2>&1 ; "
            f"cp -r /home/test/output/. /host-out/")


def run_trial(t, core, args):
    """One trial in its own container, pinned to one core, as in the published setup.

    The host output directory is bind-mounted at /host-out and the container copies its
    results there as its last step, while still running -- rather than the artifact's
    'docker cp' after exit, which has nothing to copy from under Apptainer.
    """
    host_bin, host_abi, host_seeds = trial_paths(t, args)
    if not (os.path.isfile(host_bin) and os.path.isfile(host_abi)):
        log(f"  !! missing bin/abi: {t['tag']}/{t['contract']}")
        return False
    if t["seeds"] and not os.path.isdir(host_seeds):
        log(f"  !! missing seeds: {t['tag']}/{t['contract']}")
        return False
    os.makedirs(t["outdir"], exist_ok=True)
    # The image runs as its own 'test' user (uid 1000), which is not the uid that owns the
    # bind-mounted output directory on the host; without this the fuzzer cannot write its log.
    # Running the container as the host uid instead would leave $HOME unwritable for dotnet.
    os.chmod(t["outdir"], 0o777)
    outdir = os.path.abspath(t["outdir"])
    inner = inner_command(t, args.timelimit)

    if args.runtime == "docker":
        name = f"e1-{t['tag']}-{t['contract']}".replace(".", "_")
        binds = ["-v", f"{host_bin}:/ro/target.bin:ro",
                 "-v", f"{host_abi}:/ro/target.abi:ro",
                 "-v", f"{outdir}:/host-out"]
        if host_seeds:
            binds += ["-v", f"{host_seeds}:/ro/seeds:ro"]
        run(["docker", "rm", "-f", name])
        mems = [f"--cpuset-mems={args.mems}"] if args.mems else []
        cmd = (["docker", "run", "--rm", "-m=6g", f"--cpuset-cpus={core}", *mems, "--name", name]
               + binds + [args.image, "/bin/bash", "-c", inner])
    else:
        # Apptainer: the scheduler owns CPU placement, so no pinning here.
        binds = [f"{host_bin}:/ro/target.bin",
                 f"{host_abi}:/ro/target.abi",
                 f"{outdir}:/host-out"]
        if host_seeds:
            binds.append(f"{host_seeds}:/ro/seeds")
        cmd = ["apptainer", "exec", "--containall", "--bind", ",".join(binds),
               args.image, "/bin/bash", "-c", inner]

    # Generous margin over the fuzzing budget so a hung container cannot stall a worker.
    p = run(cmd, timeout=args.timelimit + 900)
    if p.returncode != 0:
        log(f"  !! trial failed ({p.returncode}): {t['tag']}/{t['contract']}: {p.stderr[-200:]}")
    return trial_done(t["outdir"])


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--arms", required=True, help="three-arm corpus (A/B/C per contract)")
    ap.add_argument("--seeds", required=True, help="seed sets from generate-seeds.sh")
    ap.add_argument("--out", required=True, help="campaign output directory")
    ap.add_argument("--jobs", type=int, default=max(1, os.cpu_count() - 2),
                    help="parallel trials; one dedicated core each")
    ap.add_argument("--cores", default=None,
                    help="CPUs to pin trials to, e.g. 0-31 or 0-15,32-47; one trial per CPU, "
                         "overrides --jobs. List physical cores only, never SMT siblings")
    ap.add_argument("--mems", default=None,
                    help="NUMA memory node(s) for every container (docker --cpuset-mems), "
                         "so memory stays local to the pinned cores")
    ap.add_argument("--runtime", choices=["docker", "apptainer"], default="docker")
    ap.add_argument("--image", default=None,
                    help="container image; defaults to the docker image name, or smartchat.sif")
    ap.add_argument("--limit", type=int, default=0,
                    help="run only the first N trials -- use this for a smoke test before "
                         "committing to the full run")
    ap.add_argument("--print-tasks", action="store_true",
                    help="emit one shell command per remaining trial and exit, for a SLURM "
                         "array job instead of this script's own worker pool")
    ap.add_argument("--only", default=None,
                    help="run just this trial, given as <tag>/<contract>; used by array jobs")
    ap.add_argument("--models", default=None,
                    help="comma-separated subset of " + ",".join(MODELS + ["smartian-dfa"])
                         + " to run now; the rest can follow later, since done trials are skipped")
    ap.add_argument("--timelimit", type=int, default=TIMELIMIT,
                    help="seconds per trial; the published protocol is 3600. Lower it only "
                         "for smoke tests -- campaign results must use the default")
    ap.add_argument("--dry-run", action="store_true")
    args = ap.parse_args()
    if args.image is None:
        args.image = IMAGE if args.runtime == "docker" else "smartchat.sif"
    if args.models:
        args.models = args.models.split(",")
        unknown = set(args.models) - set(MODELS + ["smartian-dfa"])
        if unknown:
            sys.exit(f"unknown model(s): {', '.join(sorted(unknown))}")
    if args.cores:
        args.cores = parse_cpu_list(args.cores)
        args.jobs = len(args.cores)
    else:
        args.cores = list(range(args.jobs))

    trials, contracts = build_trials(args)
    total = REPS * len(ARMS) * (len(MODELS) + 1) * len(contracts)
    log(f"{len(contracts)} contracts, {total} trials total, {len(trials)} remaining")
    if args.limit:
        trials = trials[:args.limit]
        log(f"--limit {args.limit}: running {len(trials)} of them")
    log(f"{args.jobs} parallel trials -> roughly {len(trials) / args.jobs:.1f} hours")

    if args.print_tasks:
        me = os.path.abspath(__file__)
        for i, t in enumerate(trials):
            print(f"{me} --arms {args.arms} --seeds {args.seeds} --out {args.out} "
                  f"--runtime {args.runtime} --image {args.image} --jobs 1 "
                  f"--only {t['tag']}/{t['contract']}")
        return

    if args.dry_run:
        for t in trials[:10]:
            log(f"  would run {t['tag']}/{t['contract']} seeds={t['seeds']}")
        return

    if shutil.which(args.runtime) is None:
        sys.exit(f"{args.runtime} not found")

    q = queue.Queue()
    for t in trials:
        q.put(t)
    done = {"ok": 0, "fail": 0}
    done_lock = threading.Lock()

    def worker(core):
        while True:
            try:
                t = q.get_nowait()
            except queue.Empty:
                return
            ok = False
            try:
                ok = run_trial(t, core, args)
            except subprocess.TimeoutExpired:
                log(f"  !! timeout: {t['tag']}/{t['contract']}")
            finally:
                with done_lock:
                    done["ok" if ok else "fail"] += 1
                    n = done["ok"] + done["fail"]
                if n % 25 == 0:
                    log(f"progress {n}/{len(trials)}  ok={done['ok']} fail={done['fail']}")
                q.task_done()

    threads = [threading.Thread(target=worker, args=(c,), daemon=True) for c in args.cores]
    start = time.time()
    for th in threads:
        th.start()
    for th in threads:
        th.join()

    log(f"finished in {(time.time() - start) / 3600:.1f} h: ok={done['ok']} fail={done['fail']}")
    with open(os.path.join(args.out, "run-manifest.json"), "w") as f:
        json.dump({"contracts": contracts, "arms": ARMS, "models": MODELS + ["smartian-dfa"],
                   "reps": REPS, "timelimit": args.timelimit, "opts": SMARTCHAT_OPTS,
                   "ok": done["ok"], "fail": done["fail"]}, f, indent=2)


if __name__ == "__main__":
    main()
