pragma solidity ^0.4.21;
contract C1 { function f1(address v2, uint256 v3, address v4, bytes v5) public; }
contract C2
  { 
     
    string  public v6;                                                        
    string  public v7;                                                      
    uint8   public v8;                                                    
    uint256 public v9;                                                 
    uint256 public v10;                                                   
    uint    public v11;                                                     
    address public v12;                                                       
    uint256 public v13;                                             
    uint    public v14;                                                   
    uint    public v15;                                               
    address public v16;                                                  
    address public v17;                                                   
    uint    public v18;                                          
    
     
    mapping (address => uint256) public v19;                              
    mapping (address => mapping (address => uint256)) public v20;
    mapping (address => bool) public v21;
    
    
    event FrozenFunds(address v22, bool v23);
    event Transfer(address indexed v2, address indexed v24, uint256 v3);
    event Burn(address indexed v2, uint256 v3);
    event TransferSell(address indexed v2, address indexed v24, uint256 v3, string v25); 
    

     
    function C2() public
    {
      v9 = 1000000000000000000000000000;                                 
      v12 =  msg.sender;                                                      
      v19[v12] = v9;                                           
      v6 = "CERB Coin";                                                     
      v7 = "CERB";                                                          
      v8 = 18;                                                            
      v10 = v9;                                                  
      v11 = 665;                                                            
      v14 = 1;                                                            
      v15 = 50;                                                       
      v16 = 0x4532828EC057e6cFa04a42b153d74B345084C4C2;                  
      v17  = 0x1D38b496176bDaB78D430cebf25B2Fe413d3BF84;                   
      v18 = 0;                                                   
    }

   modifier m26()
    {
        require((msg.sender == v12) || (msg.sender ==  v17));
        _;
    }


    function () public payable                                                  
    {
    }    
    
    function f27(address v29,uint256 v30) public m26 
    {
        if (v10 > 0)
        {
            uint v28 =  (v30  * (10 ** 18));              
            if(v28 < v10)
                {
                    v10 = v10 - v28;
                    f60(v12,v29, v28);    
                    TransferSell(v12, v29, v28,'Offline');
                }
            else
                {
                    revert();
                }
        }
        else
        {
            revert();
        }        
    }
    
    function f31() m26 public constant returns  (uint)            
    {
        return v11;
    }

    
    function f32() m26 public constant returns  (uint)            
    {
        return this.balance;
    }    
    
    function f33 (uint v34) public  m26                    
    {
        v11 = v34;
    } 


    function f35() m26 public constant returns  (uint)         
    {
        return v15;
    }
    
    function f36 (uint v37) public  m26               
    {
        v15 = v37;
    }     
    
    
    function f38 (uint v39) public  m26                 
    {
        v18 = v39;
    }   
    
    function f40 (uint8 v41)  public m26                   
    {
        v14 = v41;
    } 
    

    function f42(uint v43) public m26                        
        {
            if((msg.sender == v12) || (msg.sender ==  v17))
            {
                v16.transfer(v43);
            }
            else
            {
                revert();
            }
        }

    function f44() public m26                                   
        {
            if((msg.sender == v12) || (msg.sender ==  v17) )
            {
                var v43 = this.balance - 10000000000000000;
                v16.transfer(v43);
            }
            else
            {
                revert();
            }
        }

    function f45(uint256 v47) public m26 
        {
            if(v47 > 0)
            {
                var v46 = v47 * (10 ** 18);
                v19[v12] += v46;
                v9 += v46;
                Transfer(0, v12, v46);
            }
        }
		

	 
	 function f48(address v49,address v50, uint256 v51)  public m26
		  {
			  f60(v49, v50, v51);
		  }
		

    function f52(address v22, bool v53) public m26 
        {
            v21[v22] = v53;
            FrozenFunds(v22, v53);
        }
            

    function f54() m26 public constant returns (uint256 v55) 
        {
            return v13;
        }        

    function v19(address v56) public constant returns (uint256 v55) 
        {
            return v19[v56];
        }

    function v9() private constant returns (uint256 v57) 
        {
            v57 = v9;
        }    


    function f58(address v59) public m26 
        { 
            v19[v12] = 0;                        
            v19[v59] = v10;               
            v12 = v59; 
        }        

  
  function f60(address v49, address v50, uint v51) internal 
      {
          if(v18 == 1 || v49 == v12 )
          {
              require(!v21[v49]);                                   
              require (v50 != 0x0);                                             
              require (v19[v49] > v51);                              
              require (v19[v50] + v51 > v19[v50]);               
              v19[v49] -= v51;                                       
              v19[v50] += v51;                                         
              Transfer(v49, v50, v51);                                     
          }
          else
          {
               revert();
          }
      }

  function f61(address v50, uint256 v51)  public
      {
          f60(msg.sender, v50, v51);
      }

  function f62(address v49, address v50, uint256 v51) public returns (bool v63) 
      {
          require (v51 < v20[v49][msg.sender]);                      
          v20[v49][msg.sender] -= v51;
          f60(v49, v50, v51);
          return true;
      }

  function f64(address v65, uint256 v51) public returns (bool v63) 
      {
          v20[msg.sender][v65] = v51;
          return true;
      }

  function f66(address v65, uint256 v51, bytes v68) public returns (bool v63)
      {
          C1 v67 = C1(v65);
          if (f64(v65, v51)) {
              v67.f1(msg.sender, v51, this, v68);
              return true;
          }
      }        

  function f69(uint256 v51) public returns (bool v63) 
      {
          require (v19[msg.sender] > v51);                             
          v19[msg.sender] -= v51;                                      
          v9 -= v51;                                                
          Burn(msg.sender, v51);
          return true;
      }

  function f70(address v49, uint256 v51) public returns (bool v63) 
      {
          require(v19[v49] >= v51);                                  
          require(v51 <= v20[v49][msg.sender]);                      
          v19[v49] -= v51;                                           
          v20[v49][msg.sender] -= v51;                               
          v9 -= v51;                                                
          Burn(v49, v51);
          return true;
      }
} 
