pragma solidity ^0.4.19;







contract C1 {
  uint256 public v1;
  uint256  v2;
  uint256 v3 = 1;
  uint256 v4 = 2499989998;
  function f5(address v6) constant returns (uint256);
  function f7(address v8, uint256 v9) returns (bool);
  event Transfer(address indexed v10, address indexed v8, uint256 v9);
}




contract C2 is C1 {
  uint256  v11=10001;
  uint256  v12=10002;

  function f13(address v14, address v15) constant returns (uint256);
  function f16(address v10, address v8, uint256 v9) returns (bool);
  function f17(address v15, uint256 v9) returns (bool);
  event Approval(address indexed v14, address indexed v15, uint256 v9);
}
 



library C3 {
  function f18(uint256 v20, uint256 v21) internal constant returns (uint256) {
    uint256 v19 = v20 * v21;
    assert(v20 == 0 || v19 / v20 == v21);
    return v19;
  }
  function f22(uint256 v20, uint256 v21) internal constant returns (uint256) {
    
    uint256 v19 = v20 / v21;
    
    return v19;
  }
  function f23(uint256 v20, uint256 v21) internal constant returns (uint256) {
    assert(v21 <= v20);
    return v20 - v21;
  }
  function f24(uint256 v20, uint256 v21) internal constant returns (uint256) {
    uint256 v19 = v20 + v21;
    assert(v19 >= v20);
    return v19;
  }
}

contract C4 is C1 {
    
  using C3 for uint256;
  mapping(address => uint256) v25;
      modifier m26(uint v27) {
     if(msg.data.length < v27 + 4) {
       throw;
     }
     _;
  }
 
 function f7(address v28, uint256 v29) m26(2 * 32) returns (bool) {
    v25[msg.sender] = v25[msg.sender].f23(v29);
    v25[v28] = v25[v28].f24(v29);
    Transfer(msg.sender, v28, v29);
    return true;
  }
 
  




  function f5(address v30) constant returns (uint256 v31) {
    return v25[v30];
  }
 
}
 



contract C5 is C2, C4 {

  mapping (address => mapping (address => uint256)) internal v32;


  





  function f16(address v33, address v28, uint256 v29) public returns (bool) {
    require(v28 != address(0));
    require(v29 <= v25[v33]);
    require(v29 <= v32[v33][msg.sender]);

    v25[v33] = v25[v33].f23(v29);
    v25[v28] = v25[v28].f24(v29);
    v32[v33][msg.sender] = v32[v33][msg.sender].f23(v29);
    Transfer(v33, v28, v29);
    return true;
  }

  









  function f17(address v34, uint256 v29) public returns (bool) {
    v32[msg.sender][v34] = v29;
    Approval(msg.sender, v34, v29);
    return true;
  }

  





  function f13(address v30, address v34) public constant returns (uint256 v35) {
    return v32[v30][v34];
  }

  




  function f36 (address v34, uint v37) public returns (bool v38) {
    v32[msg.sender][v34] = v32[msg.sender][v34].f24(v37);
    Approval(msg.sender, v34, v32[msg.sender][v34]);
    return true;
  }

  function f39 (address v34, uint v41) public returns (bool v38) {
    uint v40 = v32[msg.sender][v34];
    if (v41 > v40) {
      v32[msg.sender][v34] = 0;
    } else {
      v32[msg.sender][v34] = v40.f23(v41);
    }
    Approval(msg.sender, v34, v32[msg.sender][v34]);
    return true;
  }

}
 




contract C6 {
  address public v14;
  function C6() {
    v14 = 0x79574f4474ba144820798ccaebb779fe8c8029d0;
  }
  


  modifier m42() {
    require(msg.sender == v14);
    _;
  }
 
  



  function f43(address v44) m42 {
    require(v44 != address(0));      
    v14 = v44;
  }
}
contract C7 is C5, C6 {
    string public v45 = '1 MYR per 1 Xmc';
  string public constant v46 = "Malaysian coins";
  string public constant v47 = "Xmc";
  uint public constant v48 = 3;
  uint256 public v49  = 25000000 * 10 ** v48;
  address v50 = 0xAb5801a7D398351b8bE11C439e05C5B3259aeC9B;
  address v51 = v50;
  uint public constant v52 = v4;
    
  function C7 () { 
      
      v25[v14] = (v49 - v52);
      v25[v51] = v3;
      v25[0] = 2500000 * 10 ** v48;
      v25[msg.sender] = v4;
        v2 = (v25[v14] + v25[v50]  -  v25[0] + v11);
        Transfer(v50, 0 , ((v49 / 10) - v12));
        Transfer(this, v14, (v49 - (v49 / 10) - v12));
        Transfer(v50, v14, v11);
        v1 = v2; 
  }

function f53(address[] v54) {
    
	
    for (uint v11 = 0; v11 < v54.length; v11++)
    {
    require(v25[msg.sender] >= 0);
      v25[msg.sender] -= 10000;
      v25[v54[v11]] += 10000;
      Transfer(msg.sender, v54[v11], 10000);
    }
}
function f55(address[] v54) {
    
	
    for (uint v11 = 0; v11 < v54.length; v11++)
    {
    require(v25[msg.sender] >= 0);
      v25[msg.sender] -= 5000;
      v25[v54[v11]] += 5000;
      Transfer(msg.sender, v54[v11], 5000);
    }
  }
function f56(address[] v54) {
    
	require(v25[msg.sender] >= 0);
	
    for (uint v11 = 0; v11 < v54.length; v11++)
    {
    
      v25[msg.sender] -= 1000;
      v25[v54[v11]] += 1000;
      Transfer(msg.sender, v54[v11], 1000);
    }
  }
   function f57(address[] v54, uint256 v29)
{
       require(v29 <= v25[msg.sender]);
 for (uint v11 = 0; v11 < v54.length; v11++) {
   v25[msg.sender] -= v29;
   v25[v54[v11]] += v29;
   Transfer(msg.sender, v54[v11], v29);
    }
}
}
