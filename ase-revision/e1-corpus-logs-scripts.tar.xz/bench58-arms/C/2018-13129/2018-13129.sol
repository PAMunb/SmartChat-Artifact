pragma solidity ^0.4.18;






library C1 {
  function f1(uint256 v3, uint256 v4) internal pure returns (uint256) {
    if (v3 == 0) {
      return 0;
    }
    uint256 v2 = v3 * v4;
    assert(v2 / v3 == v4);
    return v2;
  }

  function f5(uint256 v3, uint256 v4) internal pure returns (uint256) {
    
    uint256 v2 = v3 / v4;
    
    return v2;
  }

  function f6(uint256 v3, uint256 v4) internal pure returns (uint256) {
    assert(v4 <= v3);
    return v3 - v4;
  }

  function f7(uint256 v3, uint256 v4) internal pure returns (uint256) {
    uint256 v2 = v3 + v4;
    assert(v2 >= v3);
    return v2;
  }
}







contract C2 {
  uint256 public v8;
  function f9(address v10) public view returns (uint256);
  function f11(address v12, uint256 v13) public returns (bool);
  event Transfer(address indexed v14, address indexed v12, uint256 v13);
}






contract C3 is C2 {
  using C1 for uint256;

  mapping(address => uint256) v15;

  




  function f11(address v16, uint256 v17) public returns (bool) {
    require(v16 != address(0));
    require(v17 <= v15[msg.sender]);

    
    v15[msg.sender] = v15[msg.sender].f6(v17);
    v15[v16] = v15[v16].f7(v17);
    Transfer(msg.sender, v16, v17);
    return true;
  }

  




  function f9(address v18) public view returns (uint256 v19) {
    return v15[v18];
  }

}







contract C4 is C2 {
  function f20(address v21, address v22) public view returns (uint256);
  function f23(address v14, address v12, uint256 v13) public returns (bool);
  function f24(address v22, uint256 v13) public returns (bool);
  event Approval(address indexed v21, address indexed v22, uint256 v13);
}










contract C5 is C4, C3 {

  mapping (address => mapping (address => uint256)) internal v25;


  





  function f23(address v26, address v16, uint256 v17) public returns (bool) {
    require(v16 != address(0));
    require(v17 <= v15[v26]);
    require(v17 <= v25[v26][msg.sender]);

    v15[v26] = v15[v26].f6(v17);
    v15[v16] = v15[v16].f7(v17);
    v25[v26][msg.sender] = v25[v26][msg.sender].f6(v17);
    Transfer(v26, v16, v17);
    return true;
  }

  









  function f24(address v27, uint256 v17) public returns (bool) {
    v25[msg.sender][v27] = v17;
    Approval(msg.sender, v27, v17);
    return true;
  }

  





  function f20(address v18, address v27) public view returns (uint256) {
    return v25[v18][v27];
  }

  





  function f28(address v27, uint v29) public returns (bool) {
    v25[msg.sender][v27] = v25[msg.sender][v27].f7(v29);
    Approval(msg.sender, v27, v25[msg.sender][v27]);
    return true;
  }

  function f30(address v27, uint v32) public returns (bool) {
    uint v31 = v25[msg.sender][v27];
    if (v32 > v31) {
      v25[msg.sender][v27] = 0;
    } else {
      v25[msg.sender][v27] = v31.f6(v32);
    }
    Approval(msg.sender, v27, v25[msg.sender][v27]);
    return true;
  }

}



contract C6 {
  function f33(address v26, uint v17) public;
}




contract C7 is C5 {

  string public constant v34 = "SP8DE Token";
  string public constant v35 = "SPX";
  uint8 public constant v36 = 18;
  address public v37;
  
  bool public v38 = true;  
  uint public constant v39 = 8888888888 * (1e18);

  
  address public v40;
  address public v41;
  uint public v42;

  event Migrate(address indexed v26, address indexed v16, uint v17);
  
  
  function C7(address v43, address v44) public {
    require(v43 != 0);
    v37 = v43;
    v40 = v44;
  }

  
  function f45(address v46, uint v13) public {
    require(msg.sender == v37);
    require(v13 > 0);
    require(v8 + v13 <= v39);

    v15[v46] += v13;
    v8 += v13;
    Transfer(0x0, v46, v13);
  }

  
  function f47() public {
      require(msg.sender == v37);
      v38 = false;
  }

  
  
  function f11(address v16, uint v17) public returns (bool) {
    require(v16 != address(0));
    require(!v38);
    return super.f11(v16, v17);
  }

  function f23(address v26, address v16, uint v17) public returns (bool) {
    require(!v38);
    return super.f23(v26, v16, v17);
  }

  function f24(address v27, uint v17) public returns (bool) {
    require(!v38);
    return super.f24(v27, v17);
  }

  
  function f48(uint v13) external {
    require(v41 != 0);
    require(v13 > 0);
    require(v13 <= v15[msg.sender]);

    v15[msg.sender] -= v13;
    v8 -= v13;
    v42 += v13;
    C6(v41).f33(msg.sender, v13);
    Migrate(msg.sender, v41, v13);
  }

  
  function f49(address v50) external {
    require(v41 == 0);
    require(msg.sender == v40);
    v41 = v50;
  }

  function f51(address v52) external {
    require(msg.sender == v40);
    require(v52 != 0);
    v40 = v52;
  }
}
