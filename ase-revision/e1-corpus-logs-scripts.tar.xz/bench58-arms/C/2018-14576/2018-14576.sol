
   


pragma solidity ^0.4.21;
contract C1 {

  address public v1;

  function C1() {
    v1 = msg.sender;
  }

  modifier m2 {
    if (msg.sender != v1) throw;
    _;
  }

  function f3(address v4) m2 {
    v1 = v4;
  }
}

contract C2 { 
  function f5(address v6, uint256 v7, address v8, bytes v9);
} 

contract C3 {

  
  function f10() constant returns (uint256 f10);

  
  
  function f11(address v12) constant returns (uint256 v13) {}

  
  
  
  
  function f14(address v15, uint256 v7) returns (bool v16) {}

  
  
  
  
  
  function f17(address v6, address v15, uint256 v7) returns (bool v16) {}

  
  
  
  
  function f18(address v19, uint256 v7) returns (bool v16) {}

  
  
  
  function f20(address v12, address v19) constant returns (uint256 v21) {}

  event Transfer(address indexed v6, address indexed v15, uint256 v7);
  event Approval(address indexed v12, address indexed v19, uint256 v7);
} 

contract C4 is C3, C1{

  
  string public v22 = "SunContract token v1.0";
  string public v23 = "SunContract";
  string public v24 = "SNC";
  uint8 public v25 = 18;
  address public v26;
  uint256 public v27;

  
  uint256 v28 = 0;
  mapping (address => uint256) v29;
  mapping (address => mapping (address => uint256)) v30;
  mapping (address => bool) v31;

  
  event Mint(address indexed v15, uint256 v7);
  event Burn(address indexed v6, uint256 v7);
  event TokenFrozen(uint256 v32, string v33);

  
  function C4(address v34) {
    v31[0x0] = true;
    v31[v34] = true;
    v31[address(this)] = true;
    v26 = v34;
  }

  
  function f10() constant returns (uint256 f10) {
    return v28;
  }

  
  function f11(address v12) constant returns (uint256 v13) {
    return v29[v12];
  }

  
  function f14(address v15, uint256 v7) returns (bool v16) {
    if (block.number < v27) throw;    
    if (v31[v15]) throw;                
    if (v29[msg.sender] < v7) throw;           
    if (v29[v15] + v7 < v29[v15]) throw;  
    v29[msg.sender] -= v7;                     
    v29[v15] += v7;                            
    Transfer(msg.sender, v15, v7);                  
    return true;
  }

  
  function f18(address v19, uint256 v7) returns (bool v16) {
    if (block.number < v27) throw;    
    v30[msg.sender][v19] = v7;          
    Approval(msg.sender, v19, v7);             
    return true;
  }

   
  function f35(address v19, uint256 v7, bytes v9) returns (bool v16) {            
    C2 v36 = C2(v19);              
    f18(v19, v7);                                      
    v36.f5(msg.sender, v7, this, v9);  
    return true;     
  }     

  
  function f17(address v6, address v15, uint256 v7) returns (bool v16) {      
    if (block.number < v27) throw;    
    if (v31[v15]) throw;                
    if (v29[v6] < v7) throw;                
    if (v29[v15] + v7 < v29[v15]) throw;  
    if (v7 > v30[v6][msg.sender]) throw;  
    v29[v6] -= v7;                          
    v29[v15] += v7;                            
    v30[v6][msg.sender] -= v7;            
    Transfer(v6, v15, v7);                       
    return true;     
  }         

       
  function f20(address v12, address v19) constant returns (uint256 v21) {         
    return v30[v12][v19];
  }         

       
  function f37(address v15, uint256 v38) {         
    if (msg.sender != v26) throw;            
    if (v31[v15]) throw;                    
    if (v29[v15] + v38 < v29[v15]) throw;     
    v28 += v38;                                      
    v29[v15] += v38;                               
    Mint(v15, v38);                                     
    Transfer(0x0, v15, v38);                            
  }     
  
  
  function f39(uint256 v38) m2 {
    if(v29[msg.sender] < v38) throw;               
    if(v28 < v38) throw;                             

    v28 -= v38;                                      
    v29[msg.sender] -= v38;                        
    Burn(msg.sender, v38);                              
    Transfer(msg.sender, 0x0, v38);                     
  }

  
  function f40(uint256 v32, string v33) m2 {      
    v27 = v32;
    TokenFrozen(v32, v33);
  }

  function f41(address v42) constant returns (bool v43){
    return v31[v42];
  }

  
  
  

  
  
  
  

  
  
  
}
