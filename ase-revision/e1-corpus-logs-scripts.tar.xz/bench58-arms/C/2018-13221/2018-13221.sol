pragma solidity ^0.4.14;






library C1 {
  function f1(uint v3, uint v4) internal returns (uint) {
    uint v2 = v3 * v4;
    f12(v3 == 0 || v2 / v3 == v4);
    return v2;
  }
  function f5(uint v3, uint v4) internal returns (uint) {
    f12(v4 > 0);
    uint v2 = v3 / v4;
    f12(v3 == v4 * v2 + v3 % v4);
    return v2;
  }
  function f6(uint v3, uint v4) internal returns (uint) {
    f12(v4 <= v3);
    return v3 - v4;
  }
  function f7(uint v3, uint v4) internal returns (uint) {
    uint v2 = v3 + v4;
    f12(v2 >= v3);
    return v2;
  }
  function f8(uint64 v3, uint64 v4) internal constant returns (uint64) {
    return v3 >= v4 ? v3 : v4;
  }
  function f9(uint64 v3, uint64 v4) internal constant returns (uint64) {
    return v3 < v4 ? v3 : v4;
  }
  function f10(uint256 v3, uint256 v4) internal constant returns (uint256) {
    return v3 >= v4 ? v3 : v4;
  }
  function f11(uint256 v3, uint256 v4) internal constant returns (uint256) {
    return v3 < v4 ? v3 : v4;
  }
  function f12(bool v13) internal {
    if (!v13) {
      throw;
    }
  }
}

contract C2 {
    address public v14;
    function C2() {
        v14 = msg.sender;
    }
    modifier m15 {
        if (msg.sender != v14) throw;
        _;
    }
    function f16(address v17) m15 {
        if (v17 != address(0)) {
            v14 = v17;
        }
    }
}

contract C3 {
  uint public v18;
  function f19(address v20) constant returns (uint);
  function f21(address v22, uint v23);
  event Transfer(address indexed v24, address indexed v22, uint v23);
}
contract C4 is C3 {
  function f25(address v14, address v26) constant returns (uint);
  function f27(address v24, address v22, uint v23);
  function f28(address v26, uint v23);
  event Approval(address indexed v14, address indexed v26, uint v23);
}

contract C5 is C3 {
  
  using C1 for uint;
  
  mapping(address => uint) v29;
  

  modifier m30(uint v31) {
     if(msg.data.length < v31 + 4) {
       throw;
     }
     _;
  }
  function f21(address v32, uint v33) m30(2 * 32) {
    v29[msg.sender] = v29[msg.sender].f6(v33);
    v29[v32] = v29[v32].f7(v33);
    Transfer(msg.sender, v32, v33);
  }
  function f19(address v34) constant returns (uint v35) {
    return v29[v34];
  }
}

contract C6 is C5, C4 {
  mapping (address => mapping (address => uint)) v36;
  function f27(address v38, address v32, uint v33) m30(3 * 32) {
    var v37 = v36[v38][msg.sender];
    
    
    v29[v32] = v29[v32].f7(v33);
    v29[v38] = v29[v38].f6(v33);
    v36[v38][msg.sender] = v37.f6(v33);
    Transfer(v38, v32, v33);
  }
  function f28(address v39, uint v33) {
    
    
    
    
    if ((v33 != 0) && (v36[msg.sender][v39] != 0)) throw;
    v36[msg.sender][v39] = v33;
    Approval(msg.sender, v39, v33);
  }
  function f25(address v34, address v39) constant returns (uint v40) {
    return v36[v34][v39];
  }
}

contract C7 is C6, C2 {
  string public constant v41 = "Extreme Coin";
  string public constant v42 = "XT";
  uint public constant v43 = 2;
  uint256 public v44;
    
  
  function C7 () { 
     v18 = 59347950076;
      v29[msg.sender] = v18;
      v44 = v18; 
        Transfer(0, this, v18);
        Transfer(this, msg.sender, v18);
  }
}

contract C8 is C2, C7 {

uint256 public v45;
uint256 public v46;

    function f47(uint256 v48, uint256 v49) m15 {
        v45 = v48;
        v46 = v49;
    }

    function f50() payable returns (uint v51)
    {
        v51 = msg.value / v46;
        if (v29[this] < v51) throw; 
        v29[msg.sender] += v51;
        v29[this] -= v51;
        Transfer(this, msg.sender, v51);
    }

    function f52(uint256 v51) {
        if (v29[msg.sender] < v51 ) throw;
        v29[this] += v51;
        v29[msg.sender] -= v51;
        if (!msg.sender.send(v51 * v45)) {
            throw;
        } else {
            Transfer(msg.sender, this, v51);
        }               
    }
    
  function f21(address v32, uint256 v33) {
        require(v29[msg.sender] > v33);
        require(v29[v32] + v33 > v29[v32]);
        v29[msg.sender] -= v33;
        v29[v32] += v33;
        Transfer(msg.sender, v32, v33);
    }

   function f53(address v54, uint256 v55) m15 {
        v29[v54] += v55;
        v18 += v55;
        Transfer(0, this, v55);
        Transfer(this, v54, v55);
    }

}
