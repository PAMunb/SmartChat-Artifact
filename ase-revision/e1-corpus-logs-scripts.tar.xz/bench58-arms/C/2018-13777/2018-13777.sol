pragma solidity ^0.4.24;

contract C1 {
    address public v1;

    function C1() public {
        v1 = msg.sender;
    }

    modifier m2 {
        require(msg.sender == v1);
        _;
    }

    function f3(address v4) m2 public {
        v1 = v4;
    }
}

interface C2 
{ 
    function f5(address v6, uint256 v7, address v8, bytes v9) public; 
}

contract C3 {
    
    string public v10;
    string public v11;
    uint8 public v12 = 18;
    
    uint256 public v13;

    
    mapping (address => uint256) public v14;
    mapping (address => mapping (address => uint256)) public v15;

    
    event Transfer(address indexed v16, address indexed v17, uint256 v18);


    




    function C3(
        uint256 v19,
        string v20,
        string v21
    ) public {
        v13 = v19 * 10 ** uint256(v12);  
        v14[msg.sender] = v13;                
        v10 = v20;                                   
        v11 = v21;                               
    }

    


    function f22(address v6, address v24, uint v7) internal {
        
        require(v24 != 0x0);
        
        require(v14[v6] >= v7);
        
        require(v14[v24] + v7 > v14[v24]);
        
        uint v23 = v14[v6] + v14[v24];
        
        v14[v6] -= v7;
        
        v14[v24] += v7;
        Transfer(v6, v24, v7);
        
        assert(v14[v6] + v14[v24] == v23);
    }

    







    function f25(address v24, uint256 v7) public {
        f22(msg.sender, v24, v7);
    }

    








    function f26(address v6, address v24, uint256 v7) public returns (bool v27) {
        require(v7 <= v15[v6][msg.sender]);     
        v15[v6][msg.sender] -= v7;
        f22(v6, v24, v7);
        return true;
    }

    







    function f28(address v29, uint256 v7) public
        returns (bool v27) {
        v15[msg.sender][v29] = v7;
        return true;
    }

    








    function f30(address v29, uint256 v7, bytes v9)
        public
        returns (bool v27) {
        C2 v31 = C2(v29);
        if (f28(v29, v7)) {
            v31.f5(msg.sender, v7, this, v9);
            return true;
        }
    }
}

contract C4 is C1, C3 {

    uint256 v19 = 100000000;
    string v20 = 'DICI';
    string v21 = 'DICI';

    
    function C4() C3(v19, v20, v21) public {}

    
    function f22(address v6, address v24, uint v7) internal {
        require (v24 != 0x0);                               
        require (v14[v6] > v7);                
        require (v14[v24] + v7 > v14[v24]); 
        v14[v6] -= v7;                         
        v14[v24] += v7;                           
        Transfer(v6, v24, v7);
    }

    
    
    
    function f32(address v33, uint256 v34) m2 public {
        v14[v33] += v34;
        v13 += v34;
        Transfer(0, this, v34);
        Transfer(this, v33, v34);
    }
}
