pragma solidity ^0.4.14;





contract C1 {
  function f1(uint v3, uint v4) internal returns (uint) {
    uint v2 = v3 * v4;
    f12(v3 == 0 || v2 / v3 == v4);
    return v2;
  }

  function f5(uint v3, uint v4) internal returns (uint) {
    f12(v4 > 0);
    uint v2 = v3 / v4;
    f12(v3 == v4 * v2 + v3 % v4);
    return v2;
  }

  function f6(uint v3, uint v4) internal returns (uint) {
    f12(v4 <= v3);
    return v3 - v4;
  }

  function f7(uint v3, uint v4) internal returns (uint) {
    uint v2 = v3 + v4;
    f12(v2>=v3 && v2>=v4);
    return v2;
  }

  function f8(uint64 v3, uint64 v4) internal constant returns (uint64) {
    return v3 >= v4 ? v3 : v4;
  }

  function f9(uint64 v3, uint64 v4) internal constant returns (uint64) {
    return v3 < v4 ? v3 : v4;
  }

  function f10(uint256 v3, uint256 v4) internal constant returns (uint256) {
    return v3 >= v4 ? v3 : v4;
  }

  function f11(uint256 v3, uint256 v4) internal constant returns (uint256) {
    return v3 < v4 ? v3 : v4;
  }

  function f12(bool v13) internal {
    if (!v13) {
      throw;
    }
  }
}




contract C2 {
  uint public v14;
  function f15(address v16) constant returns (uint);
  function f17(address v18, address v19) constant returns (uint);

  function f20(address v21, uint v22) returns (bool v23);
  function f24(address v25, address v21, uint v22) returns (bool v23);
  function f26(address v19, uint v22) returns (bool v23);
  event Transfer(address indexed v25, address indexed v21, uint v22);
  event Approval(address indexed v18, address indexed v19, uint v22);
}




contract C3 is C2, C1 {

  
  event Minted(address v27, uint v28);

  
  mapping(address => uint) v29;

  
  mapping (address => mapping (address => uint)) v30;

  
  function f31() public constant returns (bool v32) {
    return true;
  }

  function f20(address v33, uint v34) returns (bool v35) {
      
    v29[msg.sender] = f6(v29[msg.sender], v34);
    v29[v33] = f7(v29[v33], v34);
    Transfer(msg.sender, v33, v34);
    return true;
  }

  function f24(address v37, address v33, uint v34) returns (bool v35) {
      
    uint v36 = v30[v37][msg.sender];

    v29[v33] = f7(v29[v33], v34);
    v29[v37] = f6(v29[v37], v34);
    v30[v37][msg.sender] = f6(v36, v34);
    Transfer(v37, v33, v34);
    return true;
  }

  function f15(address v38) constant returns (uint v39) {
    return v29[v38];
  }

  function f26(address v40, uint v34) returns (bool v35) {

    
    
    
    
    if ((v34 != 0) && (v30[msg.sender][v40] != 0)) throw;

    v30[msg.sender][v40] = v34;
    Approval(msg.sender, v40, v34);
    return true;
  }

  function f17(address v38, address v40) constant returns (uint v41) {
    return v30[v38][v40];
  }

}







contract C4 is C3 {
  
    
    uint256 public v42 = 0;
    uint256 public v43 = 0;
    
    address public v18 = msg.sender;
    address public v44 = 0xB5D39A8Ea30005f9114Bf936025De2D6f353813E;
    address public v45 = 0x00A591199F53907480E1f5A00958b93B43200Fe4;
    address public v46 = 0x0d19C131400e73c71bBB2bC1666dBa8Fe22d242D;
    
	uint256 public v47;
  
    string public constant v48 = "CTest7 Token";
    string public constant v49 = "CTest7";
    uint8 public constant v50 = 18;  
	


  function f51(address v27, uint v28) public {
      
      v47 = ((msg.value*v42)/(1 ether));
    
    if (v47 != v28 || v28 == 0 || v27 != msg.sender)
    {
        revert();
    }
    

    v14 = v14 + (v28*1 ether);
    v29[v27] += (v28*1 ether);

    
    
    Transfer(0, v27, (v28*1 ether));
  }

  
  
	
	
    function () payable {
             
            
            uint256 v52 = v14;
            v14 = (v14/1 ether);
            
            
            
            
            if (v14 > 999999)
            {
                revert();
            }
            

            
            
            
            if (v14 < 25000)
            {
                v42 = 3340;
            }
            
            
            
            if (v14 >= 25000)
            {
                v42 = 668;
            }
            
            
            
            if (v14 >= 125000)
            {
                v42 = 334;
            }
            
            
            
            if (v14 >= 525000)
            {
                v42 = 134;
            }
            
            
           
            
            v47 = 0;
            v47 = ((msg.value*v42)/(1 ether));
            
            
            
            if (v47 < 0)
            {
                revert();
            }
            
            
            
            v43 = 0;
            
            v43 = f7(v14, v47);
            
            if (v43 > 1000000)
            {
                revert();
            }
            
            
            
            if (v14 < 25000 && v43 > 25000)
            {
                revert();
            }
            
            
            if (v14 < 125000 && v43 > 125000)
            {
                revert();
            }
            
            
            if (v14 < 525000 && v43 > 525000)
            {
                revert();
            }
            
            
            
            uint256 v53 = (v29[msg.sender]/1 ether);
            if ((v53 + v47) > 50 && v14 < 25000)
            {
                revert();
            }
            
    
            v14 = v52;
        	f51(msg.sender, v47);
        	v47 = 0;							
        	v43 = 0;
        	v42 = 0;
        		
        		
        	v44.transfer((msg.value/3));					
        	v45.transfer((msg.value/3));					
        	v46.transfer((msg.value/3));					
    
    }


    
    
    function f54 () {
        
        if (msg.sender == v18 && v14 < 1000000)
        {
            v14 = 1000000;
        } else {throw;}

    }
  
  
  
}
