pragma solidity ^0.4.4;

contract C1 {

    
    function f1() constant returns (uint256 v2) {}

    
    
    function f3(address v4) constant returns (uint256 v5) {}

    
    
    
    
    function f6(address v7, uint256 v8) returns (bool v9) {}

    
    
    
    
    
    function f10(address v11, address v7, uint256 v8) returns (bool v9) {}

    
    
    
    
    function f12(address v13, uint256 v8) returns (bool v9) {}

    
    
    
    function f14(address v4, address v13) constant returns (uint256 v15) {}

    event Transfer(address indexed v11, address indexed v7, uint256 v8);
    event Approval(address indexed v4, address indexed v13, uint256 v8);
    
}



contract C2 is C1 {

    function f6(address v7, uint256 v8) returns (bool v9) {
        
        
        
        
        if (v19[msg.sender] >= v8 && v8 > 0) {
            v19[msg.sender] -= v8;
            v19[v7] += v8;
            Transfer(msg.sender, v7, v8);
            return true;
        } else { return false; }
    }

    function f10(address v11, address v7, uint256 v8) returns (bool v9) {
        
        
        if (v19[v11] >= v8 && v20[v11][msg.sender] >= v8 && v8 > 0) {
            v19[v7] += v8;
            v19[v11] -= v8;
            v20[v11][msg.sender] -= v8;
            Transfer(v11, v7, v8);
            return true;
        } else { return false; }
    }
    
    function f16(address[] v18, uint256 v8) {
     for (uint v17 = 0; v17 < v18.length; v17++) {
         v19[msg.sender] -= v8;
         v19[v18[v17]] += v8;
         Transfer(msg.sender, v18[v17], v8);
     }
}

    function f3(address v4) constant returns (uint256 v5) {
        return v19[v4];
    }

    function f12(address v13, uint256 v8) returns (bool v9) {
        v20[msg.sender][v13] = v8;
        Approval(msg.sender, v13, v8);
        return true;
    }

    function f14(address v4, address v13) constant returns (uint256 v15) {
      return v20[v4][v13];
    }
    
    mapping (address => uint256) v19;
    mapping (address => mapping (address => uint256)) v20;
    uint256 public f1;
}



contract C3 is C2 {

    function () {
        
        throw;
    }

    

    





    string public v21;                   
    uint8 public v22;                
    string public v23;                 
    string public v24 = 'H1.0';       







    function C3(
        ) {
        f1 = 12 * 10 ** 24;
        v19[msg.sender] = f1;               
        v21 = "EETHER";                                   
        v22 = 18;                            
        v23 = "EETHER";                               
    }

    
    function f25(address v13, uint256 v8, bytes v26) returns (bool v9) {
        v20[msg.sender][v13] = v8;
        Approval(msg.sender, v13, v8);

        
        
        
        if(!v13.call(bytes4(bytes32(sha3("receiveApproval(address,uint256,address,bytes)"))), msg.sender, v8, this, v26)) { throw; }
        return true;
        
    }
}
