pragma solidity ^0.4.21;
contract C1{
    
    uint256 public v1;

    
    function f2(address v3) constant returns (uint256 v4);

    
    function f5(address v6, uint256 v7) returns (bool v8);

    
    function f9(address v10, address v6, uint256 v7) returns   
    (bool v8);

    
    function f11(address v12, uint256 v7) returns (bool v8);

    
    function f13(address v3, address v12) constant returns 
    (uint256 v14);

    
    event Transfer(address indexed v10, address indexed v6, uint256 v7);

    
    event Approval(address indexed v3, address indexed v12, uint256 
    v7);
}

contract C2 is C1 {
    function f5(address v6, uint256 v7) returns (bool v8) {
        
        
        
        require(v15[msg.sender] >= v7);
        v15[msg.sender] -= v7;
        v15[v6] += v7;
        Transfer(msg.sender, v6, v7);
        return true;
    }


    function f9(address v10, address v6, uint256 v7) returns 
    (bool v8) {
        
        
        require(v15[v10] >= v7 && v16[v10][msg.sender] >= v7);
        v15[v6] += v7;
        v15[v10] -= v7; 
        v16[v10][msg.sender] -= v7;
        Transfer(v10, v6, v7);
        return true;
    }
    function f2(address v3) constant returns (uint256 v4) {
        return v15[v3];
    }


    function f11(address v12, uint256 v7) returns (bool v8)   
    {
        v16[msg.sender][v12] = v7;
        Approval(msg.sender, v12, v7);
        return true;
    }


    function f13(address v3, address v12) constant returns (uint256 v14) {
        return v16[v3][v12];
    }
    mapping (address => uint256) v15;
    mapping (address => mapping (address => uint256)) v16;
}

contract C3 is C2 { 

    
    string public v17;                   
    uint8 public v18;               
    string public v19;               
    string public v20 = 'H0.1';    

    function C3(uint256 v21, string v22, uint8 v23, string v24) {
        v15[msg.sender] = v21; 
        v1 = v21;         
        v17 = v22;                   
        v18 = v23;           
        v19 = v24;             
    }

    
    
    function f25(address v12, uint256 v7, bytes v26) returns (bool v8) {
        v16[msg.sender][v12] = v7;
        Approval(msg.sender, v12, v7);
        
        
        
        require(v12.call(bytes4(bytes32(sha3("receiveApproval(address,uint256,address,bytes)"))), msg.sender, v7, this, v26));
        return true;
    }

}
