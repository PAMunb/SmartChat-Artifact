pragma solidity ^0.4.2;

contract C1 {

    function f1(address v2) constant returns (uint256 v3);
    function f4(address v5, uint256 v6) returns (bool v7);
    function f8(address v9, address v5, uint256 v6) returns (bool v7);
    function f10(address v11, uint256 v6) returns (bool v7);
    function f12(address v2, address v11) constant returns (uint256 v13);

    
    event Transfer(address indexed v9, address indexed v5, uint256 v6);

    
    event Approval(address indexed v2, address indexed v11, uint256 v6);

}

contract C2 {
    
    address public v14;

    
    function C2() {
        v14 = msg.sender;
    }

    
    modifier m15() {
        if(msg.sender != v14) throw;
        
        _;
    }
    
    function f16(address v17) m15 {
        v14 = v17;
    }
}

contract C3 is C1,C2 {

    
    string  public v18;
    string  public v19;
    uint8   public v20;
    uint256 public v21;
    
    
    mapping(address => uint256) v22;
    
    mapping (address => bool) public v23;
    
    mapping(address => mapping (address => uint256)) v24;
    
    
    event FrozenFunds(address v25, bool v26);
    
    
    function C3(uint256 v27, string v28, string v29, uint8 v30) {
        v22[msg.sender]  = v27;
        v18                  = v28;
        v19                = v29;
        v20              = v30;
        v21           = v27;
    }

    
    function f1(address v2) constant returns (uint256 v3) {
        return v22[v2];
    }

    
    function f4(address v31, uint v32) returns (bool v7) {

        
        if (v23[msg.sender]) return false;

        
        if(v22[msg.sender] < v32) return false;
        
        if(v22[v31] + v32 < v22[v31]) return false;
        
        
        v22[msg.sender] -= v32;
        
        v22[v31] += v32;
        
        
        Transfer(msg.sender, v31, v32);

        return true;
    }


    
    function f8(address v33, address v31, uint v32) returns (bool v7) {

        
        if (v23[msg.sender]) return false;

        
        if(v22[v33] < v32) return false;

        
        if( v24[v33][msg.sender] >= v32 ) return false;

        
        if(v22[v31] + v32 < v22[v31]) return false;
        
        v22[v33] -= v32;
        v24[v33][msg.sender] -= v32;
        v22[v31] += v32;
        
        
        Transfer(v33, v31, v32);

        return true;
    }

    
    function f12(address v2, address v11) constant returns (uint256 v13) {
        return v24[v2][v11];
    }

    
    function f10(address v11, uint256 v34) returns (bool v7) {
        v24[msg.sender][v11] = v34;
        Approval(msg.sender, v11, v34);
        return true;
    }
    
    
    function f35(address v25, uint256 v36) m15{
        v22[v25] += v36;
        v21 += v36;
        
        Transfer(0,v14,v36);
        Transfer(v14,v25,v36);
    }

    
    function f37(address v25, bool v38) m15 {
        v23[v25] = v38;
        FrozenFunds(v25, v38);
    }

    
    function f39(string v28) m15 {
        v18 = v28;
    }

    
    function f40(string v29) m15 {
        v19 = v29;
    }

    
    function f41(uint8 v42) m15 {
        v20 = v42;
    }
}
