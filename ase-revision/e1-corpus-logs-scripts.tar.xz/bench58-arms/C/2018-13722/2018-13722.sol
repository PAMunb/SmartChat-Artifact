pragma solidity ^0.4.24;





contract C1 {
  uint public v1;
  function f2(address v3) constant returns (uint);
  function f4(address v5, address v6) constant returns (uint);

  function f7(address v8, uint v9) returns (bool v10);
  function f11(address v12, address v8, uint v9) returns (bool v10);
  function f13(address v6, uint v9) returns (bool v10);
  event Transfer(address indexed v12, address indexed v8, uint v9);
  event Approval(address indexed v5, address indexed v6, uint v9);
}






contract C2 {
  function f14(uint v16, uint v17) internal returns (uint) {
    uint v15 = v16 * v17;
    f25(v16 == 0 || v15 / v16 == v17);
    return v15;
  }

  function f18(uint v16, uint v17) internal returns (uint) {
    f25(v17 > 0);
    uint v15 = v16 / v17;
    f25(v16 == v17 * v15 + v16 % v17);
    return v15;
  }

  function f19(uint v16, uint v17) internal returns (uint) {
    f25(v17 <= v16);
    return v16 - v17;
  }

  function f20(uint v16, uint v17) internal returns (uint) {
    uint v15 = v16 + v17;
    f25(v15>=v16 && v15>=v17);
    return v15;
  }

  function f21(uint64 v16, uint64 v17) internal constant returns (uint64) {
    return v16 >= v17 ? v16 : v17;
  }

  function f22(uint64 v16, uint64 v17) internal constant returns (uint64) {
    return v16 < v17 ? v16 : v17;
  }

  function f23(uint256 v16, uint256 v17) internal constant returns (uint256) {
    return v16 >= v17 ? v16 : v17;
  }

  function f24(uint256 v16, uint256 v17) internal constant returns (uint256) {
    return v16 < v17 ? v16 : v17;
  }

  function f25(bool v26) internal {
    if (!v26) {
      throw;
    }
  }
}









contract C3 is C1, C2 {

  
  event Minted(address v27, uint v28);

  
  mapping(address => uint) v29;

  
  mapping (address => mapping (address => uint)) v30;

  





  modifier m31(uint v32) {
     if(msg.data.length != v32 + 4) {
       throw;
     }
     _;
  }

  function f7(address v33, uint v34) m31(2 * 32) returns (bool v35) {
    v29[msg.sender] = f19(v29[msg.sender], v34);
    v29[v33] = f20(v29[v33], v34);
    Transfer(msg.sender, v33, v34);
    return true;
  }

  function f11(address v37, address v33, uint v34) returns (bool v35) {
    uint v36 = v30[v37][msg.sender];

    
    

    v29[v33] = f20(v29[v33], v34);
    v29[v37] = f19(v29[v37], v34);
    v30[v37][msg.sender] = f19(v36, v34);
    Transfer(v37, v33, v34);
    return true;
  }

  function f2(address v38) constant returns (uint v39) {
    return v29[v38];
  }

  function f13(address v40, uint v34) returns (bool v35) {

    
    
    
    
    if ((v34 != 0) && (v30[msg.sender][v40] != 0)) throw;

    v30[msg.sender][v40] = v34;
    Approval(msg.sender, v40, v34);
    return true;
  }

  function f4(address v38, address v40) constant returns (uint v41) {
    return v30[v38][v40];
  }

  





  function f42(address v40, uint v44)
  m31(2 * 32)
  returns (bool v35) {
      uint v43 = v30[msg.sender][v40];
      v30[msg.sender][v40] = f20(v43, v44);
      Approval(msg.sender, v40, v30[msg.sender][v40]);
      return true;
  }

  




  function f45(address v40, uint v47)
  m31(2 * 32)
  returns (bool v35) {

      uint v46 = v30[msg.sender][v40];

      if (v47 > v46) {
          v30[msg.sender][v40] = 0;
      } else {
          v30[msg.sender][v40] = f19(v46, v47);
      }
      Approval(msg.sender, v40, v30[msg.sender][v40]);
      return true;
  }

}



contract C4 is C3 {

  address public constant v48 = 0;

  
  event Burned(address v49, uint v50);

  



  function f51(uint v52) {
    address v49 = msg.sender;
    v29[v49] = f19(v29[v49], v52);
    v1 = f19(v1, v52);
    Burned(v49, v52);
  }
}











contract C5 {

  uint public v53;

  
  function f54() public constant returns (bool) {
    return true;
  }

  function f55(address v37, uint256 v34) public;

}







contract C6 is C3 {

  
  address public v56;

  
  C5 public v57;

  
  uint256 public v58;

  








  enum UpgradeState {Unknown, NotAllowed, WaitingForAgent, ReadyToUpgrade, Upgrading}

  


  event Upgrade(address indexed v37, address indexed v33, uint256 v34);

  


  event UpgradeAgentSet(address v59);

  


  function C6(address v60) {
    v56 = v60;
  }

  


  function f61(uint256 v9) public {

      UpgradeState v62 = f64();
      if(!(v62 == UpgradeState.ReadyToUpgrade || v62 == UpgradeState.Upgrading)) {
        
        throw;
      }

      
      if (v9 == 0) throw;

      v29[msg.sender] = f19(v29[msg.sender], v9);

      
      v1 = f19(v1, v9);
      v58 = f20(v58, v9);

      
      v57.f55(msg.sender, v9);
      Upgrade(msg.sender, v57, v9);
  }

  


  function f63(address v59) external {

      if(!f67()) {
        
        throw;
      }

      if (v59 == 0x0) throw;
      
      if (msg.sender != v56) throw;
      
      if (f64() == UpgradeState.Upgrading) throw;

      v57 = C5(v59);

      
      if(!v57.f54()) throw;
      
      if (v57.v53() != v1) throw;

      UpgradeAgentSet(v57);
  }

  


  function f64() public constant returns(UpgradeState) {
    if(!f67()) return UpgradeState.NotAllowed;
    else if(address(v57) == 0x00) return UpgradeState.WaitingForAgent;
    else if(v58 == 0) return UpgradeState.ReadyToUpgrade;
    else return UpgradeState.Upgrading;
  }

  




  function f65(address v66) public {
      if (v66 == 0x0) throw;
      if (msg.sender != v56) throw;
      v56 = v66;
  }

  


  function f67() public constant returns(bool) {
     return true;
  }

}


contract C7 is C4, C6 {

  string public v68;
  string public v69;
  uint public v70;
  address public v5;

  
  mapping (address => bool) public v71;

  event MintingAgentChanged(address v72, bool v62);

  




  function f73(address v27, uint v28) m75 public {
    v1 = v1 + v28;
    v29[v27] = v29[v27] + v28;

    
    
    Transfer(0, v27, v28);
  }

  


  function f74(address v72, bool v62) m76 public {
    v71[v72] = v62;
    MintingAgentChanged(v72, v62);
  }

  modifier m75() {
    
    if(!v71[msg.sender]) {
        throw;
    }
    _;
  }

  modifier m76() {
    if (msg.sender != v5) {
      throw;
    }
    _;
  }

  function C7(address v38, string v77, string v78, uint v79, uint v80) C6(v38) {
    v68 = v77;
    v69 = v78;
    v1 = v79;
    v70 = v80;

    
    v29[v38] = v79;
    v5 = v38;
  }
}
