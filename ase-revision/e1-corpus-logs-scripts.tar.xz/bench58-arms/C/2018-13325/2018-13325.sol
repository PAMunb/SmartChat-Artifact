pragma solidity ^0.4.18;
interface C1{
    function f1(address v2,uint256 v3,address v4,bytes v5) external ;
}
contract C2{
    
    address public v6;
    string public v7;
    string public v8;
    uint8 public v9;
    uint256 public v10;
    uint256 public v11; 
    uint256 public v12;
    bool public v13;
    bool public v14;
    
    
    mapping(address => uint256) public v15;
    
    mapping(address => mapping(address => uint256)) public v16;
    
    mapping(address=>bool) public v17;
    
    
    event Transfer(address indexed v18,address indexed v19 , uint256 v20);
    
    event Approval(address indexed v6,address indexed v21,uint256 v20);
    
    event FrozenFunds(address v22,bool v23);
    
    event SellToken(address v24,uint256 v11, uint256 v25,uint256 v26);
    
    event BuyToken(address v27,uint256 v12,uint256 v25,uint256 v28);
    
    modifier m29 {
        require(msg.sender == v6);
        _;
    }
    
    function C2() public {
        v6 = 0x757D7FbB9822b5033a6BBD4e17F95714942f921f;
        v7 = "GROWCHAIN";
        v8 = "GROW";
        v9 = 8;
        v10 = 5000000000 * 10 ** uint256(8);
        
        
        v15[v6] = v10;
    }
    
 function () public payable {  
     if(msg.sender!=v6){
         f50();    
     }
 }
 
    
    
    function f30(address v31,uint256 v3) public{
        require(!v17[msg.sender]);
        if(v31 == address(this)){
          f51(msg.sender,v3);
        }else{
            f48(msg.sender,v31,v3);
        }
    }
    
    
    function f32(address v2,address v31,uint256 v3) public returns (bool v33){
        
        require(!v17[v2]&&!v17[msg.sender]);
        require(v3<=v16[v2][msg.sender]);
        
        v16[v2][msg.sender] -= v3;
        if(v31 == address(this)){
            f51(v2,v3);
        }else
        {
            f48(v2,v31,v3);
        }
        
        return true;
    }
    
    
    
    
    
    function f34(address v35,uint256 v3) public returns (bool v33){
        require(!v17[msg.sender]);
        v16[msg.sender][v35] = v3;
        return true;
    }
    
    function f36(address v35,uint256 v3,bytes v5)
    public returns (bool v33){
        require(!v17[msg.sender]);
        C1 v21 = C1(v35);
        if(f34(v35,v3)){
            v21.f1(msg.sender,v3,this,v5);
            return true;
        }
    }
    
    
    
    function f37(address v22,bool v23)  m29 public{
        require(v22!=v6);
        v17[v22] = v23;
        FrozenFunds(v22,v23);
    }
    
    function f38(address v39) m29 public{
        f48(v6,v39,v15[v6]);
        v6 = v39;
    }
    
    function f40(uint256 v41,uint256 v42) m29 public{
        v11 = v41;
        v12 = v42;
    }
    
    function f43(bool v44) m29 public{
        require(v12>0);
        v14 = v44;
    }
    
    function f45(bool v46) m29 public{
        require(v11>0);
        v13 = v46;
    }
    
    function f47(uint256 v25) m29 public{
        msg.sender.transfer(v25*10**uint256(18));
    }
    
    
 
    function f48(address v2,address v31, uint256 v3) internal {
        
        require(v31 != 0x0);
        require(v15[v2] >= v3);
        require(v15[v31] + v3 >v15[v31]);
        uint256 v49 = v15[v2]+v15[v31];
        
        v15[v2] -= v3;
        v15[v31] += v3;
        
        Transfer(v2,v31,v3);
        assert(v15[v2]+v15[v31] == v49);
    }
 
    function f50() internal returns (uint256 v25){
        require(v14);
        require(v12>0);
        require(msg.value>0);
        v25 = msg.value / v12;                    
        f48(v6,msg.sender,v25);
        BuyToken(msg.sender,v12,v25,msg.value);
        return v25;                                    
    }
    
    
    function f51(address v2,uint256 v25) internal returns (uint256 v52){
        require(v13);
        require(!v17[v2]);
        require(v25>0);
        require(v11>0);
        require(v2!=v6);
        f48(v2,v6,v25);
        v52 = v25 * v11;
        v2.transfer(v52);                     
        SellToken(v2,v11,v25,v52);
        return v52;                                   
    }
}
