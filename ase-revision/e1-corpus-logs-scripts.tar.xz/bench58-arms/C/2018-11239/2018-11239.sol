pragma solidity ^0.4.18;

contract C1 {
  
  string public constant v1 = "Hexagon";
  string public constant v2 = "HXG";
  uint8 public constant v3 = 4;
  uint8 public constant v4 = 2;
  uint256 public constant v5 = 420000000000000;
  uint256 public v6 = v5;

  
  mapping (address => uint256) public v7;
  
  mapping (address => mapping (address => uint256)) public v8;

  
  function C1() public {
    
    v7[msg.sender] = v5;
  }

  
  
  function f9(address v10, uint256 v11) public returns (bool v12) {
    f19(msg.sender, v10, v11);

    return true;
  }

  
  function f13() public constant returns (uint) {
    return v6;
  }

  
  function f14(uint256 v11) public returns (bool v12) {
    
    require(v7[msg.sender] >= v11);
    
    v7[msg.sender] -= v11;
    
    v7[0x0] += v11;
    
    v6 -= v11;
    
    Burn(msg.sender, v11);

    return true;
  }

  
  function f15(address v16, uint256 v11) public returns (bool v12) {
    
    require(v11 == 0 || v8[msg.sender][v16] == 0);
    
    v8[msg.sender][v16] = v11;
    
    Approval(msg.sender, v16, v11);

    return true;
  }

  
  function f17(address v18, address v10, uint256 v11) public returns (bool v12) {
    
    require(v8[v18][msg.sender] >= v11);
    
    v8[v18][msg.sender] -= v11;

    f19(v18, v10, v11);

    return true;
  }

  
  function f19(address v18, address v10, uint v11) internal {
    
    require (v10 != 0x0);
    
    require (v7[v18] >= v11 + v4);
    
    require (v7[v10] + v11 > v7[v10]);
    
    v7[v18] -= v11 + v4;
    
    v7[v10] += v11;
    
    v7[0x0] += v4;
    
    v6 -= v4;
    
    Burn(v18, v4);
    
    Transfer(v18, v10, v11);
  }

  
  event Transfer(address indexed v20, address indexed v21, uint256 v22);
  event Burn(address indexed v20, uint256 v22);
  event Approval(address indexed v23, address indexed v16, uint256 v11);
}