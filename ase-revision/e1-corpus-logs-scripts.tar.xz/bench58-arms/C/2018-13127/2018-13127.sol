pragma solidity ^0.4.19;






contract C1 {
  uint256 public v1;
  function f2(address v3) public view returns (uint256);
  function f4(address v5, uint256 v6) public returns (bool);
  event Transfer(address indexed v7, address indexed v5, uint256 v6);
}






library C2 {
  function f8(uint256 v10, uint256 v11) internal pure returns (uint256) {
    if (v10 == 0) {
      return 0;
    }
    uint256 v9 = v10 * v11;
    assert(v9 / v10 == v11);
    return v9;
  }

  function f12(uint256 v10, uint256 v11) internal pure returns (uint256) {
    
    uint256 v9 = v10 / v11;
    
    return v9;
  }

  function f13(uint256 v10, uint256 v11) internal pure returns (uint256) {
    assert(v11 <= v10);
    return v10 - v11;
  }

  function f14(uint256 v10, uint256 v11) internal pure returns (uint256) {
    uint256 v9 = v10 + v11;
    assert(v9 >= v10);
    return v9;
  }
}






contract C3 is C1 {
  using C2 for uint256;

  mapping(address => uint256) v15;

  




  function f4(address v16, uint256 v17) public returns (bool) {
    require(v16 != address(0));
    require(v17 <= v15[msg.sender]);

    
    v15[msg.sender] = v15[msg.sender].f13(v17);
    v15[v16] = v15[v16].f14(v17);
    Transfer(msg.sender, v16, v17);
    return true;
  }

  




  function f2(address v18) public view returns (uint256 v19) {
    return v15[v18];
  }

}









contract C4 is C1 {
  function f20(address v21, address v22) public view returns (uint256);
  function f23(address v7, address v5, uint256 v6) public returns (bool);
  function f24(address v22, uint256 v6) public returns (bool);
  event Approval(address indexed v21, address indexed v22, uint256 v6);
}










contract C5 is C4, C3 {

  mapping (address => mapping (address => uint256)) internal v25;


  





  function f23(address v26, address v16, uint256 v17) public returns (bool) {
    require(v16 != address(0));
    require(v17 <= v15[v26]);
    require(v17 <= v25[v26][msg.sender]);

    v15[v26] = v15[v26].f13(v17);
    v15[v16] = v15[v16].f14(v17);
    v25[v26][msg.sender] = v25[v26][msg.sender].f13(v17);
    Transfer(v26, v16, v17);
    return true;
  }

  









  function f24(address v27, uint256 v17) public returns (bool) {
    v25[msg.sender][v27] = v17;
    Approval(msg.sender, v27, v17);
    return true;
  }

  





  function f20(address v18, address v27) public view returns (uint256) {
    return v25[v18][v27];
  }

  





  function f28(address v27, uint v29) public returns (bool) {
    v25[msg.sender][v27] = v25[msg.sender][v27].f14(v29);
    Approval(msg.sender, v27, v25[msg.sender][v27]);
    return true;
  }

  function f30(address v27, uint v32) public returns (bool) {
    uint v31 = v25[msg.sender][v27];
    if (v32 > v31) {
      v25[msg.sender][v27] = 0;
    } else {
      v25[msg.sender][v27] = v31.f13(v32);
    }
    Approval(msg.sender, v27, v25[msg.sender][v27]);
    return true;
  }

}




contract C6 is C5 {

  string public constant v33 = "SP8DE PreSale Token";
  string public constant v34 = "DSPX";
  uint8 public constant v35 = 18;
  address public v36;
  address public v37;
  bool public v38 = true;  
  uint public constant v39 = 888888888 * (1e18);

  
  function C6(address v40, address v41) {
      require(v40 != address(0));
      require(v41 != address(0));
      v36 = v40;
      v37 = v41;
  }

  
  function f42(address v43, uint v6) {
    require(msg.sender == v36);
    require(v6 > 0);
    require(v1 + v6 <= v39);

    v15[v43] += v6;
    v1 += v6;
    Transfer(0x0, v43, v6);
  }

  
  function f44() external {
      require(msg.sender == v37);
      v38 = false;
  }

  
  
  function f4(address v16, uint v17) public returns (bool) {
      require(!v38);
      return super.f4(v16, v17);
  }

  function f23(address v26, address v16, uint v17) public returns (bool) {
      require(!v38);
      return super.f23(v26, v16, v17);
  }

  function f24(address v27, uint v17) public returns (bool) {
      require(!v38);
      return super.f24(v27, v17);
  }
}
