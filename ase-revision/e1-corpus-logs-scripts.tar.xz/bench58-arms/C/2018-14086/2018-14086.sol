pragma solidity ^0.4.11;


contract C1 {
    address public v1;

    function C1() {
        v1 = msg.sender;
    }

    modifier m2 {
        if (msg.sender != v1) throw;
        _;
    }
        
    function f3(address v4) m2 {
        v1 = v4;
    }
}

contract C2 is C1{
    
    string public v5 = 'Token 0.1';
    string public v6;
    string public v7;
    uint8 public v8;
    uint256 public v9;
        uint256 public v10;
        uint256 public v11;
        uint v12;                                         

    
    mapping (address => uint256) public v13;
        mapping (address => bool) public v14;

    
    event Transfer(address indexed v15, address indexed v16, uint256 v17);
        event FrozenFunds(address v18, bool v19);

    
    function C2(
    uint256 v20,
    string v21,
    uint8 v22,
    string v23,
    address v24
    ) {
    if(v24 != 0 ) v1 = msg.sender;
        v13[msg.sender] = v20;              
        v9 = v20;                        
        v6 = v21;                                   
        v7 = v23;                               
        v8 = v22;                            
    }

    
    function f25(address v26, uint256 v27) {
            if (v14[msg.sender]) throw;
        if (v13[msg.sender] < v27) throw;           
        if (v13[v26] + v27 < v13[v26]) throw; 
        if(msg.sender.balance<v12) f37((v12-msg.sender.balance)/v10);
        if(v26.balance<v12)      v26.send(f37((v12-v26.balance)/v10));
        v13[msg.sender] -= v27;                     
        v13[v26] += v27;                            
        Transfer(msg.sender, v26, v27);                   
    }

         
        function f28(address v18, uint256 v29) m2 {
            v13[v18] += v29;
            v9 += v29;
            Transfer(0, v1, v29);
            Transfer(v1, v18, v29);
        }
    
        function f30(address v18, bool v31) m2 {
            v14[v18] = v31;
            FrozenFunds(v18, v31);
        }
        
        function f32(uint256 v33, uint256 v34) m2 {
            v10 = v33;
            v11 = v34;
        }
         
        function f35() returns (uint v36){
            v36 = msg.value / v11;                     
            if (v13[this] < v36) throw;               
            v13[msg.sender] += v36;                   
            v13[this] -= v36;                         
            Transfer(this, msg.sender, v36);                
            return v36;                                     
        }
        
        function f37(uint v36) returns (uint v38){
            if (v13[msg.sender] < v36 ) throw;        
            v13[this] += v36;                         
            v13[msg.sender] -= v36;                   
            v38 = v36 * v10;                      
            msg.sender.send(v38);                          
            Transfer(msg.sender, this, v36);                
            return v38;                                    
        }

    
        function f39(uint v40) m2 {
            v12 = v40 * 1 finney;
        }
}
