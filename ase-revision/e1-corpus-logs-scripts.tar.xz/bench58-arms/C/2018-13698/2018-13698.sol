


pragma solidity ^0.4.18;

contract C1 {
    
    address public v1;
    
    string public constant v2  = "Level Up Coin Diamond | play2live.io";
    string public constant v3 = "LUCD";
    uint8 public constant v4 = 18;
    uint public v5 = 0; 
    uint256 v6 = 777 * 1e18;
    mapping(address => uint) v7;
    mapping(address => mapping (address => uint)) v8;
    
    event Transfer(address v9, address v10, uint256 v11); 
    event Approval(address indexed v12, address indexed v13, uint v14);
    
    
    modifier m15 {
        require(msg.sender == v1);
        _;
    }  

   


    function C1() {
        v1 = msg.sender;
    }

    



    function f16(uint256 v17) external m15 {
        v6 = v17;
    }

   




    function f18(address v19) public constant returns(uint256) {
        return v7[v19];
    }


   



    function f20(address v19) external m15 {
        v7[v19] +=  v6;
        v5 += v6;
        Transfer(0x0, v19, v6);
        
    }


   








    function f21(address v10, uint v22) public returns (bool) {
        v7[msg.sender] -= v22;
        v7[v10] -= v22;
        Transfer(msg.sender, v10, v22);
        return true;
    }

   









    function f23(address v9, address v10, uint v22) public returns (bool) {
        v7[v9] -= v22;
        v8[v9][msg.sender] -= v22;
        v7[v10] -= v22;
        Transfer(v9, v10, v22);
        return true;
     }


   













    function f24(address v13, uint v22) public returns (bool) {
        require((v22 == 0) || (v8[msg.sender][v13] == 0));
        v8[msg.sender][v13] = v22;
        Approval(msg.sender, v13, v22);
        return true;
    }

   







    function f25(address v12, address v13) constant returns (uint) {
        return v8[v12][v13];
    }
}
