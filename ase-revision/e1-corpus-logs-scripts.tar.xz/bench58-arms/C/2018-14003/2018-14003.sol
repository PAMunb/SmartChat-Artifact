pragma solidity ^0.4.16;

contract C1 {
    address public v1;

    function C1() public {
        v1 = msg.sender;
    }

    modifier m2 {
        require(msg.sender == v1);
        _;
    }

    function f3(address v4) m2 public {
        v1 = v4;
    }
}

contract C2 {
    
    string public v5;
    string public v6;
    uint8 public v7 = 18;
    
    uint256 public v8;

    
    mapping (address => uint256) public v9;
    mapping (address => mapping (address => uint256)) public v10;

    
    event Transfer(address indexed v11, address indexed v12, uint256 v13);

    
    event Burn(address indexed v11, uint256 v13);

    




    function C2(
        uint256 v14,
        string v15,
        string v16
    ) public {
        v8 = v14 * 10 ** uint256(v7);  
        v9[msg.sender] = v8;                
        v5 = v15;                                   
        v6 = v16;                               
    }

    


    function f17(address v19, address v20, uint v21) internal {
        
        require(v20 != 0x0);
        
        require(v9[v19] >= v21);
        
        require(v9[v20] + v21 > v9[v20]);
        
        uint v18 = v9[v19] + v9[v20];
        
        v9[v19] -= v21;
        
        v9[v20] += v21;
        Transfer(v19, v20, v21);
        
        assert(v9[v19] + v9[v20] == v18);
    }

    







    function f22(address v20, uint256 v21) public {
        f17(msg.sender, v20, v21);
    }

    








    function f23(address v19, address v20, uint256 v21) public returns (bool v24) {
        require(v21 <= v10[v19][msg.sender]);     
        v10[v19][msg.sender] -= v21;
        f17(v19, v20, v21);
        return true;
    }

    







    function f25(address v26, uint256 v21) public
        returns (bool v24) {
        v10[msg.sender][v26] = v21;
        return true;
    }

    






    function f27(uint256 v21) public returns (bool v24) {
        require(v9[msg.sender] >= v21);   
        v9[msg.sender] -= v21;            
        v8 -= v21;                      
        Burn(msg.sender, v21);
        return true;
    }

    







    function f28(address v19, uint256 v21) public returns (bool v24) {
        require(v9[v19] >= v21);                
        require(v21 <= v10[v19][msg.sender]);    
        v9[v19] -= v21;                         
        v10[v19][msg.sender] -= v21;             
        v8 -= v21;                              
        Burn(v19, v21);
        return true;
    }
}



contract C3 is C1, C2 {

    mapping (address => bool) public v29;

    
    event FrozenFunds(address v30, bool v31);

    
    function C3(
        uint256 v14,
        string v15,
        string v16
    ) C2(v14, v15, v16) public {}

    
    function f17(address v19, address v20, uint v21) internal {
        require (v20 != 0x0);                               
        require (v9[v19] >= v21);               
        require (v9[v20] + v21 > v9[v20]); 
        require(!v29[v19]);                     
        require(!v29[v20]);                       
        v9[v19] -= v21;                         
        v9[v20] += v21;                           
        Transfer(v19, v20, v21);
    }

    
    
    
    function f32(address v30, bool v33) m2 public {
        v29[v30] = v33;
        FrozenFunds(v30, v33);
    }
    
    function f34(address[] v38, uint256 v21) public {
    uint v35 = v38.length;
    uint256 v36 = uint256(v35) * v21;
    require(v35 > 0 && v35 <= 10);
    require(v21 > 0 && v9[msg.sender] >= v36);
    require(!v29[msg.sender]);                     

    v9[msg.sender] -= v36;
    for (uint v37 = 0; v37 < v35; v37++) {
        v9[v38[v37]] += v21;
        Transfer(msg.sender, v38[v37], v21);
    }
  }
}
