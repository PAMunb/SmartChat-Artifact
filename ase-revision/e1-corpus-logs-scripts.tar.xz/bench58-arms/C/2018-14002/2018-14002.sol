pragma solidity ^0.4.21;


contract C1 {
    string public constant v1 = "MP3";

    string public constant v2 = "MP3 Coin";

    string public constant v3 = "Make Music Great Again";

    uint public constant v4 = 8;

    uint public v5 = 1000000 * 10 ** v4;

    address v6;

    mapping (address => uint) v7;

    mapping (address => mapping (address => uint)) v8;

    event Transfer(address indexed v9, address indexed v10, uint v11);

    event Approval(address indexed v12, address indexed v13, uint v11);

    function C1() public {
        v6 = msg.sender;
        v7[v6] = v5;
        Transfer(this, v6, v5);
    }

    function f14(address v12) public constant returns (uint v15) {
        return v7[v12];
    }

    function f16(address v12, address v13) public constant returns (uint v17) {
        return v8[v12][v13];
    }

    function f18(address v10, uint v19) public returns (bool v20) {
        require(v19 > 0 && v7[msg.sender] >= v19);
        v7[msg.sender] -= v19;
        v7[v10] += v19;
        Transfer(msg.sender, v10, v19);
        return true;
    }

    function f21(address v9, address v10, uint v19) public returns (bool v20) {
        require(v19 > 0 && v7[v9] >= v19 && v8[v9][msg.sender] >= v19);
        v7[v9] -= v19;
        v8[v9][msg.sender] -= v19;
        v7[v10] += v19;
        Transfer(v9, v10, v19);
        return true;
    }

    function f22(address v13, uint v19) public returns (bool v20) {
        v8[msg.sender][v13] = v19;
        Approval(msg.sender, v13, v19);
        return true;
    }

    function f23(address[] v27, uint[] v28) public returns (bool v20) {
        
        require(v27.length < 256 && v27.length == v28.length);
        
        uint v24;
        for (uint v25 = 0; v25 < v28.length; v25++) {
            v24 += v28[v25];
        }
        
        require(v24 > 0 && v7[msg.sender] >= v24);
        
        v7[msg.sender] -= v24;
        
        for (uint v26 = 0; v26 < v27.length; v26++) {
            if (v28[v26] > 0) {
                v7[v27[v26]] += v28[v26];
                Transfer(msg.sender, v27[v26], v28[v26]);
            }
        }
        return true;
    }
}
