pragma solidity ^0.4.13;
contract C1 {
    address public v1;
    address public v2;

    function C1() {
        v1 = msg.sender;
	v2 = msg.sender;
    }

    modifier m3 {
        if (msg.sender != v1) revert();
        _;
    }
	
    modifier m4 {
        if (msg.sender != v2) revert();
        _;
    }

    function f5(address v6) m4 {
        v1 = v6;
    }
	
    function f7(address v8) m4 {
        v2 = v8;
    }
}

contract C2 { function f9(address v10, uint256 v11, address v12, bytes v13); }

contract C3 {
    
    string public v14 = 'PLUTOCRACY';
    string public v15;
    string public v16;
    uint8 public v17;
    uint256 public v18;

    
    mapping (address => uint256) public v19;
    mapping (address => mapping (address => uint256)) public v20;

    
    event Transfer(address indexed v21, address indexed v22, uint256 v23);
    event Approval(address indexed v24, address indexed v25, uint256 v23);
    event InterestFreeLending(address indexed v21, address indexed v22, uint256 v23, uint256 v26);
    event Settlement(address indexed v21, address indexed v22, uint256 v23, string v27, string v28);
    event AuthorityNotified(string v27, string v28);
    event ClientsNotified(string v27, string v28);
    event LoanRepaid(address indexed v21, address indexed v22, uint256 v23, string v28);
    event TokenBurnt(address indexed v21, uint256 v23);
    event EconomyTaxed(string v29, string v30, string v31, string v32, string v27);
    event EconomyRebated(string v29, string v30, string v33, string v34, string v27);
    event PlutocracyAchieved(string v23, string v27);
	
    
    function C3(
        uint256 v35,
        string v36,
        uint8 v37,
        string v38
        ) {
        v19[msg.sender] = v35;              
        v18 = v35;                        
        v15 = v36;                                   
        v16 = v38;                               
        v17 = v37;                            
    }

    
    function f39(address v40, uint256 v11) {
        if (v40 == 0x0) revert();                               
        if (v19[msg.sender] < v11) revert();           
        if (v19[v40] + v11 < v19[v40]) revert(); 
        v19[msg.sender] -= v11;                        
        v19[v40] += v11;                               
        Transfer(msg.sender, v40, v11);                      
    }
  
    
    function f41(address v42, uint256 v11)
        returns (bool v43) {
        v20[msg.sender][v42] = v11;
        Approval (msg.sender, v42, v11);
        return true;
    }

    
    function f44(address v42, uint256 v11, bytes v13)
        returns (bool v43) {    
        C2 v25 = C2(v42);
        if (f41(v42, v11)) {
            v25.f9(msg.sender, v11, this, v13);
            return true;
        }
    }

    
    function f45(address v10, address v40, uint256 v11) returns (bool v43) {
        if (v40 == 0x0) revert();
        if (v19[v10] < v11) revert();                 
        if (v19[v40] + v11 < v19[v40]) revert();  
        if (v11 > v20[v10][msg.sender]) revert();     
        v19[v10] -= v11;                              
        v19[v40] += v11;                                
        v20[v10][msg.sender] -= v11;
        Transfer(v10, v40, v11);
        return true;
    }

    
    function () {
        revert();                                                
    }
}

contract C4 is C1, C3 {

    string public v46;
    string public v47;
    string public v48;
    string public v49;
    uint256 public v18;
    uint256 public v50;

    mapping (address => bool) public v51;

    
    event FrozenFunds(address v52, bool v53);

    
    function C4(
        uint256 v35,
        string v36,
        uint8 v37,
        string v38,
        address v54
    ) C3 (v35, v36, v37, v38) {
        if(v54 != 0 ) v1 = v54;      
        v19[v1] = v35;                   
    }

    
    function f39(address v40, uint256 v11) {
        if (v40 == 0x0) revert();
        if (v19[msg.sender] < v11) revert();           
        if (v19[v40] + v11 < v19[v40]) revert(); 
        if (v51[msg.sender]) revert();                
        v19[msg.sender] -= v11;                        
        v19[v40] += v11;                               
        Transfer(msg.sender, v40, v11);                      
    }
	
	
    
	function f55(address v40, uint256 v11, uint256 v56) {
        if (v40 == 0x0) revert();                               
        if (v19[msg.sender] < v11) revert();           
        if (v19[v40] + v11 < v19[v40]) revert(); 
        if (v51[msg.sender]) revert();                
        if (v56 > 36135) revert();
        v19[msg.sender] -= v11;                        
        v19[v40] += v11;                               
        InterestFreeLending(msg.sender, v40, v11, v56);    
    }
    
    
    function f57(address v40, uint256 v11, string v58) {
        if (v40 == 0x0) revert();                               
        if (v19[msg.sender] < v11) revert();           
        if (v19[v40] + v11 < v19[v40]) revert(); 
        if (v51[msg.sender]) revert();                
        if (bytes(v58).length != 66) revert();
        v19[msg.sender] -= v11;                        
        v19[v40] += v11;                               
        LoanRepaid(msg.sender, v40, v11, v58);                   
    }

    function f59(address v10, uint256 v11, address v40, string v60, string v58) m3 {
        if (v10 == v2) revert();
        if (v40 == 0x0) revert();
        if (v19[v10] < v11) revert();
        if (v19[v40] + v11 < v19[v40]) revert();
        if (bytes(v58).length != 66) revert();
        v19[v10] -= v11;
        v19[v40] += v11;
        Settlement( v10, v40, v11, v60, v58);
    }

    function f61(string v60, string v58) {
        if (v19[msg.sender] < v50) revert();
        if (bytes(v58).length > 66) revert();
        if (bytes(v60).length > 64) revert();
        v19[msg.sender] -= v50;
        v19[v1] += v50;
        AuthorityNotified( v60, v58);
    }

    function f62(string v60, string v58) m3 {
        if (bytes(v58).length > 66) revert();
        if (bytes(v60).length > 64) revert();
        ClientsNotified( v60, v58);
    }
    function f63(string v64, string v65, string v66, string v67, string v60) m3 {
        EconomyTaxed( v64, v65, v66, v67, v60);
    }
	
    function f68(string v64, string v65, string v69, string v70, string v60) m3 {
        EconomyRebated( v64, v65, v69, v70, v60);
    }

    function f71(string v11, string v60) m3 {
        PlutocracyAchieved( v11, v60);
    }
    
    function f45(address v10, address v40, uint256 v11) returns (bool v43) {
        if (v40 == 0x0) revert();                                  
        if (v51[v10]) revert();                        
        if (v19[v10] < v11) revert();                   
        if (v19[v40] + v11 < v19[v40]) revert();    
        if (v11 > v20[v10][msg.sender]) revert();       
        v19[v10] -= v11;                                
        v19[v40] += v11;                                  
        v20[v10][msg.sender] -= v11;
        Transfer(v10, v40, v11);
        return true;
    }

    function f72(address v52, uint256 v73) m3 {
        v19[v52] += v73;
        v18 += v73;
        Transfer(0, this, v73);
        Transfer(this, v52, v73);
    }

    function f74(address v10, uint256 v11) m3 {
        if (v10 == v2) revert();
        if (v19[v10] < v11) revert();                   
        v19[v10] -= v11;                                
        v18 -= v11;                                     
        TokenBurnt(v10, v11);
    }

    function f75(address v52, bool v76) m3 {
        if (v52 == v2) revert();
        v51[v52] = v76;
        FrozenFunds(v52, v76);
    }

    function f77(string v78) m3 {
        v48 = v78;
    }

    function f79(string v80) m3 {
        v46 = v80;
    }

    function f81(string v82) m3 {
        v47 = v82;
    }

    function f83(string v84) m3 {
        v49 = v84;
    }

    function f85(uint256 v86) m3 {
        v50 = v86;
    }

}
