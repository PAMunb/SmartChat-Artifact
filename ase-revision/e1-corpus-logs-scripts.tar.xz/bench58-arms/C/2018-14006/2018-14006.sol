pragma solidity ^0.4.18;
 
interface C1 {
	
	
	function f1() public view returns (string);
	function f2() public view returns (string);
	function f3() public view returns (uint8);
	function f4() public view returns (uint256);
	function f5(address v6) public view returns (uint256);
	function f7(address v8, uint256 v9) public returns (bool v10);
	function f11(address v12, address v8, uint256 v9) public returns (bool v10);
	function f13(address v14, uint256 v9) public returns (bool v10);
	function f15(address v6, address v14) public view returns (uint256);
	
	event Transfer(address indexed v12, address indexed v8, uint256 v9);
	event Approval(address indexed v6, address indexed v14, uint256 v9);
}

interface C2 { 
	function f16(address v12, uint256 v9, address v17, bytes v18) public; 
}

interface C3 {
    function f19(address v12, uint256 v9, bytes v20) public;
}

contract C4 is C1 {
	
	
	function f7(address v8, uint256 v9, bytes v20) public returns (bool v10);
	function f7(address v8, uint256 v9, bytes v20, string v21) public returns (bool v10);
	
	event Transfer(address indexed v12, address indexed v8, uint256 v9, bytes v20);
}

contract C5 is C4 {
	string constant private v22 			= "NEO Genesis Token";
	string constant private v23	 		= "NGT";
	uint8 constant private v24 		= 18;
	uint256 constant private v25	= 20000000000 * (10 ** uint256(v24));
	uint256 private v26				= 0;
	mapping(address => uint256) private v27;
	mapping(address => mapping(address => uint256)) private v28;
	
	function C5() public {
	  v27[msg.sender] = v25;
	}
	
	
	function f1() public view returns (string) {
		return v22;
	}
	
	function f2() public view returns (string) {
		return v23;
	}
	
	function f3() public view returns (uint8) {
		return v24;
	}
	
	function f4() public view returns (uint256) {
		return v25 - v26;
	}

	function f5(address v6) public view returns (uint256) {
		return v27[v6];
	}
	
	function f7(address v8, uint256 v9) public returns (bool v10) {
		if (f44(v8)) {
			bytes memory v29;
			return f42(v8, v9, v29);
		} else {
			require(v8 != address(0x0));
			require(v27[msg.sender] >= v9);
			v27[msg.sender] -= v9;
			v27[v8] += v9;
			Transfer(msg.sender, v8, v9);
			
		}
		return true;
	}

	function f30(address[] v8, uint256 v9) public returns (bool v10) {
		require(v9 * v8.length > 0);
		require(v27[msg.sender] >= v9 * v8.length);
		v27[msg.sender] -= v9 * v8.length;
		for (uint256 v31 = 0; v31 < v8.length; ++v31) {
		 	v27[v8[v31]] += v9;
		 	Transfer(msg.sender, v8[v31], v9);
		}
		return true;
	}

	function f32(address[] v8, uint256[] v9) public returns (bool v10) {
		require(v8.length > 0);
		require(v9.length > 0);
		require(v8.length == v9.length);
		for (uint256 v31 = 0; v31 < v8.length; ++v31) {
			address v33 = v8[v31];
			uint256 v34 = v9[v31];
			require(v27[msg.sender] >= v34);
			v27[msg.sender] -= v34;
		 	v27[v33] += v34;
		 	Transfer(msg.sender, v33, v34);
		}
		return true;
	}

	function f11(address v12, address v8, uint256 v9) public returns (bool v10) {
		require(v8 != address(0x0));
        require(v27[v12] >= v9 && v28[v12][msg.sender] >= v9);
        v27[v12] -= v9;
        v27[v8] += v9;
		v28[v12][msg.sender] -= v9;
        Transfer(v12, v8, v9);
		bytes memory v29;
		Transfer(v12, v8, v9, v29);
        return true;
	}
	
	function f13(address v14, uint256 v9) public returns (bool v10) {
		
		
		require((v9 == 0) || (v28[msg.sender][v14] == 0));
		
		v28[msg.sender][v14] = v9;
		Approval(msg.sender, v14, v9);
		return true;
	}
	
    function f35(address v14, uint256 v9, bytes v18) public returns (bool v10) {
        C2 v36 = C2(v14);
        if (f13(v14, v9)) {
            v36.f16(msg.sender, v9, this, v18);
            return true;
        }
		return false;
    }

	function f37(address v14, uint256 v38) public returns (bool) {
		v28[msg.sender][v14] += v38;
		Approval(msg.sender, v14, v28[msg.sender][v14]);
		return true;
	}

	function f39(address v14, uint256 v40) public returns (bool) {
		if (v40 > v28[msg.sender][v14]) {
		  v28[msg.sender][v14] = 0;
		} else {
		  v28[msg.sender][v14] -= v40;
		}
		Approval(msg.sender, v14, v28[msg.sender][v14]);
		return true;
	}	
	
	function f15(address v6, address v14) public view returns (uint256) {
		return v28[v6][v14];
	}
	
	
	function f7(address v8, uint256 v9, bytes v20) public returns (bool v10) {
		if (f44(v8)) {
			return f42(v8, v9, v20);
		} else {
			return f41(v8, v9, v20);
		}
	}

	function f7(address v8, uint256 v9, bytes v20, string v21) public returns (bool v10) {
		if (f44(v8)) {
			require(v8 != address(0x0));
			require(v27[msg.sender] >= v9);
			v27[msg.sender] -= v9;
			v27[v8] += v9;
			assert(v8.call.value(0)(bytes4(keccak256(v21)), msg.sender, v9, v20));
			Transfer(msg.sender, v8, v9);
			Transfer(msg.sender, v8, v9, v20);
			return true;
		} else {
			return f41(v8, v9, v20);
		}
	}

    function f41(address v8, uint256 v9, bytes v20) private returns (bool v10) {
		require(v8 != address(0x0));
		require(v27[msg.sender] >= v9);
		v27[msg.sender] -= v9;
		v27[v8] += v9;
		Transfer(msg.sender, v8, v9);
		Transfer(msg.sender, v8, v9, v20);
		return true;
    }

    function f42(address v8, uint256 v9, bytes v20) private returns (bool v10) {
		require(v8 != address(0x0));
		require(v27[msg.sender] >= v9);
		v27[msg.sender] -= v9;
		v27[v8] += v9;
		C3 v43 = C3(v8);
		v43.f19(msg.sender, v9, v20);
        Transfer(msg.sender, v8, v9);
        Transfer(msg.sender, v8, v9, v20);
        return true;
    }

	function f44(address _addr) private view returns (bool) {
        
		
        uint256 length;
        assembly {
            length := extcodesize(_addr)
        }
		return (length > 0);
    }
	
	
    event Burn(address indexed v45, uint256 v34, uint256 v46, bytes v47);

    function f48(uint256 v9, bytes v20) public returns (bool v10) {
		require(v27[msg.sender] >= v9);
		v27[msg.sender] -= v9;
		v26 += v9;
		Burn(msg.sender, v9, f4(), v20);
		return true;
    }

    function f49(address v12, uint256 v9, bytes v20) public returns (bool v10) {
		if (f11(v12, msg.sender, v9)) {
			return f48(v9, v20);
		}
        return false;
    }

	function f50() public pure returns (uint256) {
		return v25;
	}

	function f51() public view returns (uint256) {
		return v26;
	}

	
	function () public {
        require(false);
    }
}
