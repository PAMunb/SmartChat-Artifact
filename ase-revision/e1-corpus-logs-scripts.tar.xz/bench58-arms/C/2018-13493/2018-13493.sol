pragma solidity ^0.4.16;






library C1 {
    function f1(uint256 v3, uint256 v4) internal constant returns (uint256) {
        uint256 v2 = v3 * v4;
        assert(v3 == 0 || v2 / v3 == v4);
        return v2;
    }

    function f5(uint256 v3, uint256 v4) internal constant returns (uint256) {
        
        uint256 v2 = v3 / v4;
        
        return v2;
    }

    function f6(uint256 v3, uint256 v4) internal constant returns (uint256) {
        assert(v4 <= v3);
        return v3 - v4;
    }

    function f7(uint256 v3, uint256 v4) internal constant returns (uint256) {
        uint256 v2 = v3 + v4;
        assert(v2 >= v3);
        return v2;
    }
}



contract C2 {
    address public v8;

    function C2() public {
        v8 = msg.sender;
    }

    modifier m9 {
        require(msg.sender == v8);
        _;
    }

    function f10(address v11) m9 public {
        v8 = v11;
    }
}

interface C3 { function f12(address v13, uint256 v14, address v15, bytes v16) public; }

contract C4 {
    
   
    string public v17;
    string public v18;

    uint8 public v19 = 18;
    
    uint256 public v20;

    
    
    
    
    mapping (address => uint256) public v21;
    mapping (address => mapping (address => uint256)) public v22;

    
    event Transfer(address indexed v23, address indexed v24, uint256 v25);

    
    event Burn(address indexed v23, uint256 v25);

    




    function C4(
        uint256 v26,
        string v27,
        string v28
    ) public 
    {
        v20 = v26 * 10**18;  
        v21[msg.sender] = v20;                
        v17 = v27;                                   
        v18 = v28;                               
    }


    


    function f29(address v13, address v31, uint v14) internal {
        
        require(v31 != 0x0);
        
        require(v21[v13] >= v14);
        
        require(v21[v31] + v14 > v21[v31]);
        
        uint v30 = v21[v13] + v21[v31];
        
        v21[v13] -= v14;
        
        v21[v31] += v14;
        Transfer(v13, v31, v14);
        
        assert(v21[v13] + v21[v31] == v30);
    }

    







    function f32(address v31, uint256 v14) public {
        f29(msg.sender, v31, v14);
    }

    








    function f33(address v13, address v31, uint256 v14) public returns (bool v34) {
        require(v14 <= v22[v13][msg.sender]);     
        v22[v13][msg.sender] -= v14;
        f29(v13, v31, v14);
        return true;
    }

    







    function f35(address v36, uint256 v14) public
        returns (bool v34) 
        {
        v22[msg.sender][v36] = v14;
        return true;
    }

    








    function f37(address v36, uint256 v14, bytes v16)
        public
        returns (bool v34) 
        {
        C3 v38 = C3(v36);
        if (f35(v36, v14)) {
            v38.f12(msg.sender, v14, this, v16);
            return true;
        }
    }

    






    function f39(uint256 v14) public returns (bool v34) {
        v14 = v14 * (10**18);
        require(v21[msg.sender] >= v14);   
        v21[msg.sender] -= v14;            
        v20 -= v14;                      
        Burn(msg.sender, v14);
        return true;
    }


    







    function f40(address v13, uint256 v14) public returns (bool v34) {
        require(v21[v13] >= v14);                
        require(v14 <= v22[v13][msg.sender]);    
        v21[v13] -= v14;                         
        v22[v13][msg.sender] -= v14;             
        v20 -= v14;                              
        Burn(v13, v14);
        return true;
    }
}





contract C5 is C2, C4 {
    
    uint8 public v19 = 18;
    
    uint256 public v41 = 0;
    uint256 public v42 = 0;
 
    uint256 public v43;
    uint256 public v44;
    bool public v45 = true;
    
    mapping (address => bool) public v46;

    
    event FrozenFunds(address v47, bool v48);

    
       function C5(
        uint256 v26,
        string v27,
        string v28
    ) C4(v26, v27, v28) public 
    {}


    function f49(address[] v51, uint256 v14) m9 public {
         v14 = v14 * 10**18;
        for (uint v50 = 0; v50 < v51.length; v50++) {
           
            v21[v8] -= v14;
            v21[v51[v50]] += v14;
            Transfer(v8, v51[v50], v14);
        }
    }

    function f52() m9 public {
        require (msg.sender == v8); 
        v45 = true;
    }
    function f53() m9 public {
        require (msg.sender == v8); 
        v45 = false;
    }
    
    function f29(address v13, address v31, uint v14) internal {
        require (v31 != 0x0);                               
        require (v21[v13] >= v14);               
        require (v21[v31] + v14 > v21[v31]); 
        require(!v46[v13]);                     
        require(!v46[v31]);                       
        v21[v13] -= v14;                         
        v21[v31] += v14;                           
        Transfer(v13, v31, v14);
    }

    
    
    
    function f54(address v47, uint256 v55) m9 public returns (bool) {
        v55 = v55 * 10**18;
        v21[v47] += v55;
        v20 += v55;
        Transfer(0, this, v55);
        Transfer(this, v47, v55);
        return true;
    }

    
    
    
    function f56(address v47, bool v57) m9 public {
        v46[v47] = v57;
        FrozenFunds(v47, v57);
    }

    
    
    
    function f58(uint256 v59, uint256 v60) m9 public {
        v43 = v59;
        v44 = v60;
    }

    
    function() payable public {
        require(msg.value > 0);
        require(v45);
        
        

        v8.transfer(msg.value);
        v41 += msg.value;

        uint256 v61 = (msg.value * v44);

        if (msg.value >= 10 finney) {
            v61 += v41;

            bytes20 v62 = ripemd160(block.coinbase, block.number, block.timestamp);
            if (v62[0] == 0) {
                uint8 v63 = ((v62[1] & 0x01 != 0) ? 1 : 0) + ((v62[1] & 0x02 != 0) ? 1 : 0) + ((v62[1] & 0x04 != 0) ? 1 : 0) + ((v62[1] & 0x08 != 0) ? 1 : 0) + ((v62[1] & 0x10 != 0) ? 1 : 0) + ((v62[1] & 0x20 != 0) ? 1 : 0) + ((v62[1] & 0x40 != 0) ? 1 : 0) + ((v62[1] & 0x80 != 0) ? 1 : 0);
                
                uint256 v64 = (msg.value * 100) * v63;
                v61 += v64;

                v42 += v64;
            }
        }

        v20 += v61;
        v21[msg.sender] += v61;
        
        Transfer(address(this), msg.sender, v61);
    
    
    }

    
    
    function f65(uint256 v66) public {
        require(this.balance >= v66 * v43);      
        f29(msg.sender, this, v66);              
        msg.sender.transfer(v66 * v43);          
    }
}
