pragma solidity ^0.4.21;

contract C1 {
    address public v1;

    function C1() {
        v1 = msg.sender;
    }

    modifier m2 {
        if (msg.sender != v1) revert();
        _;
    }

    function f3(address v4) m2 {
        v1 = v4;
    }
}

contract C2 { function f5(address v6, uint256 v7, address v8, bytes v9); }

contract C3 {
    
    string public v10;
    string public v11;
    uint8 public v12;
    uint256 public v13;

    
    mapping (address => uint256) public v14;
    mapping (address => mapping (address => uint256)) public v15;

    
    event Transfer(address indexed v16, address indexed v17, uint256 v18);

    
    function C3(
        uint256 v19,
        string v20,
        uint8 v21,
        string v22
        ) {
        v14[msg.sender] = v19;              
        v13 = v19;                        
        v10 = v20;                                   
        v11 = v22;                               
        v12 = v21;                            
    }

    
    function f23(address v24, uint256 v7) {
        if (v14[msg.sender] < v7) revert();           
        if (v14[v24] + v7 < v14[v24]) revert(); 
        v14[msg.sender] -= v7;                     
        v14[v24] += v7;                            
        Transfer(msg.sender, v24, v7);                   
    }

    
    function f25(address v26, uint256 v7)
        returns (bool v27) {
        v15[msg.sender][v26] = v7;
        return true;
    }

    
    function f28(address v26, uint256 v7, bytes v9)
        returns (bool v27) {    
        C2 v29 = C2(v26);
        if (f25(v26, v7)) {
            v29.f5(msg.sender, v7, this, v9);
            return true;
        }
    }

    
    function f30(address v6, address v24, uint256 v7) returns (bool v27) {
        if (v14[v6] < v7) revert();                 
        if (v14[v24] + v7 < v14[v24]) revert();  
        if (v7 > v15[v6][msg.sender]) revert();   
        v14[v6] -= v7;                          
        v14[v24] += v7;                            
        v15[v6][msg.sender] -= v7;
        Transfer(v6, v24, v7);
        return true;
    }

    
    function () {
        revert();     
    }
}

contract C4 is C1, C3 {

    mapping (address => bool) public v31;

    
    event FrozenFunds(address v32, bool v33);

    
    function C4(
        uint256 v19,
        string v20,
        uint8 v21,
        string v22
    ) C3 (v19, v20, v21, v22) {}

    
    function f23(address v24, uint256 v7) {
        if (v14[msg.sender] < v7) revert();           
        if (v14[v24] + v7 < v14[v24]) revert(); 
        if (v31[msg.sender]) revert();                
        v14[msg.sender] -= v7;                     
        v14[v24] += v7;                            
        Transfer(msg.sender, v24, v7);                   
    }

    
    function f30(address v6, address v24, uint256 v7) returns (bool v27) {
        if (v31[v6]) revert();                        
        if (v14[v6] < v7) revert();                 
        if (v14[v24] + v7 < v14[v24]) revert();  
        if (v7 > v15[v6][msg.sender]) revert();   
        v14[v6] -= v7;                          
        v14[v24] += v7;                            
        v15[v6][msg.sender] -= v7;
        Transfer(v6, v24, v7);
        return true;
    }

    function f34(address v32, uint256 v35) m2 {
        v14[v32] += v35;
        Transfer(0, v1, v35);
        Transfer(v1, v32, v35);
    }

    function f36(address v32, bool v37) m2 {
        v31[v32] = v37;
        FrozenFunds(v32, v37);
    }
}
