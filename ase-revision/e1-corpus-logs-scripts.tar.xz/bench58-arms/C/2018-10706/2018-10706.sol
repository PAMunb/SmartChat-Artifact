pragma solidity ^0.4.21;

contract C1 {
    function f1(
    address v2,
    uint256 v3,
    address v4,
    bytes v5
    ) public;
}


contract C2 {
    modifier m6 {
        require(msg.sender == v7);
        _;
    }
    address public v7;

    function C2() public {
        v7 = msg.sender;
    }

    function f8(address v9) m6 public {
        v7 = v9;
    }
}


contract C3 {

    
    uint256 public v10;
    

    
    
    mapping (address => uint256) public v11;

    

    
    
    
    
    function f12(address v13, uint256 v14) public returns (bool v15);

    
    
    
    
    
    function f16(address v2, address v13, uint256 v14) public returns (bool v15);

    
    
    
    
    function f17(address v18, uint256 v14) public returns (bool v15);

    
    
    
    mapping (address => mapping (address => uint256)) public v19;
    

    event Transfer(address indexed v2, address indexed v13, uint256 v14);
    event Approval(address indexed v20, address indexed v18, uint256 v14);
}

contract C4 is C3, C2 {

    string public v21;                
    uint8 public v22;             
    string public v23;              


    

    
    
    
    
    
    
    
    function f24(
    address v18,
    uint256 v3,
    bytes v25
    ) public returns (bool v15);


    

    
    
    
    
    function f26(address v20, uint v3) public returns (bool);


    
    
    
    
    function f27(address v20, uint v3) public returns (bool);

}

contract C5 is C4 {

    struct FreezeInfo {
    address user;
    uint256 amount;
    }
    
    mapping (uint8 => mapping (uint8 => FreezeInfo)) public v28; 
    mapping (uint8 => uint8) public v29; 
    mapping (address => uint256) public v30;

    address public v31;
    bool public v32=false;
    uint256 public v33 = 1 ether;  
    uint256 public v34=0;
    uint256 public v35=0;
    uint256 public v36 = 10000;
    address private v37;
    uint256 public v38 = 0;

    
    

    
    event Burn(address indexed v39, uint256 v40);

    
    event Freeze(address indexed v39, uint256 v40);

    
    event Unfreeze(address indexed v39, uint256 v40);

    event Payment(address v41, uint256 v42, uint256 v43);

    
    function C5(
    uint256 v44,
    string v45,
    uint8 v46,
    string v47,
    address v48
    ) public {
        require(v48 != 0);
        v10 = v44 * 10 ** uint256(v46);
        v11[msg.sender] = v10;
        v21 = v45;
        v23 = v47;
        v22 = v46;
        v31 = msg.sender;
        v37=v48;
    }

    modifier m49() {
        require(msg.sender == v31);
        _;
    }

    modifier m50(address v51){
        if(v51 == 0x0){
            revert();
        }
        _;
    }

    modifier m52(uint256 v14){
        if (v14 <= 0){
            revert();
        }
        _;
    }

    
    
    
    function f53(address _addr) constant internal returns(bool) {
        uint size;
        if (_addr == 0) {
            return false;
        }
        assembly {
        size := extcodesize(_addr)
        }
        return size>0;
    }

    
    function f12(address v13, uint256 v14) m50(v13) m52(v14) public returns (bool) {
        require(v11[msg.sender] >= v14);           
        require(v11[v13] + v14 > v11[v13]); 
        v11[msg.sender] = v11[msg.sender] - v14;                     
        v11[v13] = v11[v13] + v14;                            
        emit Transfer(msg.sender, v13, v14);                   
        return true;
    }

    
    function f17(address v18, uint256 v14) m52(v14) public
    returns (bool v15) {
        v19[msg.sender][v18] = v14;
        return true;
    }

    








    function f24(address v18, uint256 v3, bytes v25) public returns (bool v15) {
        require(f17(v18, v3));
        C1(v18).f1(
        msg.sender,
        v3,
        this,
        v25
        );

        return true;
    }

    
    function f16(address v2, address v13, uint256 v14) m50(v2) m50(v13) m52(v14) public returns (bool v15) {
        require(v11[v2] >= v14);                 
        require(v11[v13] + v14 > v11[v13]);  
        require(v14 <= v19[v2][msg.sender]);     
        v11[v2] = v11[v2] - v14;                           
        v11[v13] = v11[v13] + v14;                             
        v19[v2][msg.sender] = v19[v2][msg.sender] + v14;
        emit Transfer(v2, v13, v14);
        return true;
    }

    function f54(address[] v13, uint256[] v14) public returns (uint256 v60){
        require(v13.length == v14.length);
        uint8 v55 = uint8(v13.length);
        for(uint8 v56; v56<v55; v56++){
            v60 += v14[v56]*10**uint256(v22);
        }
        require(v11[msg.sender] >= v60);
        for(uint8 v59; v59<v55; v59++){
            address v57 = v13[v59];
            uint256 v58 = v14[v59]*10**uint256(v22);
            v11[v57] += v58;
            v11[msg.sender] -= v58;
            emit Transfer(msg.sender, v57, v58);
        }
    }

    
    function f61(address v62, uint256 v14, uint8 v63) m52(v14) m6 public returns (bool v15) {
        v14=v14*10**uint256(v22);
        return f64(v62,v14,v63);
    }

    function f64(address v62, uint256 v14, uint8 v63) m52(v14) private returns (bool v15) {
        
        require(v11[v62] >= v14);
        v11[v62] = v11[v62] - v14;
        v28[v63][v29[v63]] = FreezeInfo({user:v62, amount:v14});
        v29[v63]++;
        emit Freeze(v62, v14);
        return true;
    }


    
    function f65(uint8 v63) m49 public returns (bool v69) {
        
        uint8 v66 = v29[v63];
        require(v66 > 0);
        v69=false;
        uint8  v67=0;
        for(; v66>v67; v66--){
            FreezeInfo storage v68 = v28[v63][v66-1];
            uint256 v3 = v68.amount;
            v11[v68.user] += v3;
            delete v28[v63][v66-1];
            v29[v63]--;
            emit Unfreeze(v68.user, v3);
        }
    }


    
    
    

    
    
    
    
    function f26(address v62, uint v3) m6 public returns (bool) {
        v3=v3*10**uint256(v22);
        return f70(v62,v3);
    }

    function f70(address v62, uint v3)  private returns (bool) {
        require(v11[v31] >= v3);
        v11[v62] += v3;
        v11[v31] -= v3;
        emit Transfer(0, v62, v3);
        return true;
    }

    
    
    
    
    function f27(address v62, uint256 v3) m49 public returns (bool) {
        v3=v3*10**uint256(v22);
        return f71(v62,v3);
    }

    function f71(address v62, uint256 v3) private returns (bool) {
        require(v11[v62] >= v3);
        v11[v31] += v3;
        v11[v62] -= v3;
        emit Transfer(v62, 0, v3);
        emit Burn(v62, v3);
        return true;
    }


    function f72(address v73) m49 public returns (bool) {
        v11[v73] += v11[v31];
        v11[v31] = 0;
        v31 = v73;
        return true;
    }


    


    function f74(uint256 v75) m6 public {
        v36 = v75;
    }

    

   
    function f76(uint256 v77) m6 public {
        v34 = v77;
    }

    

   
    function f78(uint256 v79) m6 public {
        uint256 v4 =v79*10**uint256(v22);
        require(v11[v31] >= v4);
        v35 = v79;
    }

        
    
    
    function f80(bool v81) m6 public {
        v32 = v81;
    }

    
    function() payable public {
        require(!v32);
        address v62=msg.sender;
        uint256 v82;
        if(msg.value==0){
            require(v34>0);
            require(v35>=v34);
            require(v30[v62]==0);
            v82=v34*10**uint256(v22);
            v30[v62]=v82;
            v35-=v34;
            require(f70(v62, v82));
            emit Payment(v62, msg.value, v82);
        }else{
            require(msg.value >= v33);
            require(msg.value % 1 ether==0);
            v38 +=msg.value;
            require(v37.send(msg.value));
            v82 = (msg.value/1 ether)*(v36*10 ** uint256(v22));
            require(f70(v62, v82));
            uint256 v83 = v82 / 5;
            require(f64(v62, v83, 0));
            f64(v62, v83, 1);
            f64(v62, v83, 2);
            f64(v62, v83, 3);
            emit Payment(v62, msg.value, v82);
        }
    }
}
