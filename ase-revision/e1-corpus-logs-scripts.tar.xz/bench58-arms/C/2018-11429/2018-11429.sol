pragma solidity ^0.4.11;

library C1 {
  function f1(uint v3, uint v4) internal returns (uint) {
    uint v2 = v3 * v4;
    f12(v3 == 0 || v2 / v3 == v4);
    return v2;
  }

  function f5(uint v3, uint v4) internal returns (uint) {
    f12(v4 > 0);
    uint v2 = v3 / v4;
    f12(v3 == v4 * v2 + v3 % v4);
    return v2;
  }

  function f6(uint v3, uint v4) internal returns (uint) {
    f12(v4 <= v3);
    return v3 - v4;
  }

  function f7(uint v3, uint v4) internal returns (uint) {
    uint v2 = v3 + v4;
    f12(v2 >= v3);
    return v2;
  }

  function f8(uint64 v3, uint64 v4) internal constant returns (uint64) {
    return v3 >= v4 ? v3 : v4;
  }

  function f9(uint64 v3, uint64 v4) internal constant returns (uint64) {
    return v3 < v4 ? v3 : v4;
  }

  function f10(uint256 v3, uint256 v4) internal constant returns (uint256) {
    return v3 >= v4 ? v3 : v4;
  }

  function f11(uint256 v3, uint256 v4) internal constant returns (uint256) {
    return v3 < v4 ? v3 : v4;
  }

  function f12(bool v13) internal {
    if (!v13) {
      throw;
    }
  }
}

contract C2 {
  uint public v14;
  function f15(address v16) constant returns (uint);
  function f17(address v18, uint v19);
  event Transfer(address indexed v20, address indexed v18, uint v19);
}

contract C3 is C2 {
  function f21(address v22, address v23) constant returns (uint);
  function f24(address v20, address v18, uint v19);
  function f25(address v23, uint v19);
  event Approval(address indexed v22, address indexed v23, uint v19);
}

contract C4 is C2 {
  using C1 for uint;

  mapping(address => uint) v26;

  


  modifier m27(uint v28) {
     if(msg.data.length < v28 + 4) {
       throw;
     }
     _;
  }

  function f17(address v29, uint v30) m27(2 * 32) {
    v26[msg.sender] = v26[msg.sender].f6(v30);
    v26[v29] = v26[v29].f7(v30);
    Transfer(msg.sender, v29, v30);
  }

  function f15(address v31) constant returns (uint v32) {
    return v26[v31];
  }
  
}

contract C5 is C4, C3 {

  mapping (address => mapping (address => uint)) v33;

  function f24(address v35, address v29, uint v30) {
    var v34 = v33[v35][msg.sender];

    
    

    v26[v29] = v26[v29].f7(v30);
    v26[v35] = v26[v35].f6(v30);
    v33[v35][msg.sender] = v34.f6(v30);
    Transfer(v35, v29, v30);
  }

  function f25(address v36, uint v30) {
    v33[msg.sender][v36] = v30;
    Approval(msg.sender, v36, v30);
  }

  function f21(address v31, address v36) constant returns (uint v37) {
    return v33[v31][v36];
  }

}

contract C6 is C5 {

  string public v38 = "ATLANT Token";
  string public v39 = "ATL";
  uint public v40 = 18;
  uint constant v41 = 150 * 1e6 * 1e18;

  address public v42;

  bool public v43 = true;

  function C6(address v44) {
    v42 = v44;
  }

  function f45(address v46, uint v30) external {
    require(msg.sender == v42);
    require(v30 != 0);
    require(v14 + v30 <= v41);

    v26[v46] += v30;
    v14 += v30;
    Transfer(0x0, v46, v30);
  }

  function f47() external {
    require(msg.sender == v42);
    v43 = false;
  }

  function f17(address v29, uint v30) public {
    require(!v43);
    super.f17(v29, v30);
  }


  function f24(address v35, address v29, uint v30) public {
    require(!v43);
    super.f24(v35, v29, v30);
  }


  function f25(address v36, uint v30) public {
    require(!v43);
    super.f25(v36, v30);
  }
}
