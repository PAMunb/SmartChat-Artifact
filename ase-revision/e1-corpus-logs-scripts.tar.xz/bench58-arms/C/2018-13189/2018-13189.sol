pragma solidity ^0.4.18;





library C1 {
  function f1(uint256 v3, uint256 v4) internal constant returns (uint256) {
    uint256 v2 = v3 * v4;
    assert(v3 == 0 || v2 / v3 == v4);
    return v2;
  }

  function f5(uint256 v3, uint256 v4) internal constant returns (uint256) {
    
    uint256 v2 = v3 / v4;
    
    return v2;
  }

  function f6(uint256 v3, uint256 v4) internal constant returns (uint256) {
    assert(v4 <= v3);
    return v3 - v4;
  }

  function f7(uint256 v3, uint256 v4) internal constant returns (uint256) {
    uint256 v2 = v3 + v4;
    assert(v2 >= v3);
    return v2;
  }
}







contract C2 {
  uint256 public v8;
  function f9(address v10) constant returns (uint256);
  function f11(address v12, uint256 v13) returns (bool);
  event Transfer(address indexed v14, address indexed v12, uint256 v13);
}






contract C3 is C2 {
  function f15(address v16, address v17) constant returns (uint256);
  function f18(address v14, address v12, uint256 v13) returns (bool);
  function f19(address v17, uint256 v13) returns (bool);
  event Approval(address indexed v16, address indexed v17, uint256 v13);
}






contract C4 is C2 {
  using C1 for uint256;

  mapping(address => uint256) v20;

  




  function f11(address v21, uint256 v22) returns (bool) {
    v20[msg.sender] = v20[msg.sender].f6(v22);
    v20[v21] = v20[v21].f7(v22);
    Transfer(msg.sender, v21, v22);
    return true;
  }

  




  function f9(address v23) constant returns (uint256 v24) {
    return v20[v23];
  }
}









contract C5 is C3, C4 {

  mapping (address => mapping (address => uint256)) v25;


  





  function f18(address v27, address v21, uint256 v22) returns (bool) {
    var v26 = v25[v27][msg.sender];

    
    

    v20[v21] = v20[v21].f7(v22);
    v20[v27] = v20[v27].f6(v22);
    v25[v27][msg.sender] = v26.f6(v22);
    Transfer(v27, v21, v22);
    return true;
  }

  




  function f19(address v28, uint256 v22) returns (bool) {

    
    
    
    
    require((v22 == 0) || (v25[msg.sender][v28] == 0));

    v25[msg.sender][v28] = v22;
    Approval(msg.sender, v28, v22);
    return true;
  }

  





  function f15(address v23, address v28) constant returns (uint256 v29) {
    return v25[v23][v28];
  }
}







contract C6 {
  address public v16;


  



  function C6() {
    v16 = msg.sender;
  }


  


  modifier m30() {
    require(msg.sender == v16);
    _;
  }


  



  function f31(address v32) m30 {
    if (v32 != address(0)) {
      v16 = v32;
    }
  }
}







contract C7 is C6 {
  event Pause();
  event Unpause();

  bool public v33 = false;


  


  modifier m34() {
    require(!v33);
    _;
  }

  


  modifier m35 {
    require(v33);
    _;
  }

  


  function f36() m30 m34 returns (bool) {
    v33 = true;
    Pause();
    return true;
  }

  


  function f37() m30 m35 returns (bool) {
    v33 = false;
    Unpause();
    return true;
  }
}








contract C8 is C5, C7 {

  function f11(address v21, uint v22) m34 returns (bool) {
    return super.f11(v21, v22);
  }

  function f18(address v27, address v21, uint v22) m34 returns (bool) {
    return super.f18(v27, v21, v22);
  }
}



contract C9 is C8 {

  string public constant v38 = "UnolaboToken";
  string public constant v39 = "UNLB";
  uint256 public constant v40 = 18;

  function C9() {
    v16 = msg.sender;
  }

  function f41(address v42, uint v43) public m30 {
    v20[v42] += v43;
    v8 += v43;
    Transfer(0x0, v42, v43);
  }
}



contract C10 is C7 {

  uint public constant v44 =  1511773200;
  uint public constant v45   =  1525018620;

  address public constant v46      = 0xFeC0714C2eE71a486B679d4A3539FA875715e7d8;
  address public constant v47 = 0xf16d5733A31D54e828460AFbf7D60aA803a61C51;

  C9 public v48;
  bool public v49 = false;

  event ForeignBuy(address v50, uint v51, string v52);
  
  function C10() {
    v16 = v46;
    v48 = new C9();
    v48.f36();
  }

  function f53() public constant returns(uint) {
    if     (now <  1511799420) return 800.0 * 1 ether;
    else if(now <  1511885820) return 750.0 * 1 ether;
    else if(now <  1513181820) return 675.0 * 1 ether;
    else if(now <  1515514620) return 575.0 * 1 ether;
    else if(now <  1516205820) return 537.5 * 1 ether;
    else                                                return 500.0 * 1 ether;
  }


  function() public payable {
    require(!v33 && now >= v44 && now < v45);
    uint v54 = (msg.value * f53()) / 1 ether;
    v48.f41(msg.sender, v54);
  }

  function f55(address v56, uint v57, string v58) external m30 {
    require(!v33 && now >= v44 && now < v45);
    require(v57 > 0);
    v48.f41(v56, v57);
    ForeignBuy(v56, v57, v58);
  }
  
  function f59(address v61, address v62, address v63, address v64) external m30 {
    require(now >= v45 && !v49);
    v48.f37();
    v49 = true;

    uint v60 = v48.v8() * 100 / (100 - 12 - 15 - 5 - 3);
    v48.f41(v61,   (v60 * 12) / 100);
    v48.f41(v62,   (v60 * 15) / 100);
    v48.f41(v63, (v60 *  5) / 100);
    v48.f41(v64, (v60 *  3) / 100);
  }


  function f65() external m30 {
    v47.transfer(this.balance);
  }
}
