pragma solidity ^0.4.13;
contract C1 {
    address public v1;
    mapping (address =>  bool) public v2;

    function C1() {
        v1 = msg.sender;
        v2[msg.sender]=true;
    }

    modifier m3 {
        require(msg.sender == v1);
        _;
    }

    modifier m4   {
        require(v2[msg.sender] == true);
        _;
    }

    function f5(address v6) m3 {
        v1 = v6;
    }
    function f7(address v8, bool v9) m3 {
        v2[v8] = v9;
    }
}

interface C2 {
    function f10(address v11, uint256 v12, address v13, bytes v14);
}

contract C3 is C1 {
    
    string public v15;
    string public v16;
    uint8 public v17;
    uint256 public v18;
    uint256 v19;
    bool public v20;
    bool public v21;

    bool public v22 = true; 
    mapping (address => bool) public v23;


    modifier m24 {
        require(v23[msg.sender] || !v22);
        _;
    }


    
    mapping (address => uint256) public v25;


    mapping (address => mapping (address => uint256)) public v26;
    mapping (address =>  bool) public v27;

    mapping (address =>  bool) public v28; 

    
    event Transfer(address indexed v29, address indexed v30, uint256 v31);

    
    event Reward(address v29, address v30, uint256 v31, string v32, uint256 v33);

    
    event Burn(address indexed v29, uint256 v31);

    
    event Frozen(address indexed v34, bool v27);

    
    event Unlock(address indexed v34, address v29, uint256 v35);

    


    
    

    




    function C3() {
        uint256 v36 = 20000000000000000000000000;
        v25[msg.sender] = v36 ;              
        v18 = v36;                        
        v15 = "Gold Reward Token";                                   
        v16 = "GRX";                               
        v17 = 18;                            
        v19 = 1000000000000000;
        v20=false;
        v21=false;
        v23[msg.sender]=true;
        v28[msg.sender]=true;

    }

    




    function f37 (address v38,  uint256 v39 )  m3 {
        v25[v38] += v39;
        v18 += v39;
        Transfer(0, v1, v39);
        Transfer(v1, v38, v39);
    }

    function  f40(bool v41) {
        v21=v41;
    }

    function f42(uint v43) m3 {
        v19 = v43;
    }

    




    function f44 (address v38,  uint256 v45 )  m4 {
        f49(msg.sender, v38, v45);
        f48(v38, true);
    }

    




    function f46 (address v38, bool v47 )  internal  {

        v27[v38]=v47;
        Frozen(v38, v47);
    }



    




    function f48 (address v38, bool v47 )   {
        if(v47 || (!v47 && !v21)) {
            require(v23[msg.sender]);
        }

        f46(v38, v47);
    }



    


    function f49(address v11, address v50, uint v12) internal {
        require(v50 != 0x0);                                   

        require(!v27[v11]);                       
        require(v25[v11] >= v12);                
        require(v25[v50] + v12 > v25[v50]); 
        v25[v11] -= v12;                         
        v25[v50] += v12;                           
        Transfer(v11, v50, v12);
    }

    







    function f51(address v50, uint256 v12) m24 {
        require(!v27[msg.sender]);                       
        if (msg.sender.balance  < v19) {
            f79((v19 - msg.sender.balance) * v70);
        }
        f49(msg.sender, v50, v12);
    }



    mapping (address => uint256) public v52;
    mapping (address => mapping (address => uint256)) public v53; 
    mapping (address => mapping (uint32  => address)) public v54; 
    mapping (address => mapping (address => uint32)) public v55; 
    mapping (address => uint32) public v56; 

    
    mapping (address =>  uint256  ) public v57;

    







    function f58(address v50, uint256 v12, bool v59, string v32) {
        require(v50 != 0x0);
        require(!v27[msg.sender]);                       
        if (msg.sender.balance  < v19) {
            f79((v19 - msg.sender.balance) * v70);
        }
        if(!v59) {
            f49(msg.sender, v50, v12);
        }else{
            
            require(v25[msg.sender] >= v12);                
            require(v52[v50] + v12 > v52[v50]); 
            v25[msg.sender] -= v12;                         
            v52[v50] += v12;                           
            v53[v50][msg.sender] += v12;
            if(v55[v50][msg.sender]==0) {
                v56[v50] += 1;
                v54[v50][v56[v50]]=msg.sender;
            }
            v55[v50][msg.sender]+=1;
            v57[msg.sender]+= v12;
            Transfer(msg.sender, v50, v12);
        }

        Reward(msg.sender, v50, v12, v32, now);
    }

    







    function f60(address v50, uint256 v12) {
        require(!v27[msg.sender]);                       
        require(v53[msg.sender][v50] >= v12 );
        require(v52[msg.sender] >= v12);

        if (msg.sender.balance  < v19) {
            f79((v19 - msg.sender.balance) * v70);
        }
        v52[msg.sender] -= v12;                           
        v53[msg.sender][v50] -= v12;
        v25[v50] += v12;
        Transfer(msg.sender, v50, v12);
    }

    







    function f61(address v34, uint256 v12) {
        require(v52[v34] > v12);                       
        require(v53[v34][msg.sender] >= v12 );
        if(v12==0) v12=v53[v34][msg.sender];
        if (msg.sender.balance  < v19) {
            f79((v19 - msg.sender.balance) * v70);
        }
        v52[v34] -= v12;                           
        v53[v34][msg.sender] -= v12;
        v25[v34] += v12;
        Unlock(v34, msg.sender, v12);
    }



    








    function f62(address v11, address v50, uint256 v12) returns (bool v63) {
        require(!v27[v11]);                       
        require(v12 <= v26[v11][msg.sender]);     
        v26[v11][msg.sender] -= v12;
        f49(v11, v50, v12);
        return true;
    }

    







    function f64(address v65, uint256 v12)
    returns (bool v63) {
        v26[msg.sender][v65] = v12;
        return true;
    }

    








    function f66(address v65, uint256 v12, bytes v14) m3
    returns (bool v63) {
        C2 v67 = C2(v65);
        if (f64(v65, v12)) {
            v67.f10(msg.sender, v12, this, v14);
            return true;
        }
    }

    






    function f68(uint256 v12) m3 returns (bool v63) {
        require(v25[msg.sender] >= v12);   
        v25[msg.sender] -= v12;            
        v18 -= v12;                      
        Burn(msg.sender, v12);
        return true;
    }

    







    function f69(address v11, uint256 v12)  returns (bool v63) {
        require(v25[v11] >= v12);                
        require(v12 <= v26[v11][msg.sender]);    
        v25[v11] -= v12;                         
        v26[v11][msg.sender] -= v12;             
        v18 -= v12;                              
        Burn(v11, v12);
        return true;
    }

    











    uint256 public v70 = 608;
    uint256 public v71 = 760;

    function f72(uint256 v73, uint256 v74) m3 {
        v70 = v73;
        v71 = v74;
    }
    function f75(bool v76) m3 {
        v20=v76;
    }
    function f77(address v34, bool v76) m3 {
        v28[v34]=v76;
    }

    
    function f78() payable returns (uint256 v45){
        if(!v20 && !v28[msg.sender]) revert();
        v45 = msg.value * v71;                    

        require(v25[this] >= v45);               
        v25[msg.sender] += v45;                  
        v25[this] -= v45;                        
        Transfer(this, msg.sender, v45);               
        return v45;                                    
    }

    
    function f79(uint256 v45) returns (uint v80){
        require(!v27[msg.sender]);
        if(!v20 && !v28[msg.sender]) {
            require(v19 > v45/v70);
        }
        require(v25[msg.sender] >= v45);         
        v25[this] += v45;                        
        v25[msg.sender] -= v45;                  
        v80 = v45 / v70;
        require(msg.sender.send(v80));                
        Transfer(msg.sender, this, v45);               
        return v80;                                   
    }

    function() payable {
    }
    event Withdrawn(address indexed v30, uint256 v31);
    function f81(address v38, uint256 v45) m3 {
        v38.transfer(v45);
        Withdrawn(v38, v45);
    }

    function f82(address v34, bool v83) m3 {
        v23[v34]=v83;
    }

    function f84(bool v83) m3 {
        v22=v83;
    }
}