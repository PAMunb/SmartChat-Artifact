pragma solidity ^0.4.13;

contract C1 {
     function f1() constant returns (uint256 f1);
     function f2(address v3) constant returns (uint256 v4);
     function f5(address v6, uint256 v7) returns (bool v8);
     function f9(address v10, address v6, uint256 v7) returns (bool v8);
     function f11(address v12, uint256 v7) returns (bool v8);
     function f13(address v3, address v12) constant returns (uint256 v14);
     event Transfer(address indexed v10, address indexed v6, uint256 v7);
     event Approval(address indexed v3, address indexed v12, uint256 v7);
 }
  
  contract C2 is C1 {
     string public constant v15 = "BTCR";
     string public constant v16 = "Bitcoin Red";
     uint8 public constant v17 = 8;
     uint256 v18 = 21000000 * 10**8;
     

     address public v19;
  
     mapping(address => uint256) v20;
  
     mapping(address => mapping (address => uint256)) v21;
     
  
     function C2() {
         v19 = msg.sender;
         v20[v19] = 21000000 * 10**8;
     }
     
     modifier m22() {
        require(msg.sender == v19);
        _;
    }
     
     
     function f23(address[] v25) m22 {
         for (uint v24 = 0; v24 < v25.length; v24++) {
             v20[v19] -= 2000 * 10**8;
             v20[v25[v24]] += 2000 * 10**8;
             Transfer(v19, v25[v24], 2000 * 10**8);
         }
     }
     
  
     function f1() constant returns (uint256 f1) {
         f1 = v18;
     }
  

     function f2(address v3) constant returns (uint256 v4) {
        return v20[v3];
     }
 
     function f5(address v6, uint256 v26) returns (bool v8) {
         if (v20[msg.sender] >= v26 
            && v26 > 0
             && v20[v6] + v26 > v20[v6]) {
             v20[msg.sender] -= v26;
             v20[v6] += v26;
             Transfer(msg.sender, v6, v26);
            return true;
         } else {
             return false;
         }
     }
     
     
     function f9(
         address v10,
         address v6,
         uint256 v26
     ) returns (bool v8) {
         if (v20[v10] >= v26
             && v21[v10][msg.sender] >= v26
             && v26 > 0
             && v20[v6] + v26 > v20[v6]) {
             v20[v10] -= v26;
             v21[v10][msg.sender] -= v26;
             v20[v6] += v26;
             Transfer(v10, v6, v26);
             return true;
         } else {
            return false;
         }
     }
 
     function f11(address v12, uint256 v26) returns (bool v8) {
         v21[msg.sender][v12] = v26;
        Approval(msg.sender, v12, v26);
         return true;
     }
  
     function f13(address v3, address v12) constant returns (uint256 v14) {
         return v21[v3][v12];
    }
}
