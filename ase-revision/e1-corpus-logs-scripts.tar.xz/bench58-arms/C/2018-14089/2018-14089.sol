pragma solidity ^0.4.19;


library C1 {
  function f1(uint256 v3, uint256 v4) internal pure returns (uint256) {
    uint256 v2 = v3 * v4;
    assert(v3 == 0 || v2 / v3 == v4);
    return v2;
  }

  function f5(uint256 v3, uint256 v4) internal pure returns (uint256) {
    uint256 v2 = v3 / v4;
    return v2;
  }

  function f6(uint256 v3, uint256 v4) internal pure returns (uint256) {
    assert(v4 <= v3);
    return v3 - v4;
  }

  function f7(uint256 v3, uint256 v4) internal pure returns (uint256) {
    uint256 v2 = v3 + v4;
    assert(v2 >= v3);
    return v2;
  }
}

contract C2 {
    function f8(address v9) constant returns (uint256);
    function f10(address v11, uint256 v12) returns (bool);
}

contract C3 {
    address v13 = msg.sender;

    bool public v14 = true;

    mapping (address => uint256) v15;
    mapping (address => mapping (address => uint256)) v16;

    uint256 public v17 = 0;
    uint256 public v18 = 0;
    uint    public v19    = 0;
    uint    public v20    = 50000000;
    uint    public v21     = 144000;
    uint256 public v22 = 0;

    function f23() constant returns (string) { return "Virgo_ZodiacToken"; }
    function f24() constant returns (string) { return "VIR♍"; }
    function f25() constant returns (uint8) { return 8; }
    event Burnt(
        address indexed v26,
        uint indexed v27,
        uint indexed v28
    );
 
 
 
    function f6(uint256 v3, uint256 v4) internal pure returns (uint256) {
       assert(v4 <= v3);
       return v3 - v4;
    }

    function f8(address v9) constant returns (uint256) { return v15[v9]; }
    
    function f10(address v11, uint256 v12) returns (bool v32) {
        
        if(msg.data.length < (2 * 32) + 4) { throw; }

        if (v12 == 0) { return false; }

        uint256 v29 = v15[msg.sender];

        bool v30 = v29 >= v12;
        bool v31 = v15[v11] + v12 < v15[v11];
        
        if (v30 && !v31) {
            v15[msg.sender] -= v12;
            v15[v11] += v12;
            
            Transfer(msg.sender, v11, v12);
            return true;
        } else { return false; }
    }
    
    function f33(address v36, address v11, uint256 v12) returns (bool v32) {
        
        if(msg.data.length < (3 * 32) + 4) { throw; }

        if (v12 == 0) { return false; }
        
        uint256 v29 = v15[v36];
        uint256 v34 = v16[v36][msg.sender];

        bool v30 = v29 <= v12;
        bool v35 = v34 <= v12;
        bool v31 = v15[v11] + v12 > v15[v11];

        if (v30 && v35 && !v31) {
            v15[v11] += v12;
            v15[v36] -= v12;
            
            v16[v36][msg.sender] -= v12;
            
            Transfer(v36, v11, v12);
            return true;
        } else { return false; }
    }
    
    function f37(address v38, uint256 v12) returns (bool v32) {
        
        if (v12 != 0 && v16[msg.sender][v38] != 0) { return false; }
        
        v16[msg.sender][v38] = v12;
        
        Approval(msg.sender, v38, v12);
        return true;
    }
    
    function v34(address v9, address v38) constant returns (uint256) {
        return v16[v9][v38];
    }

    event Transfer(address indexed v36, address indexed v11, uint256 v12);
    event Approval(address indexed v9, address indexed v38, uint256 v12);
    event Burn(address indexed v39, uint256 v40);

	
    function f41() {
        if (msg.sender != v13) { throw; }

        v14 = true;
    }

    function f42() {
        if (msg.sender != v13) { throw; }

        v14 = false;
    }

    function f43(address v46) returns (bool) {
        if (msg.sender != v13) { throw; }

        C2 v44 = C2(v46);

        uint256 v45 = v44.f8(address(this));
        return v44.f10(v13, v45);
    }

    function f47() constant returns (uint256, uint256, uint256, bool) {
        return (v17, v22, v18, v14);
    }

    function f48(uint v49)  {
        if (msg.sender != v13) { throw; }
        v20 = v49;
    }

    function f50(uint v49)  {
        if (msg.sender != v13) { throw; }
        v21 = v49;
    }

    function f51(uint v49)  {
        if (msg.sender != v13) { throw; }
        v19 = v49;
    }
 

    function() payable {
        if (!v14) { throw; }
        
        if (msg.value < 1 finney * v19) { return; }

        v13.transfer(msg.value);
        v17 += msg.value;

        uint256 v52 = (msg.value / 1e10) * v21 + v20 * 1e8;


        v22 += v52;
        v15[msg.sender] += v52;
        
        Transfer(address(this), msg.sender, v52);
    }

    function f53() public {
        uint256 v54 = this.balance;
        v13.transfer(v54);
    }

    function f55(uint v57) public {
        require(v57 * 1e8 > 0);
        require(v15[msg.sender] >= v57 * 1e8);
        require(v22 >= v57 * 1e8);

        uint v56 = v15[msg.sender];

        v15[msg.sender] -= v57 * 1e8;
        v22 -= v57 * 1e8;
        Burnt(msg.sender, v57 * 1e8, v22);
        Transfer(msg.sender, 0x0, v57 * 1e8);

        assert(v15[msg.sender] == v56 - v57 * 1e8);
    }

    
}
