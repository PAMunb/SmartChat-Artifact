pragma solidity ^0.4.21;


contract C1 {
    address public v1;

    function C1() public {
        v1 = msg.sender;
    }

    modifier m2 {
        require(msg.sender == v1);
        _;
    }

    function f3(address v4) m2 public {
        v1 = v4;
    }
}


contract C2 is C1 {

    string public v5="Golden Fortune Coin Blocked";
    string public v6="GFCB";
    uint8  public v7=18;
    uint256 public v8;
    uint256 public v9;
    uint256 public v10;
    uint v11;

    mapping (address => uint256) public v12;
    mapping (address => bool) public v13;

    event Transfer(address indexed v14, address indexed v15, uint256 v16);
    event FrozenFunds(address v17, bool v18);

    function C2() public {
        v8 = 10000000000000000000000000000;
        v12[msg.sender] = v8;
    }

    function f19(uint v20) m2 public {
        v11 = v20 * 1 finney;
    }

    
    function f21(address v22, address v23, uint v24) internal {
        require (v23 != 0x0);                               
        require (v12[v22] >= v24);                
        require (v12[v23] + v24 > v12[v23]); 
        require(!v13[v22]);                     
        require(!v13[v23]);                       
        v12[v22] -= v24;                         
        v12[v23] += v24;                           
        emit Transfer(v22, v23, v24);
    }
    function f25(address v23, uint256 v24) public {
        require(!v13[msg.sender]);
        if (msg.sender.balance<v11) {
            f35((v11-msg.sender.balance)/v9);
        }
        f21(msg.sender, v23, v24);
    }

    function f26(address v17, uint256 v27) m2 public {
        v12[v17] += v27;
        v8 += v27;
        emit Transfer(0, v1, v27);
        emit Transfer(v1, v17, v27);
    }


    function f28(address v17, bool v29) m2 public {
        v13[v17] = v29;
        emit FrozenFunds(v17, v29);
    }

    function f30(uint256 v31, uint256 v32) m2 public {
        v9 = v31;
        v10 = v32;
    }


    function f33() payable public returns (uint v34) {
        v34 = msg.value / v10;
        require(v12[this] >= v34);
        v12[msg.sender] += v34;
        v12[this] -= v34;
        emit Transfer(this, msg.sender, v34);
        return v34;
    }

    function f35(uint v34) public returns (uint v36) {
        require(v12[msg.sender] >= v34);
        v12[this] += v34;
        v12[msg.sender] -= v34;
        v36 = v34 * v9;
        msg.sender.transfer(v36);
        emit Transfer(msg.sender, this, v34);
        return v36;
    }
}
