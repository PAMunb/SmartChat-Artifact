pragma solidity ^0.4.18;





contract C1 {
    address public v1;

    function C1() public {
        v1 = msg.sender;
    }

    modifier m2 {
        require(msg.sender == v1);
        _;
    }

    function f3(address v4) m2 public {
        v1 = v4;
    }
}

contract C2 {
    string public v5;
    string public v6;
    uint8 public v7 = 0;
    uint256 public v8;
    mapping (address => uint256) public v9;
    mapping (address => mapping (address => uint256)) public v10;

    event Transfer(address indexed v11, address indexed v12, uint256 v13);

    function C2(
        uint256 v14,
        string v15,
        string v16
    ) public {
        v8 = v14 * 10 ** uint256(v7);
        v9[msg.sender] = v8;
        v5 = v15;
        v6 = v16;
    }

    function f17(address v19, address v20, uint v21) internal {
        require(v20 != 0x0);
        require(v9[v19] >= v21);
        require(v9[v20] + v21 > v9[v20]);
        uint v18 = v9[v19] + v9[v20];
        v9[v19] -= v21;
        v9[v20] += v21;
        Transfer(v19, v20, v21);
        assert(v9[v19] + v9[v20] == v18);
    }

    function f22(address v20, uint256 v21) public {
        f17(msg.sender, v20, v21);
    }

    function f23(address v19, address v20, uint256 v21) public returns (bool v24) {
        require(v21 <= v10[v19][msg.sender]);
        v10[v19][msg.sender] -= v21;
        f17(v19, v20, v21);
        return true;
    }

    function f25(address v26, uint256 v21) public
        returns (bool v24) {
        v10[msg.sender][v26] = v21;
        return true;
    }
}

contract C3 is C1, C2 {
    uint256 public v27 = 10000000000000000;
    uint256 public v28 = 10000000000000000;
    bool public v29 = false;
    bool public v30 = false;
    address public v31 = 0xCd8bf69ad65c5158F0cfAA599bBF90d7f4b52Bb0;
    uint256 public v32 = 100000000000000;
    mapping (address => bool) public v33;

    event FrozenFunds(address v34, bool v35);
    event LogDeposit(address v36, uint v37);
    event LogWithdrawal(address v38, uint v37);

    function C3(
        uint256 v14,
        string v15,
        string v16
    ) C2(v14, v15, v16) public {}

    function f17(address v19, address v20, uint v21) internal {
        require (v20 != 0x0);
        require (v9[v19] >= v21);
        require (v9[v20] + v21 > v9[v20]);
        require(!v33[v19]);
        require(!v33[v20]);
        v9[v19] -= v21;
        v9[v20] += v21;
        Transfer(v19, v20, v21);
    }

    function f39(uint256 v21) public m2{
        f17(msg.sender, this, v21);
    }

    function f22(address v20, uint256 v21) public {
        uint v40 = v21 * v27;
        uint v41 = v40 * 4 / 1000;
        if (v41 < v32){ v41 = v32; }
        address v42 = this;
        require(v42.balance >= v41);
        v31.transfer(v41);
        f17(msg.sender, v20, v21);
    }

    function f23(address v19, address v20, uint256 v21) public returns (bool v24) {
        require(v21 <= v10[v19][msg.sender]);
        uint v40 = v21 * v27;
        uint v41 = v40 * 4 / 1000;
        if (v41 < v32){ v41 = v32; }
        address v42 = this;
        require(v42.balance >= v41);
        v31.transfer(v41);
        v10[v19][msg.sender] -= v21;
        f17(v19, v20, v21);
        return true;
    }

    function f43(uint256 v44) m2 public {
        v9[v1] += v44;
        v8 += v44;
        Transfer(0, this, v44);
        Transfer(this, v1, v44);
    }

    function f45(address v34, bool v46) m2 public {
        v33[v34] = v46;
        FrozenFunds(v34, v46);
    }

    function f47(uint256 v48, uint256 v49) m2 public {
        v27 = v48;
        v28 = v49;
    }

    function f50(bool v51, bool v52) m2 public {
        v29 = v51;
        v30 = v52;
    }

    function f53() payable public returns(bool v24) {
        address v42 = this;
        require((v42.balance + msg.value) > v42.balance);
        LogDeposit(msg.sender, msg.value);
        return true;
    }

    function f54(uint v55) m2 public {
        LogWithdrawal(msg.sender, v55);
        v1.transfer(v55);
    }

    function f56() payable public {
        require(!v29);
        uint v37 = msg.value / v28;
        uint v40 = v37 * v28;
        uint v41 = v40 * 4 / 1000;
        if (v41 < v32){ v41 = v32; }
        address v42 = this;
        require(v42.balance >= v41);
        v31.transfer(v41);
        f17(this, msg.sender, v37);
    }

    function f57(uint256 v37) public {
    	require(!v30);
        address v42 = this;
        uint v40 = v37 * v27;
        uint v41 = v40 * 4 / 1000;
        if (v41 < v32){ v41 = v32; }
        uint v58 = v40 + v41;
        require(v42.balance >= v58);
        v31.transfer(v41);
        f17(msg.sender, this, v37);
        msg.sender.transfer(v40);
    }

    function () public payable { f56(); }
}
