pragma solidity ^0.4.21;

library C1 {
    function f1(uint256 v2, uint256 v3) internal pure returns (uint256 v4) {
        if (v2 == 0) {
            return 0;
        }
        v4 = v2 * v3;
        assert(v4 / v2 == v3);
        return v4;
    }

    function f5(uint256 v2, uint256 v3) internal pure returns (uint256) {
        return v2 / v3;
    }

    function f6(uint256 v2, uint256 v3) internal pure returns (uint256) {
        assert(v3 <= v2);
        return v2 - v3;
    }

    function f7(uint256 v2, uint256 v3) internal pure returns (uint256 v4) {
        v4 = v2 + v3;
        assert(v4 >= v2);
        return v4;
    }
}





contract C2{
    






    function f8(address v9, uint v10, bytes v11) public;
}

contract C3 {
    uint public v12;
    function f13(address v14) public constant returns (uint);
    function f15(address v16, uint v17) public;
    event Transfer(address indexed v18, address indexed v16, uint v17);
}

contract C4 is C3 {
    function f19(address v20, address v21) public constant returns (uint);
    function f22(address v18, address v16, uint v17) public;
    function f23(address v21, uint v17) public;
    event Approval(address indexed v20, address indexed v21, uint v17);
}

contract C5 is C3 {
    using C1 for uint;

    mapping(address => uint) balances;

    modifier m24(uint v25) {
        require(msg.data.length >= v25 + 4);
        _;
    }

    function f15(address _to, uint v10) m24(2 * 32) public {
        uint codeLength;
        bytes memory v26;

        assembly {
            codeLength := extcodesize(_to)
        }


        balances[msg.sender] = balances[msg.sender].f6(v10);
        balances[_to] = balances[_to].f7(v10);

        if(codeLength > 0) {
            C2 v27 = C2(_to);
            v27.f8(msg.sender, v10, v26);
        }

        emit Transfer(msg.sender, _to, v10);
    }

    function f13(address v28) public constant returns (uint v29) {
        return balances[v28];
    }

}

contract C6 is C5, C4 {

    mapping (address => mapping (address => uint)) v30;

    function f22(address v9, address _to, uint v10) public {
        uint256 v31 = v30[v9][msg.sender];
        uint codeLength;
        bytes memory v26;

        assembly {
            codeLength := extcodesize(_to)
        }

        balances[_to] = balances[_to].f7(v10);
        balances[v9] = balances[v9].f6(v10);
        v30[v9][msg.sender] = v31.f6(v10);

        if(codeLength>0) {
            C2 v27 = C2(_to);
            v27.f8(msg.sender, v10, v26);
        }

        emit Transfer(v9, _to, v10);
    }

    function f23(address v32, uint v10) public {
        v30[msg.sender][v32] = v10;
        emit Approval(msg.sender, v32, v10);
    }

    function f19(address v28, address v32) public constant returns (uint v33) {
        return v30[v28][v32];
    }

}

contract C7 is C6 {

    function f34(uint v10) public {
        require(v10 > 0);
        address v35 = msg.sender;
        balances[v35] = balances[v35].f6(v10);
        v12 = v12.f6(v10);
        emit Burn(v35, v10);
    }

    event Burn(address indexed v35, uint indexed v17);

}

contract C8 is C7 {

    string public v36 = "Etherty Token";
    string public v37 = "ETY";
    uint public v38 = 18;
    uint constant v39 = 240 * 1e6 * 1e18;

    address public v40;

    bool public v41 = true;

    function C8(address v42) public {
        v40 = v42;
    }

    function f43(address v44, uint v10) external {
        require(msg.sender == v40);
        require(v10 != 0);
        require(v12 + v10 <= v39);

        balances[v44] += v10;
        v12 += v10;
        emit Transfer(0x0, v44, v10);
    }

    function f34(uint v10) public {
        require(msg.sender == v40);
        super.f34(v10);
    }

    function f45() external {
        require(msg.sender == v40);
        v41 = false;
    }

    function f15(address _to, uint v10) public {
        require(!v41);
        super.f15(_to, v10);
    }

    function f22(address v9, address _to, uint v10) m24(3 * 32) public {
        require(!v41);
        super.f22(v9, _to, v10);
    }

    function f23(address v32, uint v10) public {
        require(!v41);
        super.f23(v32, v10);
    }
}
