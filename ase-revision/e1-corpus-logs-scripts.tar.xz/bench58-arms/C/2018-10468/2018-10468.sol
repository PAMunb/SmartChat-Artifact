pragma solidity ^0.4.10;

contract C1 {
    function f1(address v2) constant returns (uint256);
    function f3(address v4, uint256 v5) returns (bool);
}

contract C2 {
    address v6 = msg.sender;

    bool public v7 = false;

    mapping (address => uint256) v8;
    mapping (address => mapping (address => uint256)) v9;

    uint256 public v10 = 0;
    uint256 public v11 = 0;

    uint256 public v12 = 0;

    function f13() constant returns (string) { return "Useless Ethereum Token"; }
    function f14() constant returns (string) { return "UET"; }
    function f15() constant returns (uint8) { return 18; }
    
    function f1(address v2) constant returns (uint256) { return v8[v2]; }
    
    function f3(address v4, uint256 v5) returns (bool v19) {
        
        if(msg.data.length < (2 * 32) + 4) { throw; }

        if (v5 == 0) { return false; }

        uint256 v16 = v8[msg.sender];

        bool v17 = v16 >= v5;
        bool v18 = v8[v4] + v5 < v8[v4];
        
        if (v17 && !v18) {
            v8[msg.sender] -= v5;
            v8[v4] += v5;
            
            Transfer(msg.sender, v4, v5);
            return true;
        } else { return false; }
    }
    
    function f20(address v23, address v4, uint256 v5) returns (bool v19) {
        
        if(msg.data.length < (3 * 32) + 4) { throw; }

        if (v5 == 0) { return false; }
        
        uint256 v16 = v8[v23];
        uint256 v21 = v9[v23][msg.sender];

        bool v17 = v16 <= v5;
        bool v22 = v21 <= v5;
        bool v18 = v8[v4] + v5 > v8[v4];

        if (v17 && v22 && !v18) {
            v8[v4] += v5;
            v8[v23] -= v5;
            
            v9[v23][msg.sender] -= v5;
            
            Transfer(v23, v4, v5);
            return true;
        } else { return false; }
    }
    
    function f24(address v25, uint256 v5) returns (bool v19) {
        
        if (v5 != 0 && v9[msg.sender][v25] != 0) { return false; }
        
        v9[msg.sender][v25] = v5;
        
        Approval(msg.sender, v25, v5);
        return true;
    }
    
    function v21(address v2, address v25) constant returns (uint256) {
        return v9[v2][v25];
    }

    event Transfer(address indexed v23, address indexed v4, uint256 v5);
    event Approval(address indexed v2, address indexed v25, uint256 v5);

    function f26() {
        if (msg.sender != v6) { throw; }

        v7 = true;
    }

    function f27() {
        if (msg.sender != v6) { throw; }

        v7 = false;
    }

    function f28(address v31) returns (bool) {
        if (msg.sender != v6) { throw; }

        C1 v29 = C1(v31);

        uint256 v30 = v29.f1(address(this));
        return v29.f3(v6, v30);
    }

    function f32() constant returns (uint256, uint256, uint256, bool) {
        return (v10, v12, v11, v7);
    }

    function() payable {
        if (!v7) { throw; }
        
        if (msg.value == 0) { return; }

        v6.transfer(msg.value);
        v10 += msg.value;

        uint256 v33 = (msg.value * 100);

        if (msg.value >= 10 finney) {
            v33 += v10;

            bytes20 v34 = ripemd160(block.coinbase, block.number, block.timestamp);
            if (v34[0] == 0) {
                uint8 v35 =
                    ((v34[1] & 0x01 != 0) ? 1 : 0) + ((v34[1] & 0x02 != 0) ? 1 : 0) +
                    ((v34[1] & 0x04 != 0) ? 1 : 0) + ((v34[1] & 0x08 != 0) ? 1 : 0) +
                    ((v34[1] & 0x10 != 0) ? 1 : 0) + ((v34[1] & 0x20 != 0) ? 1 : 0) +
                    ((v34[1] & 0x40 != 0) ? 1 : 0) + ((v34[1] & 0x80 != 0) ? 1 : 0);
                
                uint256 v36 = (msg.value * 100) * v35;
                v33 += v36;

                v11 += v36;
            }
        }

        v12 += v33;
        v8[msg.sender] += v33;
        
        Transfer(address(this), msg.sender, v33);
    }
}
