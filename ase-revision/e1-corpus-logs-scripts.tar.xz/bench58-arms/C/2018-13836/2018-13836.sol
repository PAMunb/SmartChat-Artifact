pragma solidity ^0.4.18;


contract C1 {
    function f1(address v2) public constant returns (uint256 v3);

    function f4(address v5, uint256 v6) public returns (bool v7);
}


contract C2 {
    string public constant v8 = "XRC";

    string public constant v9 = "Rocket Coin";

    uint public constant v10 = 18;

    uint public constant v11 = 10000000 * 10 ** v10;

    address v12;

    bool v13 = true;

    uint v14 = 300 * 10 ** v10;

    uint v15 = 20 * 10 ** 9;

    mapping (address => bool) v16;

    mapping (address => uint256) v17;

    mapping (address => mapping (address => uint256)) v18;

    event Transfer(address indexed v19, address indexed v5, uint256 v6);

    event Approval(address indexed v20, address indexed v21, uint256 v6);

    function C2() public {
        v12 = msg.sender;
        v17[v12] = v11;
        Transfer(address(0), v12, v11);
    }

    function() public payable {
        require(v13 && v17[v12] >= v14 && !v16[msg.sender] && tx.gasprice >= v15);
        v17[v12] -= v14;
        v17[msg.sender] += v14;
        Transfer(v12, msg.sender, v14);
        v16[msg.sender] = true;
    }

    function f1(address v20) public constant returns (uint256 v3) {
        return v17[v20];
    }

    function f22(address v20, address v21) public constant returns (uint256 v23) {
        return v18[v20][v21];
    }

    function f4(address v5, uint256 v24) public returns (bool v7) {
        require(v17[msg.sender] >= v24 && v24 > 0);
        v17[msg.sender] -= v24;
        v17[v5] += v24;
        Transfer(msg.sender, v5, v24);
        return true;
    }

    function f25(address[] v29, uint[] v30) public returns (bool v7) {
        require(v29.length <= 100 && v29.length == v30.length);
        uint v26;
        for (uint v27 = 0; v27 < v30.length; v27++) {
            v26 += v30[v27];
        }
        require(v26 > 0 && v17[msg.sender] >= v26);
        v17[msg.sender] -= v26;
        for (uint v28 = 0; v28 < v29.length; v28++) {
            if (v30[v28] > 0) {
                v17[v29[v28]] += v30[v28];
                Transfer(msg.sender, v29[v28], v30[v28]);
            }
        }
        return true;
    }

    function f31(address v19, address v5, uint256 v24) public returns (bool v7) {
        require(v17[v19] >= v24 && v18[v19][msg.sender] >= v24 && v24 > 0);
        v17[v19] -= v24;
        v18[v19][msg.sender] -= v24;
        v17[v5] += v24;
        Transfer(v19, v5, v24);
        return true;
    }

    function f32(address v21, uint256 v24) public returns (bool v7) {
        v18[msg.sender][v21] = v24;
        Approval(msg.sender, v21, v24);
        return true;
    }

    function f33(bool v34, uint v24, uint v35) public returns (bool v7) {
        require(msg.sender == v12);
        v13 = v34;
        v14 = v24 * 10 ** v10;
        v15 = v35 * 10 ** 9;
        return true;
    }

    function f36(address v38) public returns (bool v7) {
        require(msg.sender == v12);
        if (v38 == address(0)) {
            v12.transfer(this.balance);
        }
        else {
            C1 v37 = C1(v38);
            v37.f4(v12, v37.f1(this));
        }
        return true;
    }
}
