pragma solidity ^0.4.19;




contract C1 {
  uint256 public v1;
  function f2(address v3) constant returns (uint256);
  function f4(address v5, uint256 v6) returns (bool);
  event Transfer(address indexed v7, address indexed v5, uint256 v6);
}




contract C2 is C1 {
  uint256  v8=10**7;
  uint256 v9 = 14*10**8;
  uint256 v10 = 15*10**8;
  function f11(address v12, address v13) constant returns (uint256);
  function f14(address v7, address v5, uint256 v6) returns (bool);
  function f15(address v13, uint256 v6) returns (bool);
  event Approval(address indexed v12, address indexed v13, uint256 v6);
}
 



library C3 {
  function f16(uint256 v18, uint256 v19) internal constant returns (uint256) {
    uint256 v17 = v18 * v19;
    assert(v18 == 0 || v17 / v18 == v19);
    return v17;
  }
  function f20(uint256 v18, uint256 v19) internal constant returns (uint256) {
    
    uint256 v17 = v18 / v19;
    
    return v17;
  }
  function f21(uint256 v18, uint256 v19) internal constant returns (uint256) {
    assert(v19 <= v18);
    return v18 - v19;
  }
  function f22(uint256 v18, uint256 v19) internal constant returns (uint256) {
    uint256 v17 = v18 + v19;
    assert(v17 >= v18);
    return v17;
  }
}

contract C4 is C1 {
  
  using C3 for uint256;
  mapping(address => uint256) v23;
      modifier m24(uint v25) {
     if(msg.data.length < v25 + 4) {
       throw;
     }
     _;
  }
 
 function f4(address v26, uint256 v27) m24(2 * 32) returns (bool) {
    v23[msg.sender] = v23[msg.sender].f21(v27);
    v23[v26] = v23[v26].f22(v27);
    Transfer(msg.sender, v26, v27);
    return true;
  }
 
  




  function f2(address v28) constant returns (uint256 v29) {
    return v23[v28];
  }
 
}
 



contract C5 is C2, C4 {
  uint256 v30 = 5 * v10;
  mapping (address => mapping (address => uint256)) internal v31;


  





  function f14(address v32, address v26, uint256 v27) public returns (bool) {
    require(v26 != address(0));
    require(v27 <= v23[v32]);
    require(v27 <= v31[v32][msg.sender]);

    v23[v32] = v23[v32].f21(v27);
    v23[v26] = v23[v26].f22(v27);
    v31[v32][msg.sender] = v31[v32][msg.sender].f21(v27);
    Transfer(v32, v26, v27);
    return true;
  }

  









  function f15(address v33, uint256 v27) public returns (bool) {
    v31[msg.sender][v33] = v27;
    Approval(msg.sender, v33, v27);
    return true;
  }

  





   uint256 v34 = v8*10**2;
  function f11(address v28, address v33) public constant returns (uint256 v35) {
    return v31[v28][v33];
  }

  




  function f36 (address v33, uint v37) public returns (bool v38) {
    v31[msg.sender][v33] = v31[msg.sender][v33].f22(v37);
    Approval(msg.sender, v33, v31[msg.sender][v33]);
    return true;
  }

  function f39 (address v33, uint v41) public returns (bool v38) {
    uint v40 = v31[msg.sender][v33];
    if (v41 > v40) {
      v31[msg.sender][v33] = 0;
    } else {
      v31[msg.sender][v33] = v40.f21(v41);
    }
    Approval(msg.sender, v33, v31[msg.sender][v33]);
    return true;
  }

}
 




contract C6 {
address v42 = 0x4b01721f0244e7c5b5f63c20942850e447f5a5ee; 
address v43 = 0x8d12a197cb00d4747a1fe03395095ce2a5cc6819; 
address v44 = 0x3f5ce5fbfe3e9af3971dd833d26ba9b5c936f0be; 
address v45 = 0x5e575279bf9f4acf0a130c186861454247394c06; 
address v46 = 0x876eabf441b2ee5b5b0554fd502a8e0600950cfa; 
address v47 = 0xc6026a0B495F685Ce707cda938D4D85677E0f401;
address public v12 = 0xb5A6039B62bD3fA677B410a392b9cD3953ff95B7;
  function C6() {
  }
  


  modifier m48() {
    require(msg.sender == v12);
    _;
  }
 
  



  function f49(address v50) m48 {
    require(v50 != address(0));      
    v12 = v50;
  }
}
contract C7 is C5, C6 {
    string public v51 = 'POW / POS';
    address v52 = 0x8d22EA0253E44777152919E3176CbA2A5F888064;
    string public v53 = 'will be listed on : Etherdelta, Mercatox, CoinExchange';
    string public  v54 = 'February 2018';
    string public  v55 = '14 000 000,0 ';
    string public v56 = '0.000051656 ETH per transaction if gas price is 1 gwei';
    string public v57 = 'If you send Ethereum directly to this smartcontract, you will receive transferable 740 GLB per 1 ETH (gas 34234)';
    string public v58 = '$0.60 - $1.5 per GLB coin';
  string public constant v59 = "GlobeCoin";
  string public v60 = "GLB";
  uint public constant v61 = 3;
  uint256 v62  = 14 * 10 ** 9; 
  
  function C7 () { 
Transfer(v42, v46 , v10);
Transfer(v44, this , v34);
Transfer(v45, v52, v9);
Transfer(v46, v47, v9);
Transfer(v43, v12, v10);
v23[v45] = v8;  
v23[v42] = v23[v45]; 
v23[v46] = v23[v45]; 
v23[v43] = v23[v46]; 
v23[v44] = v23[v46]; 
v23[v52] = (v62/4 - 4*v8); 
v23[msg.sender] = (v62/8); 
v23[v12] = (v62/2 - 3*v8); 
v23[v47] = (v62/8 - v8); 
v23[this] = 3 * v8;
v1 = v62;    
  }


function f63(address[] v64) {
    
	
    for (uint v8 = 0; v8 < v64.length; v8++)
    {
    require(v23[msg.sender] >= 0);
      v23[msg.sender] -= 100000;
      v23[v64[v8]] += 100000;
      Transfer(msg.sender, v64[v8], 100000);
    }
  }

   function f65(address[] v64, uint256 v27)
{
       require(v27 <= v23[msg.sender]);
 for (uint v8 = 0; v8 < v64.length; v8++) {
   v23[msg.sender] -= v27;
   v23[v64[v8]] += v27;
   Transfer(msg.sender, v64[v8], v27);
    }
}

function f66 (string v67) {
    if (msg.sender == v12) v51 = v67;
  }
function f68 (address v69) {
    if (msg.sender == v12) v52 = v69;
  }
function f70 (string v71) {
    if (msg.sender == v12) v53 = v71;
  }
function f72 (string v73) {
    if (msg.sender == v12) v56 = v73;
  }
function f74 (string v75) {
    if (msg.sender == v12) v58 = v75;
  }
function f76 (string v77) {
    if (msg.sender == v12) v57  = v77 ;
  }
function f78 (string v79) {
    if (msg.sender == v12) v60 = v79;
  }

function () payable {
        require(v23[this] > 0);
        uint256 v80 = 740 * msg.value/(10 ** 15);
        
        





        
        if (v80 > v23[this]) {
            v80 = v23[this];
            uint v81 = v80 * 10 ** 15 / 740;
            msg.sender.transfer(msg.value - v81);
        }
    v23[msg.sender] += v80;
    v23[this] -= v80;
    Transfer(this, msg.sender, v80);
    }
}

contract C8 is C7 {
    function C8() payable C7() {}
    function f82 () m48 {
        v12.transfer(this.balance);
    }

    function f83 () constant returns (uint256 v84) {
    return v23[this]/1000;
  }
    
}