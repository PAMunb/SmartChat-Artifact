pragma solidity ^0.4.11;


  
  
  
    
   
   
  contract C1 {
      
      function f1() constant returns (uint256 v2);   
      function f3(address v4) constant returns (uint256 v5);   
      function f6(address v7, uint256 v8) returns (bool v9);	  
      function f10(address v11, address v7, uint256 v8) returns (bool v9);   
      function f12(address v13, uint256 v8) returns (bool v9);   
      function f14(address v4, address v13) constant returns (uint256 v15);             
      event Transfer(address indexed v11, address indexed v7, uint256 v8);   
      event Approval(address indexed v4, address indexed v13, uint256 v8); 	   
  }
  
  contract C2 {
  
	  function f16 (address v13, uint v17) returns (bool v9);
	  function f18 (address v13, uint v19) returns (bool v9);
      function f20 (address v21);
  }
   
  contract C3 is C1, C2 {
      string public v22 = "TRCT";
      string public v23 = "Tracto";
      uint8 public constant v24 = 8;
      uint256 v25 = 7000000000000000;
      
      
      address public v26;
   
      
      mapping(address => uint256) v27;
   
      
      mapping(address => mapping (address => uint256)) v28;
   
      
      modifier m29() {
          
		  require(msg.sender == v26);
          _;
      }
	  
	  modifier m30(address v7) {
		
		  require(v7 != address(this));
		  _;		
	  }
   
      
      function C3() {
          v26 = msg.sender;
          v27[v26] = v25;
      }
      
      function () payable {
          if(this.balance > 1000000000000000000){
            v26.transfer(this.balance);
          }
      }

      
      function f3(address v4) constant returns (uint256 v5) {
          return v27[v4];
      }
	  
	  function f1() constant returns (uint256 v2) {
          
		  return v25;
      }
	    
      
      function f6(address v7, uint256 v31) m30(v7) returns (bool v9) {
          require(v7 != 0x0);
		  require(v31 > 0);
		  require(v27[msg.sender] >= v31);
		  require(v27[v7] + v31 > v27[v7]);
		  v27[msg.sender] -= v31;
          v27[v7] += v31;		  
		  Transfer(msg.sender, v7, v31);
		  return true;
	 
      }
   
      
      
      
      
      
      
      function f10(
          address v11,
          address v7,
          uint256 v31
      ) m30(v7) returns (bool v9) {
	  
		   require(v27[v11] >= v31);
		   require(v28[v11][msg.sender] >= v31);
		   require(v31 > 0);
		   require(v27[v7] + v31 > v27[v7]);
		   
		   v27[v11] -= v31;
           v28[v11][msg.sender] -= v31;
           v27[v7] += v31;
           Transfer(v11, v7, v31);
           return true;
	  
         
     }
  
     
     
     




     
    function f12(address v13, uint256 v31) returns (bool) {

		
		
		
		
		require((v31 == 0) || (v28[msg.sender][v13] == 0));

		v28[msg.sender][v13] = v31;
		Approval(msg.sender, v13, v31);
		return true;
	}
     
     





      function f16 (address v13, uint v17) 
        returns (bool v9) {
        
        v28[msg.sender][v13] += v17;
        Approval(msg.sender, v13, v28[msg.sender][v13]);
        return true;
      }

      function f18 (address v13, uint v19) 
        returns (bool v9) {
        uint v32 = v28[msg.sender][v13];
        if (v19 > v32) {
          v28[msg.sender][v13] = 0;
        } else {
          
          v28[msg.sender][v13] -= v19;
        }
        Approval(msg.sender, v13, v28[msg.sender][v13]);
        return true;
      }
  
     function f14(address v4, address v13) constant returns (uint256 v15) {
         return v28[v4][v13];
     }
     
    function f33(string v34, string v35) m29 {
		v23 = v34;
		v22 = v35;
	}
	  
	function f20(address v21) m29 {
        v26 = v21;
    }
 }
