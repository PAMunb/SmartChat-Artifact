pragma solidity ^0.4.24;

contract C1
{
    string public v1;
    string public v2; 
    uint256 public v3;
    uint256 public v4;
    mapping(address => uint256) public v5;
    mapping (address => mapping (address => uint256)) public v6;
    
    event Transfer(address indexed v7, address indexed v8, uint256 v9);
    event Approval(address indexed v10, address indexed v11, uint256 v9);
    
    function f12(address v13, uint256 v14) public returns (bool) {
        if( v14 > v5[msg.sender] || (v5[v13]+v14) < v5[v13]) return false;
        v5[msg.sender] -= v14;
        v5[v13] += v14;
        Transfer(msg.sender, v13, v14);
        return true;
    }
    
    function f15(address v16, address v13, uint256 v14) public returns (bool) {
        if( v14 > v5[v16] || v14 > v6[v16][msg.sender] || (v5[v13]+v14) < v5[v13] ) return false;
        v5[v16] -=v14;
        v5[v13] += v14;
        v6[v16][msg.sender] -= v14;
        Transfer(v16, v13, v14);
        return true;
    }
    
    function f17(address v18, uint256 v14) public returns (bool) {
        v6[msg.sender][v18] = v14;
        Approval(msg.sender, v18, v14);
        return true;
    }
}

contract C2 is C1
{
    function f19(address[] v23, uint256 v14) public returns (bool) { 
        uint256 v20 = v23.length;
        uint256 v21 = v20 * v14;
        if(v21 == 0) return false;
        if(v5[msg.sender] < v21) return false;
        v5[msg.sender] -= v21;
        for (uint v22 = 0; v22 < v20; v22++) {
            v5[v23[v22]] += v14;
            Transfer(msg.sender, v23[v22], v14);
            }
        return true;
    }
}

contract C3 is C2
{
    mapping (address=>bool) public v24;
    
    modifier m25()
    {
        if(!v24[msg.sender])throw;
        _;
    }
    
    event deal(address indexed v26, address indexed v27, uint256 v21, uint256 v28, bytes32 indexed v29);
    
    function f30(uint256 v32, uint256 v33, bytes32 v34, address v35, address v36) payable m25
    {
        if(v5[v35]<v32)return;
        if(v5[v36]+v32<v5[v36])return;
        uint256 v31 = v32*v33;
        v35.transfer(v31);
        v5[v35]-=v32;
        v5[v36]+=v32;
        Transfer(v35,v36,v32);
        deal(v35,v36,v32,v33,v34);
    }
    
}

contract C4 is C3
{
    function C4()
    {
        v1 = "SHARK TECH";
        v2 = "SKT";
        v3 = 18;
        v4 = 100000000000000000000000;
        v5[msg.sender]=v4;
        v24[this]=true;
    }
    
    address public v10 = msg.sender;
    
    uint256 public v28 = 1;
    
    modifier m37()
    {
        if(msg.sender!=tx.origin)throw;
        _;
    }
    
    modifier m38()
    {
        if(msg.sender!=v10)throw;
        _;
    }
    
    function f39(uint256 v40)
    m38
    {
        if(v40>v28)
        {
            v28 = v40;
        }
    }
    
    function f41()
    payable
    m37
    {
        if(msg.value<v28*1 ether)throw;
        this.f30(msg.value/v28,v28,"",v10,msg.sender); 
    }
    
    function f42(uint256 v32) 
    payable
    m37
    {
        if(this.balance<v32*v28)throw;
        this.f30(v32,v28,"buyback",msg.sender,v10);
    }
    
    function f43(address[] v44,uint256 v45)
    public
    payable
    {
        if(msg.value >= v44.length * v45)
        {
            f41();
            f19(v44,v45);
        }
    }
    
    function f46(uint256 v47)
    m38
    payable
    {
        v10.transfer(v47);
    }
    
    function() public payable{}
    
}
