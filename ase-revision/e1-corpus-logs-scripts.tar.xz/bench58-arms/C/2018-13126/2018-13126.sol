pragma solidity ^0.4.18;






contract C1 {
  uint256 public v1;

  function f2(address v3) public view returns (uint256);
  function f4(address v5, uint256 v6) public returns (bool);

  event Transfer(address indexed v7, address indexed v5, uint256 v6);
}





library C2 {
  function f8(uint256 v10, uint256 v11) internal pure returns (uint256) {
    if (v10 == 0) {
      return 0;
    }
    uint256 v9 = v10 * v11;
    assert(v9 / v10 == v11);
    return v9;
  }

  function f12(uint256 v10, uint256 v11) internal pure returns (uint256) {
    
    uint256 v9 = v10 / v11;
    
    return v9;
  }

  function f13(uint256 v10, uint256 v11) internal pure returns (uint256) {
    assert(v11 <= v10);
    return v10 - v11;
  }

  function f14(uint256 v10, uint256 v11) internal pure returns (uint256) {
    uint256 v9 = v10 + v11;
    assert(v9 >= v10);
    return v9;
  }
}





contract C3 is C1 {
  using C2 for uint256;

  mapping(address => uint256) v15;

  




  function f4(address v16, uint256 v17) public returns (bool) {
    require(v16 != address(0));
    require(v17 <= v15[msg.sender]);

    v15[msg.sender] = v15[msg.sender].f13(v17);
    v15[v16] = v15[v16].f14(v17);

    Transfer(msg.sender, v16, v17);

    return true;
  }

  




  function f2(address v18) public view returns (uint256 v19) {
    return v15[v18];
  }
}





contract C4 is C1 {
  function f20(address v21, address v22) public view returns (uint256);
  function f23(address v7, address v5, uint256 v6) public returns (bool);
  function f24(address v22, uint256 v6) public returns (bool);

  event Approval(address indexed v21, address indexed v22, uint256 v6);
}








contract C5 is C4, C3 {
  mapping (address => mapping (address => uint256)) internal v25;

  





  function f23(address v26, address v16, uint256 v17) public returns (bool) {
    require(v16 != address(0));
    require(v17 <= v15[v26]);
    require(v17 <= v25[v26][msg.sender]);

    v15[v26] = v15[v26].f13(v17);
    v15[v16] = v15[v16].f14(v17);
    v25[v26][msg.sender] = v25[v26][msg.sender].f13(v17);

    Transfer(v26, v16, v17);

    return true;
  }

  









  function f24(address v27, uint256 v17) public returns (bool) {
    v25[msg.sender][v27] = v17;

    Approval(msg.sender, v27, v17);

    return true;
  }

  





  function f20(address v18, address v27) public view returns (uint256) {
    return v25[v18][v27];
  }
}




contract C6 is C5 {
  string public constant v28 = "Spend Token";
  string public constant v29 = "SPEND";
  uint8 public constant v30 = 18;

  address public v31;
  address public v32;

  uint public constant v33 = 50000000;

  


  function C6(address v34, address v35) public {
    require(v34 != address(0));
    require(v35 != address(0));

    v31 = v34;
    v32 = v35;
  }

  



  function f36(address v37, uint v17) external {
    require(msg.sender == v31);
    require(v17 > 0);
    require(v1 + v17 <= v33);

    v15[v37] += v17;
    v1 += v17;

    Transfer(0x0, v37, v17);
  }
}




contract C7 {
  enum PreSaleState {
    PreSaleStarted,
    PreSaleFinished
  }

  C6 public v38;
  PreSaleState public v39 = PreSaleState.PreSaleStarted;
  address public v32;
  bool public v40 = false;
  uint256 public v41 = 1 ether / 1000;

  event PreSaleStarted();
  event PreSaleFinished();
  event PreSalePaused();
  event PreSaleResumed();
  event TokenBuy(address indexed v42, uint256 v43);

  


  modifier m44 {
    require(msg.sender == v32);

    _;
  }

  


  function C7() public {
    v32 = msg.sender;
    v38 = new C6(this, v32);
  }

  


  function f45() external m44 {
    require(!v40);
    require(v39 == PreSaleState.PreSaleStarted);

    v40 = true;

    PreSalePaused();
  }

  


  function f46() external m44 {
    require(v40);
    require(v39 == PreSaleState.PreSaleStarted);

    v40 = false;

    PreSaleResumed();
  }

  


  function f47() external m44 {
    require(v39 == PreSaleState.PreSaleStarted);

    v39 = PreSaleState.PreSaleFinished;

    PreSaleFinished();
  }

  


  function f48(address v49, uint256 v50) external m44 {
    v49.transfer(v50);
  }

  


  function f51(address v53, uint256 v17) internal returns (uint) {
    require(v53 != address(0));
    require(v17 > 0);
    require(v39 == PreSaleState.PreSaleStarted);
    require(!v40);

    uint256 v52 = v17 / v41;

    require(v52 > 0);

    v38.f36(v53, v52);

    TokenBuy(v53, v52);
  }

  


  function () external payable {
    f51(msg.sender, msg.value);
  }
}
