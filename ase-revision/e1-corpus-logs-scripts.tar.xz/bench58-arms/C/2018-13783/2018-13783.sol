pragma solidity ^0.4.21;

contract C1 {
    address public v1;

    function C1() public {
        v1 = msg.sender;
    }

    modifier m2 {
        require(msg.sender == v1);
        _;
    }

    function f3(address v4) m2 public {
        v1 = v4;
    }

    function f5() m2 public {
        selfdestruct(v1);
    }

    function () public payable {}
}

interface C2 { function f6(address v7, uint256 v8, address v9, bytes v10) external; }

contract C3 {
    
    string public v11;
    string public v12;
    uint8 public v13 = 18;
    
    uint256 public v14;

    
    mapping (address => uint256) public v15;
    mapping (address => mapping (address => uint256)) public v16;

    
    event Transfer(address indexed v17, address indexed v18, uint256 v19);

    
    event Burn(address indexed v17, uint256 v19);

    




    function C3(
        uint256 v20,
        uint8 v21,
        string v22,
        string v23
    ) public {
        v13 = v21;
        v14 = v20 * 10 ** uint256(v13);  
        v15[msg.sender] = v14;                
        v11 = v22;                                   
        v12 = v23;                               
    }

    


    function f24(address v7, address v26, uint v8) internal {
        
        require(v26 != 0x0);
        
        require(v15[v7] >= v8);
        
        require(v15[v26] + v8 > v15[v26]);
        
        uint v25 = v15[v7] + v15[v26];
        
        v15[v7] -= v8;
        
        v15[v26] += v8;
        emit Transfer(v7, v26, v8);
        
        assert(v15[v7] + v15[v26] == v25);
    }

    







    function f27(address v26, uint256 v8) public {
        f24(msg.sender, v26, v8);
    }

    








    function f28(address v7, address v26, uint256 v8) public returns (bool v29) {
        if (v8 <= v16[v7][msg.sender]) {
          v16[v7][msg.sender] -= v8;
          f24(v7, v26, v8);
          return true;
        }
        else
          return false;
    }

    







    function f30(address v31, uint256 v8) public
        returns (bool v29) {
        v16[msg.sender][v31] = v8;
        return true;
    }

    








    function f32(address v31, uint256 v8, bytes v10)
        public
        returns (bool v29) {
        C2 v33 = C2(v31);
        if (f30(v31, v8)) {
            v33.f6(msg.sender, v8, this, v10);
            return true;
        }
    }

    






    function f34(uint256 v8) public returns (bool v29) {
        require(v15[msg.sender] >= v8);   
        v15[msg.sender] -= v8;            
        v14 -= v8;                      
        emit Burn(msg.sender, v8);
        return true;
    }

    







    function f35(address v7, uint256 v8) public returns (bool v29) {
        require(v15[v7] >= v8);                
        require(v8 <= v16[v7][msg.sender]);    
        v15[v7] -= v8;                         
        v16[v7][msg.sender] -= v8;             
        v14 -= v8;                              
        emit Burn(v7, v8);
        return true;
    }
}





contract C4 is C1, C3 {

    uint256 public v36;
    uint256 public v37;
    uint256 public v38;

    mapping (address => bool) public v39;

    
    event FrozenFunds(address v40, bool v41);

    
    function C4 (
        uint256 v20,
        uint8 v21,
        string v22,
        string v23
    ) C3(v20, v21, v22, v23) public {

        v36 = 10 finney;
        v37 = 10 finney;
        v38 = 20 finney;
    }

    
    function f24(address v7, address v26, uint v8) internal {
        require (v26 != 0x0);                               
        require (v15[v7] >= v8);               
        require (v15[v26] + v8 >= v15[v26]); 
        require(!v39[v7]);                     
        require(!v39[v26]);                       
        v15[v7] -= v8;                         
        v15[v26] += v8;                           
        emit Transfer(v7, v26, v8);
    }

    
    
    
    function f42(address v40, uint256 v43) m2 public {
        v15[v40] += v43;
        v14 += v43;
        emit Transfer(0, this, v43);
        emit Transfer(this, v40, v43);
    }

    
    
    
    function f44(address v40, bool v45) m2 public {
        v39[v40] = v45;
        emit FrozenFunds(v40, v45);
    }

    
    
    
    
    function f46(uint256 v47, uint256 v48, uint256 v49) m2 public {
        require(v49 > v48);
        v36 = v47;
        v37 = v48;
        v38 = v49;
    }

    
    function f50() payable public {
        require(msg.value == v36);
        uint v51 = msg.value / v36;               
        f24(this, msg.sender, v51);              

        v36 += v37;
    }

    
    
    function f52(uint256 v51) public {
        require(v51 == 1);
        require(address(this).balance >= v51 * v36);      
        f24(msg.sender, this, v51);              
        msg.sender.transfer(v51 * v36 - v38);          

        v36 -= v37;
    }
}
