pragma solidity ^0.4.4;

contract C1 {
  
    function f1() constant returns (uint256 v2) {}

    function f3(address v4) constant returns (uint256 v5) {}
   
    function f6(address v7, uint256 v8) returns (bool v9) {}
   
    function f10(address v11, address v7, uint256 v8) returns (bool v9) {}
   
    function f12(address v13, uint256 v8) returns (bool v9) {}
  
    function f14(address v4, address v13) constant returns (uint256 v15) {}
 
    event Transfer(address indexed v11, address indexed v7, uint256 v8);

    event Approval(address indexed v4, address indexed v13, uint256 v8);
}

contract C2 is C1 {

    function f6(address v7, uint256 v8) returns (bool v9) {        
        if (v16[msg.sender] >= v8 && v8 > 0) {
            v16[msg.sender] -= v8;
            v16[v7] += v8;
            Transfer(msg.sender, v7, v8);
            return true;
        } else { return false; }
    }

    function f10(address v11, address v7, uint256 v8) returns (bool v9) {
        if (v16[v11] >= v8 && v17[v11][msg.sender] >= v8 && v8 > 0) {
            v16[v7] += v8;
            v16[v11] -= v8;
            v17[v11][msg.sender] -= v8;
            Transfer(v11, v7, v8);
            return true;
        } else { return false; }
    }

    function f3(address v4) constant returns (uint256 v5) {
        return v16[v4];
    }

    function f12(address v13, uint256 v8) returns (bool v9) {
        v17[msg.sender][v13] = v8;
        Approval(msg.sender, v13, v8);
        return true;
    }

    function f14(address v4, address v13) constant returns (uint256 v15) {
      return v17[v4][v13];
    }

    mapping (address => uint256) v16;
    mapping (address => mapping (address => uint256)) v17;
    uint256 public f1;
}

contract C3 is C2 {

    function () {
        throw;
    }

    string public v18;                   
    uint8 public v19;               
    string public v20;                 
    string public v21 = 'H0.1';       

    function C3(
        uint256 v22,
        string v23,
        uint8 v24,
        string v25
        ) {
        v16[msg.sender] = v22;               
        f1 = v22;                        
        v18 = v23;                                   
        v19 = v24;                            
        v20 = v25;                               
    }

    function f26(address v13, uint256 v8, bytes v27) returns (bool v9) {
        v17[msg.sender][v13] = v8;
        Approval(msg.sender, v13, v8);        
        if(!v13.call(bytes4(bytes32(sha3("receiveApproval(address,uint256,address,bytes)"))), msg.sender, v8, this, v27)) { throw; }
        return true;
    }
}
