
pragma solidity ^0.4.2;
contract C1 {
    address public v1;

    function C1() {
        v1 = msg.sender;
    }

    modifier m2 {
        if (msg.sender != v1) throw;
        _;
    }

    function f3(address v4) m2 {
        v1 = v4;
    }
}

contract C2 { function f5(address v6, uint256 v7, address v8, bytes v9); }

contract C3 {
    
    string public v10 = "ENTER 1.0";
    string public v11;
    string public v12;
    uint8 public v13;
    uint256 public v14;

    
    mapping (address => uint256) public v15;
    mapping (address => mapping (address => uint256)) public v16;

    
    event Transfer(address indexed v17, address indexed v18, uint256 v19);

    
    function C3(
        uint256 v20,
        string v21,
        uint8 v22,
        string v23
        ) {
        v15[msg.sender] = v20;              
        v14 = v20;                        
        v11 = v21;                                   
        v12 = v23;                               
        v13 = v22;                            
    }

    
    function f24(address v25, uint256 v7) {
        if (v15[msg.sender] < v7) throw;           
        if (v15[v25] + v7 < v15[v25]) throw; 
        v15[msg.sender] -= v7;                     
        v15[v25] += v7;                            
        Transfer(msg.sender, v25, v7);                   
    }

    
    function f26(address v27, uint256 v7)
        returns (bool v28) {
        v16[msg.sender][v27] = v7;
        return true;
    }

    
    function f29(address v27, uint256 v7, bytes v9)
        returns (bool v28) {
        C2 v30 = C2(v27);
        if (f26(v27, v7)) {
            v30.f5(msg.sender, v7, this, v9);
            return true;
        }
    }

    
    function f31(address v6, address v25, uint256 v7) returns (bool v28) {
        if (v15[v6] < v7) throw;                 
        if (v15[v25] + v7 < v15[v25]) throw;  
        if (v7 > v16[v6][msg.sender]) throw;   
        v15[v6] -= v7;                          
        v15[v25] += v7;                            
        v16[v6][msg.sender] -= v7;
        Transfer(v6, v25, v7);
        return true;
    }

    
    function () {
        throw;     
    }
}

contract C4 is C1, C3 {

    uint256 public v32;
    uint256 public v33;

    mapping(address=>bool) public v34;


    
    event FrozenFunds(address v35, bool v36);

    
    uint256 public constant v20 = 21000000 * 10**8;
    uint8 public constant v22 = 8;
    string public v21 = "ENTER";
    string public v23 = "ENTR";
    function C4() C3 (v20, v21, v22, v23) {}
     
    function f24(address v25, uint256 v7) {
        if (v15[msg.sender] < v7) throw;           
        if (v15[v25] + v7 < v15[v25]) throw; 
        if (v34[msg.sender]) throw;                
        v15[msg.sender] -= v7;                     
        v15[v25] += v7;                            
        Transfer(msg.sender, v25, v7);                   
    }


    
    function f31(address v6, address v25, uint256 v7) returns (bool v28) {
        if (v34[v6]) throw;                        
        if (v15[v6] < v7) throw;                 
        if (v15[v25] + v7 < v15[v25]) throw;  
        if (v7 > v16[v6][msg.sender]) throw;   
        v15[v6] -= v7;                          
        v15[v25] += v7;                            
        v16[v6][msg.sender] -= v7;
        Transfer(v6, v25, v7);
        return true;
    }

    function f37(address v35, uint256 v38) m2 {
        v15[v35] += v38;
        v14 += v38;
        Transfer(0, this, v38);
        Transfer(this, v35, v38);
    }

    function f39(address v35, bool v40) m2 {
        v34[v35] = v40;
        FrozenFunds(v35, v40);
    }

    function f41(uint256 v42, uint256 v43) m2 {
        v32 = v42;
        v33 = v43;
    }

    function f44() payable {
        uint v45 = msg.value / v33;                
        if (v15[this] < v45) throw;               
        v15[msg.sender] += v45;                   
        v15[this] -= v45;                         
        Transfer(this, msg.sender, v45);                
    }

    function f46(uint256 v45) {
        if (v15[msg.sender] < v45 ) throw;        
        v15[this] += v45;                         
        v15[msg.sender] -= v45;                   
        if (!msg.sender.send(v45 * v32)) {        
            throw;                                         
        } else {
            Transfer(msg.sender, this, v45);            
        }
    }
}