pragma solidity ^0.4.16;





library C1 {
  function f1(uint256 v3, uint256 v4) internal constant returns (uint256) {
    uint256 v2 = v3 * v4;
    assert(v3 == 0 || v2 / v3 == v4);
    return v2;
  }

  function f5(uint256 v3, uint256 v4) internal constant returns (uint256) {
    
    uint256 v2 = v3 / v4;
    
    return v2;
  }

  function f6(uint256 v3, uint256 v4) internal constant returns (uint256) {
    assert(v4 <= v3);
    return v3 - v4;
  }

  function f7(uint256 v3, uint256 v4) internal constant returns (uint256) {
    uint256 v2 = v3 + v4;
    assert(v2 >= v3);
    return v2;
  }
}






contract C2 {
  uint256 public v8;
  function f9(address v10) public constant returns (uint256);
  function f11(address v12, uint256 v13) public returns (bool);
  event Transfer(address indexed v14, address indexed v12, uint256 v13);
}





contract C3 is C2 {
  using C1 for uint256;

  mapping(address => uint256) v15;

  




  function f11(address v16, uint256 v17) public returns (bool) {
    require(v16 != address(0));
    require(v17 > 0 && v17 <= v15[msg.sender]);

    
    v15[msg.sender] = v15[msg.sender].f6(v17);
    v15[v16] = v15[v16].f7(v17);
    Transfer(msg.sender, v16, v17);
    return true;
  }

  




  function f9(address v18) public constant returns (uint256 v19) {
    return v15[v18];
  }
}





contract C4 is C2 {
  function f20(address v21, address v22) public constant returns (uint256);
  function f23(address v14, address v12, uint256 v13) public returns (bool);
  function f24(address v22, uint256 v13) public returns (bool);
  event Approval(address indexed v21, address indexed v22, uint256 v13);
}









contract C5 is C4, C3 {

  mapping (address => mapping (address => uint256)) internal v25;


  





  function f23(address v26, address v16, uint256 v17) public returns (bool) {
    require(v16 != address(0));
    require(v17 > 0 && v17 <= v15[v26]);
    require(v17 <= v25[v26][msg.sender]);

    v15[v26] = v15[v26].f6(v17);
    v15[v16] = v15[v16].f7(v17);
    v25[v26][msg.sender] = v25[v26][msg.sender].f6(v17);
    Transfer(v26, v16, v17);
    return true;
  }

  









  function f24(address v27, uint256 v17) public returns (bool) {
    v25[msg.sender][v27] = v17;
    Approval(msg.sender, v27, v17);
    return true;
  }

  





  function f20(address v18, address v27) public constant returns (uint256 v28) {
    return v25[v18][v27];
  }
}






contract C6 {
  address public v21;


  event OwnershipTransferred(address indexed v29, address indexed v30);


  



  function C6() {
    v21 = msg.sender;
  }


  


  modifier m31() {
    require(msg.sender == v21);
    _;
  }


  



  function f32(address v30) m31 public {
    require(v30 != address(0));
    OwnershipTransferred(v21, v30);
    v21 = v30;
  }

}





contract C7 is C6 {
  event Pause();
  event Unpause();

  bool public v33 = false;


  


  modifier m34() {
    require(!v33);
    _;
  }

  


  modifier m35() {
    require(v33);
    _;
  }

  


  function f36() m31 m34 public {
    v33 = true;
    Pause();
  }

  


  function f37() m31 m35 public {
    v33 = false;
    Unpause();
  }
}







contract C8 is C5, C7 {

  function f11(address v16, uint256 v17) public m34 returns (bool) {
    return super.f11(v16, v17);
  }

  function f23(address v26, address v16, uint256 v17) public m34 returns (bool) {
    return super.f23(v26, v16, v17);
  }

  function f24(address v27, uint256 v17) public m34 returns (bool) {
    return super.f24(v27, v17);
  }
  
  function f38(address[] v42, uint256 v17) public m34 returns (bool) {
    uint v39 = v42.length;
    uint256 v40 = uint256(v39) * v17;
    require(v39 > 0 && v39 <= 20);
    require(v17 > 0 && v15[msg.sender] >= v40);

    v15[msg.sender] = v15[msg.sender].f6(v40);
    for (uint v41 = 0; v41 < v39; v41++) {
        v15[v42[v41]] = v15[v42[v41]].f7(v17);
        Transfer(msg.sender, v42[v41], v17);
    }
    return true;
  }
}






contract C9 is C8 {
    





    string public v43 = "BeautyChain";
    string public v44 = "BEC";
    string public v45 = '1.0.0';
    uint8 public v46 = 18;

    


    function C9() {
      v8 = 7000000000 * (10**(uint256(v46)));
      v15[msg.sender] = v8;    
    }

    function () {
        
        revert();
    }
}
