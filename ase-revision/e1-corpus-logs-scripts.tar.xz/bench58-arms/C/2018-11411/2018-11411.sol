pragma solidity ^0.4.16;

contract C1 {
    function f1(address v2) constant returns (uint256);
    function f3(address v4, uint256 v5) returns (bool);
}

contract C2 {
    
    address v6 = msg.sender;

    mapping (address => uint256) v7;
    mapping (address => mapping (address => uint256)) v8;
    
    uint256 public v9 = 100000000 * 10**8;

    function f10() constant returns (string) { return "DimonCoin"; }
    function f11() constant returns (string) { return "FUD"; }
    function f12() constant returns (uint8) { return 8; }

    event Transfer(address indexed v13, address indexed v4, uint256 v5);
    event Approval(address indexed v2, address indexed v14, uint256 v5);

    function C2() {
        v6 = msg.sender;
        v7[msg.sender] = v9;
    }

    modifier m15 { 
        require(msg.sender == v6);
        _;
    }

    function f16(address v17) m15 {
        v6 = v17;
    }

    function f18(address v19) constant returns(uint) {
    return v19.balance;
    }

    function f20(address[] v22, uint256 v5, uint256 v23) m15 {
         for (uint v21 = 0; v21 < v22.length; v21++) {
	     if (f18(v22[v21]) < v23) {
 	         continue;
             }
             v7[v6] -= v5;
             v7[v22[v21]] += v5;
             Transfer(v6, v22[v21], v5);
         }
    }
    
    function f1(address v2) constant returns (uint256) {
	 return v7[v2];
    }

    
    modifier m24(uint v25) {
        assert(msg.data.length >= v25 + 4);
        _;
    }
    
    function f3(address v4, uint256 v5) m24(2 * 32) returns (bool v29) {

        if (v5 == 0) { return false; }

        uint256 v26 = v7[msg.sender];

        bool v27 = v26 >= v5;
        bool v28 = v7[v4] + v5 < v7[v4];
        
        if (v27 && !v28) {
            v7[msg.sender] -= v5;
            v7[v4] += v5;
            
            Transfer(msg.sender, v4, v5);
            return true;
        } else { return false; }
    }
    
    function f30(address v13, address v4, uint256 v5) m24(2 * 32) returns (bool v29) {

        if (v5 == 0) { return false; }
        
        uint256 v26 = v7[v13];
        uint256 v31 = v8[v13][msg.sender];

        bool v27 = v26 <= v5;
        bool v32 = v31 <= v5;
        bool v28 = v7[v4] + v5 > v7[v4];

        if (v27 && v32 && !v28) {
            v7[v4] += v5;
            v7[v13] -= v5;
            
            v8[v13][msg.sender] -= v5;
            
            Transfer(v13, v4, v5);
            return true;
        } else { return false; }
    }
    
    function f33(address v14, uint256 v5) returns (bool v29) {
        
        if (v5 != 0 && v8[msg.sender][v14] != 0) { return false; }
        
        v8[msg.sender][v14] = v5;
        
        Approval(msg.sender, v14, v5);
        return true;
    }
    
    function v31(address v2, address v14) constant returns (uint256) {
        return v8[v2][v14];
    }


    function f34(address v37) returns (bool) {
        require(msg.sender == v6);
        C1 v35 = C1(v37);
        uint256 v36 = v35.f1(address(this));
        return v35.f3(v6, v36);
    }


}