

pragma solidity ^0.4.15;

contract C1 {
    
    
    uint256 public v1;

    
    
    function f2(address v3) public constant returns (uint256 v4);

    
    
    
    
    function f5(address v6, uint256 v7) public returns (bool v8);

    
    
    
    
    
    function f9(address v10, address v6, uint256 v7) public returns (bool v8);

    
    
    
    
    function f11(address v12, uint256 v7) public returns (bool v8);

    
    
    
    function f13(address v3, address v12) public constant returns (uint256 v14);

    event Transfer(address indexed v10, address indexed v6, uint256 v7);
    event Approval(address indexed v3, address indexed v12, uint256 v7);
}

contract C2 {

    
    
    modifier m15() {
        require(msg.sender == v16);
        _;
    }

    address public v16;

    
    function C2() public {
        v16 = msg.sender;
    }

    address v17=0x0;

    event OwnerUpdate(address v18, address v19);

    
    function f20(address v19) public m15 {
        require(v19 != v16);
        v17 = v19;
    }

    
    function f21() public{
        require(msg.sender == v17);
        OwnerUpdate(v16, v17);
        v16 = v17;
        v17 = 0x0;
    }
}

contract C3 is C2{

    function C3() public {
       f31(msg.sender);
    }

    
    bool public v22 = false;

    
    bool v23=true;
    mapping(address => bool) v24;
    mapping(address => bool) v25;

    function f26(bool v27) public m15{
        v22=v27;
    }

    function f28(bool v27) public m15 returns (bool v8){
        v23=v27;
        return true;
    }

    function f29(address v30) public m15 returns (bool v8){
        require(v30!=msg.sender);
        v24[v30]=true;
        return true;
    }

    function f31(address v30) public m15 returns (bool v8){
        v25[v30]=true;
        return true;
    }

    function f32(address v30) public m15 returns (bool v8){
        v24[v30]=false;
        return true;
    }

    modifier m33(address v30) {
        if (!v25[v30]) {
            assert(v22);
            if(v23){
                assert(!v24[v30]);
            }
        }
        
        _;
    }

}

contract C4 is C1,C3 {

    function f5(address v6, uint256 v7) public m33(msg.sender) returns (bool v8) {
        
        
        
        if (v34[msg.sender] >= v7 && v34[v6] + v7 > v34[v6]) {
            v34[msg.sender] -= v7;
            v34[v6] += v7;
            Transfer(msg.sender, v6, v7);
            return true;
        } else { return false; }
    }

    function f9(address v10, address v6, uint256 v7) public m33(v10) returns (bool v8) {
        
        if (v34[v10] >= v7 && v35[v10][msg.sender] >= v7 && v34[v6] + v7 > v34[v6]) {
            v34[v6] += v7;
            v34[v10] -= v7;
            v35[v10][msg.sender] -= v7;
            Transfer(v10, v6, v7);
            return true;
        } else { return false; }
    }

    function f2(address v3) public constant returns (uint256 v4) {
        return v34[v3];
    }

    function f11(address v12, uint256 v7) public returns (bool v8) {
        v35[msg.sender][v12] = v7;
        Approval(msg.sender, v12, v7);
        return true;
    }

    function f13(address v3, address v12) public constant returns (uint256 v14) {
      return v35[v3][v12];
    }

    mapping (address => uint256) v34;
    mapping (address => mapping (address => uint256)) v35;
}

contract C5 is C4 {

    function () public {
        revert();
    }

    string public v36 = "SmartMesh Token";                   
    uint8 public v37 = 18;                
    string public v38 = "SMT";                 
    string public v39 = 'v0.1';       
    uint256 public v40;

    
    
    mapping(address => uint256) v41;

    function C5() public {
        v40 = now + 1 days;
    }

    










    function f42(address v10, address v6, uint256 v7, uint256 v45,
        uint8 v46,bytes32 v47, bytes32 v48) public m33(v10) returns (bool){

        if(v34[v10] < v45 + v7) revert();

        uint256 v43 = v41[v10];
        bytes32 v44 = keccak256(v10,v6,v7,v45,v43);
        if(v10 != ecrecover(v44,v46,v47,v48)) revert();

        if(v34[v6] + v7 < v34[v6]
            || v34[msg.sender] + v45 < v34[msg.sender]) revert();
        v34[v6] += v7;
        Transfer(v10, v6, v7);

        v34[msg.sender] += v45;
        Transfer(v10, msg.sender, v45);

        v34[v10] -= v7 + v45;
        v41[v10] = v43 + 1;
        return true;
    }

    









    function f49(address v10, address v12, uint256 v7,
        uint8 v46,bytes32 v47, bytes32 v48) public returns (bool v8) {

        uint256 v43 = v41[v10];
        bytes32 v50 = keccak256(v10,v12,v7,v43);
        if(v10 != ecrecover(v50,v46,v47,v48)) revert();
        v35[v10][v12] = v7;
        Approval(v10, v12, v7);
        v41[v10] = v43 + 1;
        return true;
    }


    



    function f51(address v30) public constant returns (uint256){
        return v41[v30];
    }

    
    function f52(address v12, uint256 v7, bytes v53) public returns (bool v8) {
        v35[msg.sender][v12] = v7;
        Approval(msg.sender, v12, v7);

        
        
        
        if(!v12.call(bytes4(bytes32(keccak256("receiveApproval(address,uint256,address,bytes)"))), msg.sender, v7, this, v53)) { revert(); }
        return true;
    }

    
    function f54(address v12, uint256 v7, bytes v53) public returns (bool v8) {
        v35[msg.sender][v12] = v7;
        Approval(msg.sender, v12, v7);

        
        if(!v12.call(v53)) { revert(); }
        return true;
    }

    
    
    
    function f55(address[] v59, uint256[] v60) public m15 {

        if(v40 < now) revert();
        if(v59.length != v60.length) revert();

        for(uint256 v58 = 0; v58 < v59.length ; v58++){
            address v56 = v59[v58];
            uint256 v57 = v60[v58];
            if(v1 + v57 <= v1 || v34[v56] + v57 <= v34[v56]) revert();
            v1 += v57;
            v34[v56] += v57;
        }
    }
}