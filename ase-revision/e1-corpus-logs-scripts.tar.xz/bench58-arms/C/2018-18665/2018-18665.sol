pragma solidity ^0.4.11;

contract C1 {
    uint256 public v1;
    function f2(address v3) constant returns (uint256 v4);
    function f5(address v6, uint256 v7) returns (bool v8);
    function f9(address v10, address v6, uint256 v7) returns (bool v8);
    function f11(address v12, uint256 v7) returns (bool v8);
    function f13(address v3, address v12) constant returns (uint256 v14);
    event Transfer(address indexed v10, address indexed v6, uint256 v7);
    event Approval(address indexed v3, address indexed v12, uint256 v7);
}

contract C2 is C1 {
	bool public v15 = false;
    function f5(address v6, uint256 v7) returns (bool v8) {
        if (v15 != true && v16[msg.sender] >= v7 && v7 > 0) {
            v16[msg.sender] -= v7;
            v16[v6] += v7;
            Transfer(msg.sender, v6, v7);
            return true;
        } else { return false; }
    }
    function f9(address v10, address v6, uint256 v7) returns (bool v8) {
        if (v15 != true && v16[v10] >= v7 && v17[v10][msg.sender] >= v7 && v7 > 0) {
            v16[v6] += v7;
            v16[v10] -= v7;
            v17[v10][msg.sender] -= v7;
            Transfer(v10, v6, v7);
            return true;
        } else { return false; }
    }
    function f2(address v3) constant returns (uint256 v4) {
        return v16[v3];
    }
    function f11(address v12, uint256 v7) returns (bool v8) {
        v17[msg.sender][v12] = v7;
        Approval(msg.sender, v12, v7);
        return true;
    }
    function f13(address v3, address v12) constant returns (uint256 v14) {
      return v17[v3][v12];
    }
    mapping (address => uint256) v16;
    mapping (address => mapping (address => uint256)) v17;
}

contract C3 is C2 {

    function () {return;}

    string public v18 = "Nexxus";
    uint8 public v19 = 8;
    string public v20 = "NXX";
    address public v21;

    function C3() {
        v1 = 31800000000000000;
        v21 = msg.sender;
        v16[v21] = v1;
    }
    function f22(address v12, uint256 v7, bytes v23) returns (bool v8) {
        v17[msg.sender][v12] = v7;
        Approval(msg.sender, v12, v7);
        if(!v12.call(bytes4(bytes32(sha3("receiveApproval(address,uint256,address,bytes)"))), msg.sender, v7, this, v23)) { return; }
        return true;
    }
	function f24(uint256 v25) {
        if (msg.sender == v21) {
    		v1 += v25;
            v16[v21] += v25;
    		Transfer(0, v21, v25);
        }
	}
	function f26(bool v27) { 
        if (msg.sender == v21)
			v15 = v27;
    }
}
