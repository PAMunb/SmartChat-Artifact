# Bench58 three-arm corpus (contamination experiment E1)

Three variants of each of the 58 Bench58 contracts, used to test whether the reported
performance of \sc depends on recognizing the specific benchmark contracts.

| arm | transformation | removes |
|---|---|---|
| `A` | original (comments stripped) | — |
| `B` | synonym renaming of identifiers and contract names | exact-string memorization; semantics preserved |
| `C` | opaque renaming (`f1`, `v1`, `C1`) | memorization **and** semantics |

Each `<arm>/<contract>/` holds `<contract>.sol`, `.abi` and `.bin`. `manifest.json` records the
target contract of each arm, e.g. `2018-10299` is `BecToken` in arm A, `AuroraAsset` in arm B
and `C9` in arm C.

**Arm A is the published benchmark.** Compiled with solc 0.4.26, no optimizer, targeting
byzantium, every arm-A binary is byte-identical to the one shipped with the SmartChat artifact
apart from the trailing metadata hash, which encodes a hash of the source and therefore changes
when comments are stripped; it sits after the code and is never executed. All three arms are
compiled with those same settings, so the arms differ only in their identifiers.

Every transformed contract was checked for semantic equivalence against its original before
being written: same multiset of basic blocks, same opcode histogram and same immediates, with
function selectors and jump targets masked because renaming necessarily changes them.

Regenerate with `../renamer/buildarms.js`; see that directory for the renaming rules, what is
deliberately left unrenamed, and the equivalence criterion.
