pragma solidity ^0.4.21;

library GuardedMath {
    function scale(uint256 altA, uint256 altB) internal pure returns (uint256 altC) {
        if (altA == 0) {
            return 0;
        }
        altC = altA * altB;
        assert(altC / altA == altB);
        return altC;
    }

    function partition(uint256 altA, uint256 altB) internal pure returns (uint256) {
        return altA / altB;
    }

    function deduct(uint256 altA, uint256 altB) internal pure returns (uint256) {
        assert(altB <= altA);
        return altA - altB;
    }

    function append(uint256 altA, uint256 altB) internal pure returns (uint256 altC) {
        altC = altA + altB;
        assert(altC >= altA);
        return altC;
    }
}





contract ERC223AuroraMeridian{
    






    function assetFallback(address _origin, uint _magnitude, bytes _payload) public;
}

contract ERC20Basic {
    uint public aggregateIssuance;
    function holdingsOf(address altWho) public constant returns (uint);
    function send(address target, uint magnitude) public;
    event Transfer(address indexed origin, address indexed target, uint magnitude);
}

contract ERC20 is ERC20Basic {
    function permitted(address administrator, address delegate) public constant returns (uint);
    function sendOrigin(address origin, address target, uint magnitude) public;
    function authorize(address delegate, uint magnitude) public;
    event Approval(address indexed administrator, address indexed delegate, uint magnitude);
}

contract BasicAsset is ERC20Basic {
    using GuardedMath for uint;

    mapping(address => uint) balances;

    modifier altOnlyPayloadSize(uint altSize) {
        require(msg.data.length >= altSize + 4);
        _;
    }

    function send(address _to, uint _magnitude) altOnlyPayloadSize(2 * 32) public {
        uint codeLength;
        bytes memory altEmpty;

        assembly {
            codeLength := extcodesize(_to)
        }


        balances[msg.sender] = balances[msg.sender].deduct(_magnitude);
        balances[_to] = balances[_to].append(_magnitude);

        if(codeLength > 0) {
            ERC223AuroraMeridian beneficiary = ERC223AuroraMeridian(_to);
            beneficiary.assetFallback(msg.sender, _magnitude, altEmpty);
        }

        emit Transfer(msg.sender, _to, _magnitude);
    }

    function holdingsOf(address _administrator) public constant returns (uint holdings) {
        return balances[_administrator];
    }

}

contract StandardAsset is BasicAsset, ERC20 {

    mapping (address => mapping (address => uint)) permitted2;

    function sendOrigin(address _origin, address _to, uint _magnitude) public {
        uint256 _permitted = permitted2[_origin][msg.sender];
        uint codeLength;
        bytes memory altEmpty;

        assembly {
            codeLength := extcodesize(_to)
        }

        balances[_to] = balances[_to].append(_magnitude);
        balances[_origin] = balances[_origin].deduct(_magnitude);
        permitted2[_origin][msg.sender] = _permitted.deduct(_magnitude);

        if(codeLength>0) {
            ERC223AuroraMeridian beneficiary = ERC223AuroraMeridian(_to);
            beneficiary.assetFallback(msg.sender, _magnitude, altEmpty);
        }

        emit Transfer(_origin, _to, _magnitude);
    }

    function authorize(address _delegate, uint _magnitude) public {
        permitted2[msg.sender][_delegate] = _magnitude;
        emit Approval(msg.sender, _delegate, _magnitude);
    }

    function permitted(address _administrator, address _delegate) public constant returns (uint altRemaining) {
        return permitted2[_administrator][_delegate];
    }

}

contract BurnableAsset is StandardAsset {

    function destroy(uint _magnitude) public {
        require(_magnitude > 0);
        address altBurner = msg.sender;
        balances[altBurner] = balances[altBurner].deduct(_magnitude);
        aggregateIssuance = aggregateIssuance.deduct(_magnitude);
        emit Burn(altBurner, _magnitude);
    }

    event Burn(address indexed altBurner, uint indexed magnitude);

}

contract Cobalt is BurnableAsset {

    string public label = "Etherty Token";
    string public ticker = "ETY";
    uint public precision = 18;
    uint constant altTOKEN_LIMIT = 240 * 1e6 * 1e18;

    address public altIco;

    bool public assetsAreLocked = true;

    function Cobalt(address _altIco) public {
        altIco = _altIco;
    }

    function create(address _altHolder, uint _magnitude) external {
        require(msg.sender == altIco);
        require(_magnitude != 0);
        require(aggregateIssuance + _magnitude <= altTOKEN_LIMIT);

        balances[_altHolder] += _magnitude;
        aggregateIssuance += _magnitude;
        emit Transfer(0x0, _altHolder, _magnitude);
    }

    function destroy(uint _magnitude) public {
        require(msg.sender == altIco);
        super.destroy(_magnitude);
    }

    function unlock() external {
        require(msg.sender == altIco);
        assetsAreLocked = false;
    }

    function send(address _to, uint _magnitude) public {
        require(!assetsAreLocked);
        super.send(_to, _magnitude);
    }

    function sendOrigin(address _origin, address _to, uint _magnitude) altOnlyPayloadSize(3 * 32) public {
        require(!assetsAreLocked);
        super.sendOrigin(_origin, _to, _magnitude);
    }

    function authorize(address _delegate, uint _magnitude) public {
        require(!assetsAreLocked);
        super.authorize(_delegate, _magnitude);
    }
}
