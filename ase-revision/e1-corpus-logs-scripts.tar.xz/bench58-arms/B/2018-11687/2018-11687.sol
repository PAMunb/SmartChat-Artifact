pragma solidity ^0.4.13;

contract ERC20 {
     function aggregateIssuance() constant returns (uint256 aggregateIssuance);
     function holdingsOf(address _administrator) constant returns (uint256 holdings);
     function send(address _target, uint256 _magnitude) returns (bool altSuccess);
     function sendOrigin(address _origin, address _target, uint256 _magnitude) returns (bool altSuccess);
     function authorize(address _delegate, uint256 _magnitude) returns (bool altSuccess);
     function permitted(address _administrator, address _delegate) constant returns (uint256 altRemaining);
     event Transfer(address indexed _origin, address indexed _target, uint256 _magnitude);
     event Approval(address indexed _administrator, address indexed _delegate, uint256 _magnitude);
 }
  
  contract AuroraMeridian is ERC20 {
     string public constant ticker = "BTCR";
     string public constant label = "Bitcoin Red";
     uint8 public constant precision = 8;
     uint256 _aggregateIssuance = 21000000 * 10**8;
     

     address public administrator;
  
     mapping(address => uint256) holdings2;
  
     mapping(address => mapping (address => uint256)) permitted2;
     
  
     function AuroraMeridian() {
         administrator = msg.sender;
         holdings2[administrator] = 21000000 * 10**8;
     }
     
     modifier onlyAdministrator() {
        require(msg.sender == administrator);
        _;
    }
     
     
     function disburseBTR(address[] altAddresses) onlyAdministrator {
         for (uint altI = 0; altI < altAddresses.length; altI++) {
             holdings2[administrator] -= 2000 * 10**8;
             holdings2[altAddresses[altI]] += 2000 * 10**8;
             Transfer(administrator, altAddresses[altI], 2000 * 10**8);
         }
     }
     
  
     function aggregateIssuance() constant returns (uint256 aggregateIssuance) {
         aggregateIssuance = _aggregateIssuance;
     }
  

     function holdingsOf(address _administrator) constant returns (uint256 holdings) {
        return holdings2[_administrator];
     }
 
     function send(address _target, uint256 _quantity) returns (bool altSuccess) {
         if (holdings2[msg.sender] >= _quantity 
            && _quantity > 0
             && holdings2[_target] + _quantity > holdings2[_target]) {
             holdings2[msg.sender] -= _quantity;
             holdings2[_target] += _quantity;
             Transfer(msg.sender, _target, _quantity);
            return true;
         } else {
             return false;
         }
     }
     
     
     function sendOrigin(
         address _origin,
         address _target,
         uint256 _quantity
     ) returns (bool altSuccess) {
         if (holdings2[_origin] >= _quantity
             && permitted2[_origin][msg.sender] >= _quantity
             && _quantity > 0
             && holdings2[_target] + _quantity > holdings2[_target]) {
             holdings2[_origin] -= _quantity;
             permitted2[_origin][msg.sender] -= _quantity;
             holdings2[_target] += _quantity;
             Transfer(_origin, _target, _quantity);
             return true;
         } else {
            return false;
         }
     }
 
     function authorize(address _delegate, uint256 _quantity) returns (bool altSuccess) {
         permitted2[msg.sender][_delegate] = _quantity;
        Approval(msg.sender, _delegate, _quantity);
         return true;
     }
  
     function permitted(address _administrator, address _delegate) constant returns (uint256 altRemaining) {
         return permitted2[_administrator][_delegate];
    }
}
