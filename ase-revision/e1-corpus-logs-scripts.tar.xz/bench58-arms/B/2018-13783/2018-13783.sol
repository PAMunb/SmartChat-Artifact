pragma solidity ^0.4.21;

contract owned {
    address public administrator;

    function owned() public {
        administrator = msg.sender;
    }

    modifier onlyAdministrator {
        require(msg.sender == administrator);
        _;
    }

    function sendAdministration(address freshAdministrator) onlyAdministrator public {
        administrator = freshAdministrator;
    }

    function terminate() onlyAdministrator public {
        selfdestruct(administrator);
    }

    function () public payable {}
}

interface assetBeneficiary { function receiveAuthorization(address _origin, uint256 _magnitude, address _asset, bytes _extraPayload) external; }

contract AssetERC20 {
    
    string public label;
    string public ticker;
    uint8 public precision = 18;
    
    uint256 public aggregateIssuance;

    
    mapping (address => uint256) public holdingsOf;
    mapping (address => mapping (address => uint256)) public permitted;

    
    event Transfer(address indexed origin, address indexed target, uint256 magnitude);

    
    event Burn(address indexed origin, uint256 magnitude);

    




    function AssetERC20(
        uint256 initialIssuance,
        uint8 initialPrecision,
        string assetLabel,
        string assetTicker
    ) public {
        precision = initialPrecision;
        aggregateIssuance = initialIssuance * 10 ** uint256(precision);  
        holdingsOf[msg.sender] = aggregateIssuance;                
        label = assetLabel;                                   
        ticker = assetTicker;                               
    }

    


    function _send(address _origin, address _target, uint _magnitude) internal {
        
        require(_target != 0x0);
        
        require(holdingsOf[_origin] >= _magnitude);
        
        require(holdingsOf[_target] + _magnitude > holdingsOf[_target]);
        
        uint previousHoldings = holdingsOf[_origin] + holdingsOf[_target];
        
        holdingsOf[_origin] -= _magnitude;
        
        holdingsOf[_target] += _magnitude;
        emit Transfer(_origin, _target, _magnitude);
        
        assert(holdingsOf[_origin] + holdingsOf[_target] == previousHoldings);
    }

    







    function send(address _target, uint256 _magnitude) public {
        _send(msg.sender, _target, _magnitude);
    }

    








    function sendOrigin(address _origin, address _target, uint256 _magnitude) public returns (bool altSuccess) {
        if (_magnitude <= permitted[_origin][msg.sender]) {
          permitted[_origin][msg.sender] -= _magnitude;
          _send(_origin, _target, _magnitude);
          return true;
        }
        else
          return false;
    }

    







    function authorize(address _delegate, uint256 _magnitude) public
        returns (bool altSuccess) {
        permitted[msg.sender][_delegate] = _magnitude;
        return true;
    }

    








    function authorizeAndCall(address _delegate, uint256 _magnitude, bytes _extraPayload)
        public
        returns (bool altSuccess) {
        assetBeneficiary delegate = assetBeneficiary(_delegate);
        if (authorize(_delegate, _magnitude)) {
            delegate.receiveAuthorization(msg.sender, _magnitude, this, _extraPayload);
            return true;
        }
    }

    






    function destroy(uint256 _magnitude) public returns (bool altSuccess) {
        require(holdingsOf[msg.sender] >= _magnitude);   
        holdingsOf[msg.sender] -= _magnitude;            
        aggregateIssuance -= _magnitude;                      
        emit Burn(msg.sender, _magnitude);
        return true;
    }

    







    function destroyOrigin(address _origin, uint256 _magnitude) public returns (bool altSuccess) {
        require(holdingsOf[_origin] >= _magnitude);                
        require(_magnitude <= permitted[_origin][msg.sender]);    
        holdingsOf[_origin] -= _magnitude;                         
        permitted[_origin][msg.sender] -= _magnitude;             
        aggregateIssuance -= _magnitude;                              
        emit Burn(_origin, _magnitude);
        return true;
    }
}





contract AuroraAsset is owned, AssetERC20 {

    uint256 public rate;
    uint256 public rateInc;
    uint256 public sendFees;

    mapping (address => bool) public lockedParty;

    
    event FrozenFunds(address altTarget, bool locked);

    
    function AuroraAsset (
        uint256 initialIssuance,
        uint8 initialPrecision,
        string assetLabel,
        string assetTicker
    ) AssetERC20(initialIssuance, initialPrecision, assetLabel, assetTicker) public {

        rate = 10 finney;
        rateInc = 10 finney;
        sendFees = 20 finney;
    }

    
    function _send(address _origin, address _target, uint _magnitude) internal {
        require (_target != 0x0);                               
        require (holdingsOf[_origin] >= _magnitude);               
        require (holdingsOf[_target] + _magnitude >= holdingsOf[_target]); 
        require(!lockedParty[_origin]);                     
        require(!lockedParty[_target]);                       
        holdingsOf[_origin] -= _magnitude;                         
        holdingsOf[_target] += _magnitude;                           
        emit Transfer(_origin, _target, _magnitude);
    }

    
    
    
    function createAsset(address altTarget, uint256 mintedQuantity) onlyAdministrator public {
        holdingsOf[altTarget] += mintedQuantity;
        aggregateIssuance += mintedQuantity;
        emit Transfer(0, this, mintedQuantity);
        emit Transfer(this, altTarget, mintedQuantity);
    }

    
    
    
    function lockParty(address altTarget, bool lock) onlyAdministrator public {
        lockedParty[altTarget] = lock;
        emit FrozenFunds(altTarget, lock);
    }

    
    
    
    
    function assignPrices(uint256 freshRate, uint256 freshRateInc, uint256 freshSendFees) onlyAdministrator public {
        require(freshSendFees > freshRateInc);
        rate = freshRate;
        rateInc = freshRateInc;
        sendFees = freshSendFees;
    }

    
    function purchase() payable public {
        require(msg.value == rate);
        uint quantity = msg.value / rate;               
        _send(this, msg.sender, quantity);              

        rate += rateInc;
    }

    
    
    function vend(uint256 quantity) public {
        require(quantity == 1);
        require(address(this).balance >= quantity * rate);      
        _send(msg.sender, this, quantity);              
        msg.sender.transfer(quantity * rate - sendFees);          

        rate -= rateInc;
    }
}
