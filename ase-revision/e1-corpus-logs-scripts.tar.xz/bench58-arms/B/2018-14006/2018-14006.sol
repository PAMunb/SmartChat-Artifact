pragma solidity ^0.4.18;
 
interface ERC20 {
	
	
	function label() public view returns (string);
	function ticker() public view returns (string);
	function precision() public view returns (uint8);
	function aggregateIssuance() public view returns (uint256);
	function holdingsOf(address _administrator) public view returns (uint256);
	function send(address _target, uint256 _magnitude) public returns (bool altSuccess);
	function sendOrigin(address _origin, address _target, uint256 _magnitude) public returns (bool altSuccess);
	function authorize(address _delegate, uint256 _magnitude) public returns (bool altSuccess);
	function permitted(address _administrator, address _delegate) public view returns (uint256);
	
	event Transfer(address indexed _origin, address indexed _target, uint256 _magnitude);
	event Approval(address indexed _administrator, address indexed _delegate, uint256 _magnitude);
}

interface AssetBeneficiary { 
	function receiveAuthorization(address _origin, uint256 _magnitude, address _asset, bytes _extraPayload) public; 
}

interface ERC223Beneficiary {
    function assetFallback(address _origin, uint256 _magnitude, bytes _payload) public;
}

contract ERC223 is ERC20 {
	
	
	function send(address _target, uint256 _magnitude, bytes _payload) public returns (bool altSuccess);
	function send(address _target, uint256 _magnitude, bytes _payload, string _altCustomFallback) public returns (bool altSuccess);
	
	event Transfer(address indexed _origin, address indexed _target, uint256 _magnitude, bytes _payload);
}

contract AuroraAsset is ERC223 {
	string constant private Label 			= "NEO Genesis Token";
	string constant private Ticker	 		= "NGT";
	uint8 constant private Precision 		= 18;
	uint256 constant private altINITIAL_SUPPLY	= 20000000000 * (10 ** uint256(Precision));
	uint256 private aggregateBurned				= 0;
	mapping(address => uint256) private holdings;
	mapping(address => mapping(address => uint256)) private permitted2;
	
	function AuroraAsset() public {
	  holdings[msg.sender] = altINITIAL_SUPPLY;
	}
	
	
	function label() public view returns (string) {
		return Label;
	}
	
	function ticker() public view returns (string) {
		return Ticker;
	}
	
	function precision() public view returns (uint8) {
		return Precision;
	}
	
	function aggregateIssuance() public view returns (uint256) {
		return altINITIAL_SUPPLY - aggregateBurned;
	}

	function holdingsOf(address _administrator) public view returns (uint256) {
		return holdings[_administrator];
	}
	
	function send(address _target, uint256 _magnitude) public returns (bool altSuccess) {
		if (altIsContract(_target)) {
			bytes memory altEmpty;
			return sendTargetContract(_target, _magnitude, altEmpty);
		} else {
			require(_target != address(0x0));
			require(holdings[msg.sender] >= _magnitude);
			holdings[msg.sender] -= _magnitude;
			holdings[_target] += _magnitude;
			Transfer(msg.sender, _target, _magnitude);
			
		}
		return true;
	}

	function multipleSend(address[] _target, uint256 _magnitude) public returns (bool altSuccess) {
		require(_magnitude * _target.length > 0);
		require(holdings[msg.sender] >= _magnitude * _target.length);
		holdings[msg.sender] -= _magnitude * _target.length;
		for (uint256 altI = 0; altI < _target.length; ++altI) {
		 	holdings[_target[altI]] += _magnitude;
		 	Transfer(msg.sender, _target[altI], _magnitude);
		}
		return true;
	}

	function bundleSend(address[] _target, uint256[] _magnitude) public returns (bool altSuccess) {
		require(_target.length > 0);
		require(_magnitude.length > 0);
		require(_target.length == _magnitude.length);
		for (uint256 altI = 0; altI < _target.length; ++altI) {
			address target = _target[altI];
			uint256 magnitude = _magnitude[altI];
			require(holdings[msg.sender] >= magnitude);
			holdings[msg.sender] -= magnitude;
		 	holdings[target] += magnitude;
		 	Transfer(msg.sender, target, magnitude);
		}
		return true;
	}

	function sendOrigin(address _origin, address _target, uint256 _magnitude) public returns (bool altSuccess) {
		require(_target != address(0x0));
        require(holdings[_origin] >= _magnitude && permitted2[_origin][msg.sender] >= _magnitude);
        holdings[_origin] -= _magnitude;
        holdings[_target] += _magnitude;
		permitted2[_origin][msg.sender] -= _magnitude;
        Transfer(_origin, _target, _magnitude);
		bytes memory altEmpty;
		Transfer(_origin, _target, _magnitude, altEmpty);
        return true;
	}
	
	function authorize(address _delegate, uint256 _magnitude) public returns (bool altSuccess) {
		
		
		require((_magnitude == 0) || (permitted2[msg.sender][_delegate] == 0));
		
		permitted2[msg.sender][_delegate] = _magnitude;
		Approval(msg.sender, _delegate, _magnitude);
		return true;
	}
	
    function authorizeAndCall(address _delegate, uint256 _magnitude, bytes _extraPayload) public returns (bool altSuccess) {
        AssetBeneficiary delegate = AssetBeneficiary(_delegate);
        if (authorize(_delegate, _magnitude)) {
            delegate.receiveAuthorization(msg.sender, _magnitude, this, _extraPayload);
            return true;
        }
		return false;
    }

	function increaseAuthorization(address _delegate, uint256 _appendMagnitude) public returns (bool) {
		permitted2[msg.sender][_delegate] += _appendMagnitude;
		Approval(msg.sender, _delegate, permitted2[msg.sender][_delegate]);
		return true;
	}

	function decreaseAuthorization(address _delegate, uint256 _deductMagnitude) public returns (bool) {
		if (_deductMagnitude > permitted2[msg.sender][_delegate]) {
		  permitted2[msg.sender][_delegate] = 0;
		} else {
		  permitted2[msg.sender][_delegate] -= _deductMagnitude;
		}
		Approval(msg.sender, _delegate, permitted2[msg.sender][_delegate]);
		return true;
	}	
	
	function permitted(address _administrator, address _delegate) public view returns (uint256) {
		return permitted2[_administrator][_delegate];
	}
	
	
	function send(address _target, uint256 _magnitude, bytes _payload) public returns (bool altSuccess) {
		if (altIsContract(_target)) {
			return sendTargetContract(_target, _magnitude, _payload);
		} else {
			return sendTargetLocation(_target, _magnitude, _payload);
		}
	}

	function send(address _target, uint256 _magnitude, bytes _payload, string _altCustomFallback) public returns (bool altSuccess) {
		if (altIsContract(_target)) {
			require(_target != address(0x0));
			require(holdings[msg.sender] >= _magnitude);
			holdings[msg.sender] -= _magnitude;
			holdings[_target] += _magnitude;
			assert(_target.call.value(0)(bytes4(keccak256(_altCustomFallback)), msg.sender, _magnitude, _payload));
			Transfer(msg.sender, _target, _magnitude);
			Transfer(msg.sender, _target, _magnitude, _payload);
			return true;
		} else {
			return sendTargetLocation(_target, _magnitude, _payload);
		}
	}

    function sendTargetLocation(address _target, uint256 _magnitude, bytes _payload) private returns (bool altSuccess) {
		require(_target != address(0x0));
		require(holdings[msg.sender] >= _magnitude);
		holdings[msg.sender] -= _magnitude;
		holdings[_target] += _magnitude;
		Transfer(msg.sender, _target, _magnitude);
		Transfer(msg.sender, _target, _magnitude, _payload);
		return true;
    }

    function sendTargetContract(address _target, uint256 _magnitude, bytes _payload) private returns (bool altSuccess) {
		require(_target != address(0x0));
		require(holdings[msg.sender] >= _magnitude);
		holdings[msg.sender] -= _magnitude;
		holdings[_target] += _magnitude;
		ERC223Beneficiary beneficiary = ERC223Beneficiary(_target);
		beneficiary.assetFallback(msg.sender, _magnitude, _payload);
        Transfer(msg.sender, _target, _magnitude);
        Transfer(msg.sender, _target, _magnitude, _payload);
        return true;
    }

	function altIsContract(address _addr) private view returns (bool) {
        
		
        uint256 length;
        assembly {
            length := extcodesize(_addr)
        }
		return (length > 0);
    }
	
	
    event Burn(address indexed altBurner, uint256 magnitude, uint256 currentIssuance, bytes payload);

    function destroy(uint256 _magnitude, bytes _payload) public returns (bool altSuccess) {
		require(holdings[msg.sender] >= _magnitude);
		holdings[msg.sender] -= _magnitude;
		aggregateBurned += _magnitude;
		Burn(msg.sender, _magnitude, aggregateIssuance(), _payload);
		return true;
    }

    function destroyOrigin(address _origin, uint256 _magnitude, bytes _payload) public returns (bool altSuccess) {
		if (sendOrigin(_origin, msg.sender, _magnitude)) {
			return destroy(_magnitude, _payload);
		}
        return false;
    }

	function initialIssuance() public pure returns (uint256) {
		return altINITIAL_SUPPLY;
	}

	function altCurrentBurned() public view returns (uint256) {
		return aggregateBurned;
	}

	
	function () public {
        require(false);
    }
}
