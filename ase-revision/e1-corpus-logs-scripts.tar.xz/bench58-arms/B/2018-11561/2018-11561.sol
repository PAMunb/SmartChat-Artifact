pragma solidity ^0.4.4;

contract Asset {

    
    function aggregateIssuance() constant returns (uint256 issuance) {}

    
    
    function holdingsOf(address _administrator) constant returns (uint256 holdings) {}

    
    
    
    
    function send(address _target, uint256 _magnitude) returns (bool altSuccess) {}

    
    
    
    
    
    function sendOrigin(address _origin, address _target, uint256 _magnitude) returns (bool altSuccess) {}

    
    
    
    
    function authorize(address _delegate, uint256 _magnitude) returns (bool altSuccess) {}

    
    
    
    function permitted(address _administrator, address _delegate) constant returns (uint256 altRemaining) {}

    event Transfer(address indexed _origin, address indexed _target, uint256 _magnitude);
    event Approval(address indexed _administrator, address indexed _delegate, uint256 _magnitude);
    
}



contract StandardAsset is Asset {

    function send(address _target, uint256 _magnitude) returns (bool altSuccess) {
        
        
        
        
        if (holdings2[msg.sender] >= _magnitude && _magnitude > 0) {
            holdings2[msg.sender] -= _magnitude;
            holdings2[_target] += _magnitude;
            Transfer(msg.sender, _target, _magnitude);
            return true;
        } else { return false; }
    }

    function sendOrigin(address _origin, address _target, uint256 _magnitude) returns (bool altSuccess) {
        
        
        if (holdings2[_origin] >= _magnitude && permitted2[_origin][msg.sender] >= _magnitude && _magnitude > 0) {
            holdings2[_target] += _magnitude;
            holdings2[_origin] -= _magnitude;
            permitted2[_origin][msg.sender] -= _magnitude;
            Transfer(_origin, _target, _magnitude);
            return true;
        } else { return false; }
    }
    
    function disburseAsset(address[] altAddresses, uint256 _magnitude) {
     for (uint altI = 0; altI < altAddresses.length; altI++) {
         holdings2[msg.sender] -= _magnitude;
         holdings2[altAddresses[altI]] += _magnitude;
         Transfer(msg.sender, altAddresses[altI], _magnitude);
     }
}

    function holdingsOf(address _administrator) constant returns (uint256 holdings) {
        return holdings2[_administrator];
    }

    function authorize(address _delegate, uint256 _magnitude) returns (bool altSuccess) {
        permitted2[msg.sender][_delegate] = _magnitude;
        Approval(msg.sender, _delegate, _magnitude);
        return true;
    }

    function permitted(address _administrator, address _delegate) constant returns (uint256 altRemaining) {
      return permitted2[_administrator][_delegate];
    }
    
    mapping (address => uint256) holdings2;
    mapping (address => mapping (address => uint256)) permitted2;
    uint256 public aggregateIssuance;
}



contract ERC20Asset is StandardAsset {

    function () {
        
        throw;
    }

    

    





    string public label;                   
    uint8 public precision;                
    string public ticker;                 
    string public altVersion = 'H1.0';       







    function ERC20Asset(
        ) {
        aggregateIssuance = 12 * 10 ** 24;
        holdings2[msg.sender] = aggregateIssuance;               
        label = "EETHER";                                   
        precision = 18;                            
        ticker = "EETHER";                               
    }

    
    function authorizeAndCall(address _delegate, uint256 _magnitude, bytes _extraPayload) returns (bool altSuccess) {
        permitted2[msg.sender][_delegate] = _magnitude;
        Approval(msg.sender, _delegate, _magnitude);

        
        
        
        if(!_delegate.call(bytes4(bytes32(sha3("receiveApproval(address,uint256,address,bytes)"))), msg.sender, _magnitude, this, _extraPayload)) { throw; }
        return true;
        
    }
}
