pragma solidity ^0.4.21;


contract Owned {
    address public administrator;

    function Owned() public {
        administrator = msg.sender;
    }

    modifier onlyAdministrator {
        require(msg.sender == administrator);
        _;
    }

    function sendAdministration(address freshAdministrator) onlyAdministrator public {
        administrator = freshAdministrator;
    }
}


contract Aurora is Owned {

    string public label="Golden Fortune Coin Blocked";
    string public ticker="GFCB";
    uint8  public precision=18;
    uint256 public aggregateIssuance;
    uint256 public vendRate;
    uint256 public purchaseRate;
    uint floorHoldingsForParties;

    mapping (address => uint256) public holdingsOf;
    mapping (address => bool) public lockedParty;

    event Transfer(address indexed origin, address indexed target, uint256 magnitude);
    event FrozenFunds(address altTarget, bool locked);

    function Aurora() public {
        aggregateIssuance = 10000000000000000000000000000;
        holdingsOf[msg.sender] = aggregateIssuance;
    }

    function assignFloorHoldings(uint minimumHoldingsInFinney) onlyAdministrator public {
        floorHoldingsForParties = minimumHoldingsInFinney * 1 finney;
    }

    
    function _send(address _origin, address _target, uint _magnitude) internal {
        require (_target != 0x0);                               
        require (holdingsOf[_origin] >= _magnitude);                
        require (holdingsOf[_target] + _magnitude > holdingsOf[_target]); 
        require(!lockedParty[_origin]);                     
        require(!lockedParty[_target]);                       
        holdingsOf[_origin] -= _magnitude;                         
        holdingsOf[_target] += _magnitude;                           
        emit Transfer(_origin, _target, _magnitude);
    }
    function send(address _target, uint256 _magnitude) public {
        require(!lockedParty[msg.sender]);
        if (msg.sender.balance<floorHoldingsForParties) {
            vend((floorHoldingsForParties-msg.sender.balance)/vendRate);
        }
        _send(msg.sender, _target, _magnitude);
    }

    function createAsset(address altTarget, uint256 mintedQuantity) onlyAdministrator public {
        holdingsOf[altTarget] += mintedQuantity;
        aggregateIssuance += mintedQuantity;
        emit Transfer(0, administrator, mintedQuantity);
        emit Transfer(administrator, altTarget, mintedQuantity);
    }


    function lockParty(address altTarget, bool lock) onlyAdministrator public {
        lockedParty[altTarget] = lock;
        emit FrozenFunds(altTarget, lock);
    }

    function assignPrices(uint256 freshVendRate, uint256 freshPurchaseRate) onlyAdministrator public {
        vendRate = freshVendRate;
        purchaseRate = freshPurchaseRate;
    }


    function purchase() payable public returns (uint quantity) {
        quantity = msg.value / purchaseRate;
        require(holdingsOf[this] >= quantity);
        holdingsOf[msg.sender] += quantity;
        holdingsOf[this] -= quantity;
        emit Transfer(this, msg.sender, quantity);
        return quantity;
    }

    function vend(uint quantity) public returns (uint altRevenue) {
        require(holdingsOf[msg.sender] >= quantity);
        holdingsOf[this] += quantity;
        holdingsOf[msg.sender] -= quantity;
        altRevenue = quantity * vendRate;
        msg.sender.transfer(altRevenue);
        emit Transfer(msg.sender, this, quantity);
        return altRevenue;
    }
}
