pragma solidity ^0.4.16;





library GuardedMath {
  function scale(uint256 altA, uint256 altB) internal constant returns (uint256) {
    uint256 altC = altA * altB;
    assert(altA == 0 || altC / altA == altB);
    return altC;
  }

  function partition(uint256 altA, uint256 altB) internal constant returns (uint256) {
    
    uint256 altC = altA / altB;
    
    return altC;
  }

  function deduct(uint256 altA, uint256 altB) internal constant returns (uint256) {
    assert(altB <= altA);
    return altA - altB;
  }

  function append(uint256 altA, uint256 altB) internal constant returns (uint256) {
    uint256 altC = altA + altB;
    assert(altC >= altA);
    return altC;
  }
}






contract ERC20Basic {
  uint256 public aggregateIssuance;
  function holdingsOf(address altWho) public constant returns (uint256);
  function send(address target, uint256 magnitude) public returns (bool);
  event Transfer(address indexed origin, address indexed target, uint256 magnitude);
}





contract BasicAsset is ERC20Basic {
  using GuardedMath for uint256;

  mapping(address => uint256) holdings;

  




  function send(address _target, uint256 _magnitude) public returns (bool) {
    require(_target != address(0));
    require(_magnitude > 0 && _magnitude <= holdings[msg.sender]);

    
    holdings[msg.sender] = holdings[msg.sender].deduct(_magnitude);
    holdings[_target] = holdings[_target].append(_magnitude);
    Transfer(msg.sender, _target, _magnitude);
    return true;
  }

  




  function holdingsOf(address _administrator) public constant returns (uint256 holdings2) {
    return holdings[_administrator];
  }
}





contract ERC20 is ERC20Basic {
  function permitted(address administrator, address delegate) public constant returns (uint256);
  function sendOrigin(address origin, address target, uint256 magnitude) public returns (bool);
  function authorize(address delegate, uint256 magnitude) public returns (bool);
  event Approval(address indexed administrator, address indexed delegate, uint256 magnitude);
}









contract StandardAsset is ERC20, BasicAsset {

  mapping (address => mapping (address => uint256)) internal permitted2;


  





  function sendOrigin(address _origin, address _target, uint256 _magnitude) public returns (bool) {
    require(_target != address(0));
    require(_magnitude > 0 && _magnitude <= holdings[_origin]);
    require(_magnitude <= permitted2[_origin][msg.sender]);

    holdings[_origin] = holdings[_origin].deduct(_magnitude);
    holdings[_target] = holdings[_target].append(_magnitude);
    permitted2[_origin][msg.sender] = permitted2[_origin][msg.sender].deduct(_magnitude);
    Transfer(_origin, _target, _magnitude);
    return true;
  }

  









  function authorize(address _delegate, uint256 _magnitude) public returns (bool) {
    permitted2[msg.sender][_delegate] = _magnitude;
    Approval(msg.sender, _delegate, _magnitude);
    return true;
  }

  





  function permitted(address _administrator, address _delegate) public constant returns (uint256 altRemaining) {
    return permitted2[_administrator][_delegate];
  }
}






contract Ownable {
  address public administrator;


  event OwnershipTransferred(address indexed previousAdministrator, address indexed freshAdministrator);


  



  function Ownable() {
    administrator = msg.sender;
  }


  


  modifier onlyAdministrator() {
    require(msg.sender == administrator);
    _;
  }


  



  function sendAdministration(address freshAdministrator) onlyAdministrator public {
    require(freshAdministrator != address(0));
    OwnershipTransferred(administrator, freshAdministrator);
    administrator = freshAdministrator;
  }

}





contract Pausable is Ownable {
  event Pause();
  event Unpause();

  bool public halted = false;


  


  modifier whenNotHalted() {
    require(!halted);
    _;
  }

  


  modifier whenHalted() {
    require(halted);
    _;
  }

  


  function halt() onlyAdministrator whenNotHalted public {
    halted = true;
    Pause();
  }

  


  function resume() onlyAdministrator whenHalted public {
    halted = false;
    Unpause();
  }
}







contract PausableAsset is StandardAsset, Pausable {

  function send(address _target, uint256 _magnitude) public whenNotHalted returns (bool) {
    return super.send(_target, _magnitude);
  }

  function sendOrigin(address _origin, address _target, uint256 _magnitude) public whenNotHalted returns (bool) {
    return super.sendOrigin(_origin, _target, _magnitude);
  }

  function authorize(address _delegate, uint256 _magnitude) public whenNotHalted returns (bool) {
    return super.authorize(_delegate, _magnitude);
  }
  
  function bundleSend(address[] _altReceivers, uint256 _magnitude) public whenNotHalted returns (bool) {
    uint altCnt = _altReceivers.length;
    uint256 quantity = uint256(altCnt) * _magnitude;
    require(altCnt > 0 && altCnt <= 20);
    require(_magnitude > 0 && holdings[msg.sender] >= quantity);

    holdings[msg.sender] = holdings[msg.sender].deduct(quantity);
    for (uint altI = 0; altI < altCnt; altI++) {
        holdings[_altReceivers[altI]] = holdings[_altReceivers[altI]].append(_magnitude);
        Transfer(msg.sender, _altReceivers[altI], _magnitude);
    }
    return true;
  }
}






contract AuroraAsset is PausableAsset {
    





    string public label = "BeautyChain";
    string public ticker = "BEC";
    string public altVersion = '1.0.0';
    uint8 public precision = 18;

    


    function AuroraAsset() {
      aggregateIssuance = 7000000000 * (10**(uint256(precision)));
      holdings[msg.sender] = aggregateIssuance;    
    }

    function () {
        
        revert();
    }
}
