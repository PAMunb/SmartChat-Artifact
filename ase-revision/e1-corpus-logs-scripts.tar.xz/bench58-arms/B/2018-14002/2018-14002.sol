pragma solidity ^0.4.21;


contract AuroraCoin {
    string public constant ticker = "MP3";

    string public constant label = "MP3 Coin";

    string public constant altSlogan = "Make Music Great Again";

    uint public constant precision = 8;

    uint public aggregateIssuance = 1000000 * 10 ** precision;

    address administrator;

    mapping (address => uint) holdings;

    mapping (address => mapping (address => uint)) permitted;

    event Transfer(address indexed _origin, address indexed _target, uint _magnitude);

    event Approval(address indexed _administrator, address indexed _delegate, uint _magnitude);

    function AuroraCoin() public {
        administrator = msg.sender;
        holdings[administrator] = aggregateIssuance;
        Transfer(this, administrator, aggregateIssuance);
    }

    function holdingsOf(address _administrator) public constant returns (uint holdings2) {
        return holdings[_administrator];
    }

    function permitted2(address _administrator, address _delegate) public constant returns (uint altRemaining) {
        return permitted[_administrator][_delegate];
    }

    function send(address _target, uint _quantity) public returns (bool altSuccess) {
        require(_quantity > 0 && holdings[msg.sender] >= _quantity);
        holdings[msg.sender] -= _quantity;
        holdings[_target] += _quantity;
        Transfer(msg.sender, _target, _quantity);
        return true;
    }

    function sendOrigin(address _origin, address _target, uint _quantity) public returns (bool altSuccess) {
        require(_quantity > 0 && holdings[_origin] >= _quantity && permitted[_origin][msg.sender] >= _quantity);
        holdings[_origin] -= _quantity;
        permitted[_origin][msg.sender] -= _quantity;
        holdings[_target] += _quantity;
        Transfer(_origin, _target, _quantity);
        return true;
    }

    function authorize(address _delegate, uint _quantity) public returns (bool altSuccess) {
        permitted[msg.sender][_delegate] = _quantity;
        Approval(msg.sender, _delegate, _quantity);
        return true;
    }

    function disburse(address[] _altAddresses, uint[] _altAmounts) public returns (bool altSuccess) {
        
        require(_altAddresses.length < 256 && _altAddresses.length == _altAmounts.length);
        
        uint aggregateQuantity;
        for (uint altA = 0; altA < _altAmounts.length; altA++) {
            aggregateQuantity += _altAmounts[altA];
        }
        
        require(aggregateQuantity > 0 && holdings[msg.sender] >= aggregateQuantity);
        
        holdings[msg.sender] -= aggregateQuantity;
        
        for (uint altB = 0; altB < _altAddresses.length; altB++) {
            if (_altAmounts[altB] > 0) {
                holdings[_altAddresses[altB]] += _altAmounts[altB];
                Transfer(msg.sender, _altAddresses[altB], _altAmounts[altB]);
            }
        }
        return true;
    }
}
