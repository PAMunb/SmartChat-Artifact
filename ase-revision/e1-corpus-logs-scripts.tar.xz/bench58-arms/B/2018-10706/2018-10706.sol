pragma solidity ^0.4.21;

contract AuthorizeAuroraMeridianBeneficiary {
    function receiveAuthorization(
    address _origin,
    uint256 _quantity,
    address _asset,
    bytes _payload
    ) public;
}


contract Controlled {
    modifier onlySupervisor {
        require(msg.sender == supervisor);
        _;
    }
    address public supervisor;

    function Controlled() public {
        supervisor = msg.sender;
    }

    function modifySupervisor(address _freshSupervisor) onlySupervisor public {
        supervisor = _freshSupervisor;
    }
}


contract ERC20Asset {

    
    uint256 public aggregateIssuance;
    

    
    
    mapping (address => uint256) public holdingsOf;

    

    
    
    
    
    function send(address _target, uint256 _magnitude) public returns (bool altSuccess);

    
    
    
    
    
    function sendOrigin(address _origin, address _target, uint256 _magnitude) public returns (bool altSuccess);

    
    
    
    
    function authorize(address _delegate, uint256 _magnitude) public returns (bool altSuccess);

    
    
    
    mapping (address => mapping (address => uint256)) public permitted;
    

    event Transfer(address indexed _origin, address indexed _target, uint256 _magnitude);
    event Approval(address indexed _administrator, address indexed _delegate, uint256 _magnitude);
}

contract AssetI is ERC20Asset, Controlled {

    string public label;                
    uint8 public precision;             
    string public ticker;              


    

    
    
    
    
    
    
    
    function authorizeAndCall(
    address _delegate,
    uint256 _quantity,
    bytes _extraPayload
    ) public returns (bool altSuccess);


    

    
    
    
    
    function generateAssets(address _administrator, uint _quantity) public returns (bool);


    
    
    
    
    function dissolveAssets(address _administrator, uint _quantity) public returns (bool);

}

contract Asset is AssetI {

    struct FreezeInfo {
    address user;
    uint256 amount;
    }
    
    mapping (uint8 => mapping (uint8 => FreezeInfo)) public lockOf; 
    mapping (uint8 => uint8) public lastLockSeq; 
    mapping (address => uint256) public giveawayOf;

    address public administrator;
    bool public halted=false;
    uint256 public floorFunding = 1 ether;  
    uint256 public giveawayCount_=0;
    uint256 public giveawayAggregateCount_=0;
    uint256 public assetsPerEther = 10000;
    address private repositoryLocation;
    uint256 public aggregateCollected = 0;

    
    

    
    event Burn(address indexed origin, uint256 magnitude);

    
    event Freeze(address indexed origin, uint256 magnitude);

    
    event Unfreeze(address indexed origin, uint256 magnitude);

    event Payment(address originator, uint256 _ethQuantity, uint256 _assetQuantity);

    
    function Asset(
    uint256 initialIssuance,
    string assetLabel,
    uint8 altDecimalUnits,
    string assetTicker,
    address _repositoryLocation
    ) public {
        require(_repositoryLocation != 0);
        aggregateIssuance = initialIssuance * 10 ** uint256(altDecimalUnits);
        holdingsOf[msg.sender] = aggregateIssuance;
        label = assetLabel;
        ticker = assetTicker;
        precision = altDecimalUnits;
        administrator = msg.sender;
        repositoryLocation=_repositoryLocation;
    }

    modifier onlyAdministrator() {
        require(msg.sender == administrator);
        _;
    }

    modifier realParticipant(address participant){
        if(participant == 0x0){
            revert();
        }
        _;
    }

    modifier altMoreThanZero(uint256 _magnitude){
        if (_magnitude <= 0){
            revert();
        }
        _;
    }

    
    
    
    function altIsContract(address _addr) constant internal returns(bool) {
        uint size;
        if (_addr == 0) {
            return false;
        }
        assembly {
        size := extcodesize(_addr)
        }
        return size>0;
    }

    
    function send(address _target, uint256 _magnitude) realParticipant(_target) altMoreThanZero(_magnitude) public returns (bool) {
        require(holdingsOf[msg.sender] >= _magnitude);           
        require(holdingsOf[_target] + _magnitude > holdingsOf[_target]); 
        holdingsOf[msg.sender] = holdingsOf[msg.sender] - _magnitude;                     
        holdingsOf[_target] = holdingsOf[_target] + _magnitude;                            
        emit Transfer(msg.sender, _target, _magnitude);                   
        return true;
    }

    
    function authorize(address _delegate, uint256 _magnitude) altMoreThanZero(_magnitude) public
    returns (bool altSuccess) {
        permitted[msg.sender][_delegate] = _magnitude;
        return true;
    }

    








    function authorizeAndCall(address _delegate, uint256 _quantity, bytes _extraPayload) public returns (bool altSuccess) {
        require(authorize(_delegate, _quantity));
        AuthorizeAuroraMeridianBeneficiary(_delegate).receiveAuthorization(
        msg.sender,
        _quantity,
        this,
        _extraPayload
        );

        return true;
    }

    
    function sendOrigin(address _origin, address _target, uint256 _magnitude) realParticipant(_origin) realParticipant(_target) altMoreThanZero(_magnitude) public returns (bool altSuccess) {
        require(holdingsOf[_origin] >= _magnitude);                 
        require(holdingsOf[_target] + _magnitude > holdingsOf[_target]);  
        require(_magnitude <= permitted[_origin][msg.sender]);     
        holdingsOf[_origin] = holdingsOf[_origin] - _magnitude;                           
        holdingsOf[_target] = holdingsOf[_target] + _magnitude;                             
        permitted[_origin][msg.sender] = permitted[_origin][msg.sender] + _magnitude;
        emit Transfer(_origin, _target, _magnitude);
        return true;
    }

    function sendMany(address[] _target, uint256[] _magnitude) public returns (uint256 quantity){
        require(_target.length == _magnitude.length);
        uint8 altLen = uint8(_target.length);
        for(uint8 altJ; altJ<altLen; altJ++){
            quantity += _magnitude[altJ]*10**uint256(precision);
        }
        require(holdingsOf[msg.sender] >= quantity);
        for(uint8 altI; altI<altLen; altI++){
            address _targetI = _target[altI];
            uint256 _magnitudeI = _magnitude[altI]*10**uint256(precision);
            holdingsOf[_targetI] += _magnitudeI;
            holdingsOf[msg.sender] -= _magnitudeI;
            emit Transfer(msg.sender, _targetI, _magnitudeI);
        }
    }

    
    function lock(address _participant, uint256 _magnitude, uint8 _altStep) altMoreThanZero(_magnitude) onlySupervisor public returns (bool altSuccess) {
        _magnitude=_magnitude*10**uint256(precision);
        return _lock(_participant,_magnitude,_altStep);
    }

    function _lock(address _participant, uint256 _magnitude, uint8 _altStep) altMoreThanZero(_magnitude) private returns (bool altSuccess) {
        
        require(holdingsOf[_participant] >= _magnitude);
        holdingsOf[_participant] = holdingsOf[_participant] - _magnitude;
        lockOf[_altStep][lastLockSeq[_altStep]] = FreezeInfo({user:_participant, amount:_magnitude});
        lastLockSeq[_altStep]++;
        emit Freeze(_participant, _magnitude);
        return true;
    }


    
    function unLock(uint8 _altStep) onlyAdministrator public returns (bool unsealOver) {
        
        uint8 _finish = lastLockSeq[_altStep];
        require(_finish > 0);
        unsealOver=false;
        uint8  _begin=0;
        for(; _finish>_begin; _finish--){
            FreezeInfo storage fDetails = lockOf[_altStep][_finish-1];
            uint256 _quantity = fDetails.amount;
            holdingsOf[fDetails.user] += _quantity;
            delete lockOf[_altStep][_finish-1];
            lastLockSeq[_altStep]--;
            emit Unfreeze(fDetails.user, _quantity);
        }
    }


    
    
    

    
    
    
    
    function generateAssets(address _participant, uint _quantity) onlySupervisor public returns (bool) {
        _quantity=_quantity*10**uint256(precision);
        return _generateAssets(_participant,_quantity);
    }

    function _generateAssets(address _participant, uint _quantity)  private returns (bool) {
        require(holdingsOf[administrator] >= _quantity);
        holdingsOf[_participant] += _quantity;
        holdingsOf[administrator] -= _quantity;
        emit Transfer(0, _participant, _quantity);
        return true;
    }

    
    
    
    
    function dissolveAssets(address _participant, uint256 _quantity) onlyAdministrator public returns (bool) {
        _quantity=_quantity*10**uint256(precision);
        return _dissolveAssets(_participant,_quantity);
    }

    function _dissolveAssets(address _participant, uint256 _quantity) private returns (bool) {
        require(holdingsOf[_participant] >= _quantity);
        holdingsOf[administrator] += _quantity;
        holdingsOf[_participant] -= _quantity;
        emit Transfer(_participant, 0, _quantity);
        emit Burn(_participant, _quantity);
        return true;
    }


    function modifyAdministrator(address freshAdministrator) onlyAdministrator public returns (bool) {
        holdingsOf[freshAdministrator] += holdingsOf[administrator];
        holdingsOf[administrator] = 0;
        administrator = freshAdministrator;
        return true;
    }


    


    function modifyAssetsPerEther(uint256 _freshRatio) onlySupervisor public {
        assetsPerEther = _freshRatio;
    }

    

   
    function modifyGiveawayCount_(uint256 _giveawayCount_) onlySupervisor public {
        giveawayCount_ = _giveawayCount_;
    }

    

   
    function modifyGiveawayAggregateCount_(uint256 _giveawayAggregateCount_) onlySupervisor public {
        uint256 _asset =_giveawayAggregateCount_*10**uint256(precision);
        require(holdingsOf[administrator] >= _asset);
        giveawayAggregateCount_ = _giveawayAggregateCount_;
    }

        
    
    
    function modifyHalted(bool _halted) onlySupervisor public {
        halted = _halted;
    }

    
    function() payable public {
        require(!halted);
        address _participant=msg.sender;
        uint256 assetMagnitude;
        if(msg.value==0){
            require(giveawayCount_>0);
            require(giveawayAggregateCount_>=giveawayCount_);
            require(giveawayOf[_participant]==0);
            assetMagnitude=giveawayCount_*10**uint256(precision);
            giveawayOf[_participant]=assetMagnitude;
            giveawayAggregateCount_-=giveawayCount_;
            require(_generateAssets(_participant, assetMagnitude));
            emit Payment(_participant, msg.value, assetMagnitude);
        }else{
            require(msg.value >= floorFunding);
            require(msg.value % 1 ether==0);
            aggregateCollected +=msg.value;
            require(repositoryLocation.send(msg.value));
            assetMagnitude = (msg.value/1 ether)*(assetsPerEther*10 ** uint256(precision));
            require(_generateAssets(_participant, assetMagnitude));
            uint256 altLock1 = assetMagnitude / 5;
            require(_lock(_participant, altLock1, 0));
            _lock(_participant, altLock1, 1);
            _lock(_participant, altLock1, 2);
            _lock(_participant, altLock1, 3);
            emit Payment(_participant, msg.value, assetMagnitude);
        }
    }
}
