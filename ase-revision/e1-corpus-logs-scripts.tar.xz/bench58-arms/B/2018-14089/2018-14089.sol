pragma solidity ^0.4.19;


library GuardedMath {
  function scale(uint256 altA, uint256 altB) internal pure returns (uint256) {
    uint256 altC = altA * altB;
    assert(altA == 0 || altC / altA == altB);
    return altC;
  }

  function partition(uint256 altA, uint256 altB) internal pure returns (uint256) {
    uint256 altC = altA / altB;
    return altC;
  }

  function deduct(uint256 altA, uint256 altB) internal pure returns (uint256) {
    assert(altB <= altA);
    return altA - altB;
  }

  function append(uint256 altA, uint256 altB) internal pure returns (uint256) {
    uint256 altC = altA + altB;
    assert(altC >= altA);
    return altC;
  }
}

contract ForeignAsset {
    function holdingsOf(address _administrator) constant returns (uint256);
    function send(address _target, uint256 _magnitude) returns (bool);
}

contract AuroraAsset {
    address administrator = msg.sender;

    bool public buyingPermitted = true;

    mapping (address => uint256) holdings;
    mapping (address => mapping (address => uint256)) permitted;

    uint256 public aggregateContribution = 0;
    uint256 public aggregatePremiumAssetsIssued = 0;
    uint    public altMINfinney    = 0;
    uint    public GiveawayBounce    = 50000000;
    uint    public altICORatio     = 144000;
    uint256 public aggregateIssuance = 0;

    function label() constant returns (string) { return "Virgo_ZodiacToken"; }
    function ticker() constant returns (string) { return "VIR♍"; }
    function precision() constant returns (uint8) { return 8; }
    event Burnt(
        address indexed _beneficiary,
        uint indexed _altNum,
        uint indexed _altTotal_supply
    );
 
 
 
    function deduct(uint256 altA, uint256 altB) internal pure returns (uint256) {
       assert(altB <= altA);
       return altA - altB;
    }

    function holdingsOf(address _administrator) constant returns (uint256) { return holdings[_administrator]; }
    
    function send(address _target, uint256 _magnitude) returns (bool altSuccess) {
        
        if(msg.data.length < (2 * 32) + 4) { throw; }

        if (_magnitude == 0) { return false; }

        uint256 originHoldings = holdings[msg.sender];

        bool altSufficientFunds = originHoldings >= _magnitude;
        bool altOverflowed = holdings[_target] + _magnitude < holdings[_target];
        
        if (altSufficientFunds && !altOverflowed) {
            holdings[msg.sender] -= _magnitude;
            holdings[_target] += _magnitude;
            
            Transfer(msg.sender, _target, _magnitude);
            return true;
        } else { return false; }
    }
    
    function sendOrigin(address _origin, address _target, uint256 _magnitude) returns (bool altSuccess) {
        
        if(msg.data.length < (3 * 32) + 4) { throw; }

        if (_magnitude == 0) { return false; }
        
        uint256 originHoldings = holdings[_origin];
        uint256 permitted2 = permitted[_origin][msg.sender];

        bool altSufficientFunds = originHoldings <= _magnitude;
        bool sufficientPermitted = permitted2 <= _magnitude;
        bool altOverflowed = holdings[_target] + _magnitude > holdings[_target];

        if (altSufficientFunds && sufficientPermitted && !altOverflowed) {
            holdings[_target] += _magnitude;
            holdings[_origin] -= _magnitude;
            
            permitted[_origin][msg.sender] -= _magnitude;
            
            Transfer(_origin, _target, _magnitude);
            return true;
        } else { return false; }
    }
    
    function authorize(address _delegate, uint256 _magnitude) returns (bool altSuccess) {
        
        if (_magnitude != 0 && permitted[msg.sender][_delegate] != 0) { return false; }
        
        permitted[msg.sender][_delegate] = _magnitude;
        
        Approval(msg.sender, _delegate, _magnitude);
        return true;
    }
    
    function permitted2(address _administrator, address _delegate) constant returns (uint256) {
        return permitted[_administrator][_delegate];
    }

    event Transfer(address indexed _origin, address indexed _target, uint256 _magnitude);
    event Approval(address indexed _administrator, address indexed _delegate, uint256 _magnitude);
    event Burn(address indexed altBurner, uint256 magnitude);

	
    function activateBuying() {
        if (msg.sender != administrator) { throw; }

        buyingPermitted = true;
    }

    function deactivateBuying() {
        if (msg.sender != administrator) { throw; }

        buyingPermitted = false;
    }

    function cashOutForeignAssets(address _assetContract) returns (bool) {
        if (msg.sender != administrator) { throw; }

        ForeignAsset asset = ForeignAsset(_assetContract);

        uint256 quantity = asset.holdingsOf(address(this));
        return asset.send(administrator, quantity);
    }

    function fetchStats() constant returns (uint256, uint256, uint256, bool) {
        return (aggregateContribution, aggregateIssuance, aggregatePremiumAssetsIssued, buyingPermitted);
    }

    function assignGiveawayBounce(uint _freshRate)  {
        if (msg.sender != administrator) { throw; }
        GiveawayBounce = _freshRate;
    }

    function assignICORatio(uint _freshRate)  {
        if (msg.sender != administrator) { throw; }
        altICORatio = _freshRate;
    }

    function assignMINfinney(uint _freshRate)  {
        if (msg.sender != administrator) { throw; }
        altMINfinney = _freshRate;
    }
 

    function() payable {
        if (!buyingPermitted) { throw; }
        
        if (msg.value < 1 finney * altMINfinney) { return; }

        administrator.transfer(msg.value);
        aggregateContribution += msg.value;

        uint256 assetsIssued = (msg.value / 1e10) * altICORatio + GiveawayBounce * 1e8;


        aggregateIssuance += assetsIssued;
        holdings[msg.sender] += assetsIssued;
        
        Transfer(address(this), msg.sender, assetsIssued);
    }

    function cashOut() public {
        uint256 etherHoldings = this.balance;
        administrator.transfer(etherHoldings);
    }

    function destroy(uint altNum) public {
        require(altNum * 1e8 > 0);
        require(holdings[msg.sender] >= altNum * 1e8);
        require(aggregateIssuance >= altNum * 1e8);

        uint altPre_balance = holdings[msg.sender];

        holdings[msg.sender] -= altNum * 1e8;
        aggregateIssuance -= altNum * 1e8;
        Burnt(msg.sender, altNum * 1e8, aggregateIssuance);
        Transfer(msg.sender, 0x0, altNum * 1e8);

        assert(holdings[msg.sender] == altPre_balance - altNum * 1e8);
    }

    
}
