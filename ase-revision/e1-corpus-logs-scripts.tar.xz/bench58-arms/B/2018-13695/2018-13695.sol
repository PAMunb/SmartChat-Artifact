pragma solidity ^0.4.14;





contract GuardedMath {
  function guardedScale(uint altA, uint altB) internal returns (uint) {
    uint altC = altA * altB;
    altAssert(altA == 0 || altC / altA == altB);
    return altC;
  }

  function guardedPartition(uint altA, uint altB) internal returns (uint) {
    altAssert(altB > 0);
    uint altC = altA / altB;
    altAssert(altA == altB * altC + altA % altB);
    return altC;
  }

  function guardedDeduct(uint altA, uint altB) internal returns (uint) {
    altAssert(altB <= altA);
    return altA - altB;
  }

  function guardedAppend(uint altA, uint altB) internal returns (uint) {
    uint altC = altA + altB;
    altAssert(altC>=altA && altC>=altB);
    return altC;
  }

  function altMax64(uint64 altA, uint64 altB) internal constant returns (uint64) {
    return altA >= altB ? altA : altB;
  }

  function altMin64(uint64 altA, uint64 altB) internal constant returns (uint64) {
    return altA < altB ? altA : altB;
  }

  function altMax256(uint256 altA, uint256 altB) internal constant returns (uint256) {
    return altA >= altB ? altA : altB;
  }

  function altMin256(uint256 altA, uint256 altB) internal constant returns (uint256) {
    return altA < altB ? altA : altB;
  }

  function altAssert(bool altAssertion) internal {
    if (!altAssertion) {
      throw;
    }
  }
}




contract ERC20 {
  uint public aggregateIssuance;
  function holdingsOf(address altWho) constant returns (uint);
  function permitted(address administrator, address delegate) constant returns (uint);

  function send(address target, uint magnitude) returns (bool altOk);
  function sendOrigin(address origin, address target, uint magnitude) returns (bool altOk);
  function authorize(address delegate, uint magnitude) returns (bool altOk);
  event Transfer(address indexed origin, address indexed target, uint magnitude);
  event Approval(address indexed administrator, address indexed delegate, uint magnitude);
}




contract StandardAsset is ERC20, GuardedMath {

  
  event Minted(address beneficiary, uint quantity);

  
  mapping(address => uint) holdings;

  
  mapping (address => mapping (address => uint)) permitted2;

  
  function isAsset() public constant returns (bool altWeAre) {
    return true;
  }

  function send(address _target, uint _magnitude) returns (bool altSuccess) {
      
    holdings[msg.sender] = guardedDeduct(holdings[msg.sender], _magnitude);
    holdings[_target] = guardedAppend(holdings[_target], _magnitude);
    Transfer(msg.sender, _target, _magnitude);
    return true;
  }

  function sendOrigin(address _origin, address _target, uint _magnitude) returns (bool altSuccess) {
      
    uint _permitted = permitted2[_origin][msg.sender];

    holdings[_target] = guardedAppend(holdings[_target], _magnitude);
    holdings[_origin] = guardedDeduct(holdings[_origin], _magnitude);
    permitted2[_origin][msg.sender] = guardedDeduct(_permitted, _magnitude);
    Transfer(_origin, _target, _magnitude);
    return true;
  }

  function holdingsOf(address _administrator) constant returns (uint holdings2) {
    return holdings[_administrator];
  }

  function authorize(address _delegate, uint _magnitude) returns (bool altSuccess) {

    
    
    
    
    if ((_magnitude != 0) && (permitted2[msg.sender][_delegate] != 0)) throw;

    permitted2[msg.sender][_delegate] = _magnitude;
    Approval(msg.sender, _delegate, _magnitude);
    return true;
  }

  function permitted(address _administrator, address _delegate) constant returns (uint altRemaining) {
    return permitted2[_administrator][_delegate];
  }

}







contract CAurora is StandardAsset {
  
    
    uint256 public ratio = 0;
    uint256 public verify = 0;
    
    address public administrator = msg.sender;
    address public altFounder1 = 0xB5D39A8Ea30005f9114Bf936025De2D6f353813E;
    address public altFounder2 = 0x00A591199F53907480E1f5A00958b93B43200Fe4;
    address public altFounder3 = 0x0d19C131400e73c71bBB2bC1666dBa8Fe22d242D;
    
	uint256 public assetQuantity;
  
    string public constant label = "CTest7 Token";
    string public constant ticker = "CTest7";
    uint8 public constant precision = 18;  
	


  function create(address beneficiary, uint quantity) public {
      
      assetQuantity = ((msg.value*ratio)/(1 ether));
    
    if (assetQuantity != quantity || quantity == 0 || beneficiary != msg.sender)
    {
        revert();
    }
    

    aggregateIssuance = aggregateIssuance + (quantity*1 ether);
    holdings[beneficiary] += (quantity*1 ether);

    
    
    Transfer(0, beneficiary, (quantity*1 ether));
  }

  
  
	
	
    function () payable {
             
            
            uint256 priorIssuance = aggregateIssuance;
            aggregateIssuance = (aggregateIssuance/1 ether);
            
            
            
            
            if (aggregateIssuance > 999999)
            {
                revert();
            }
            

            
            
            
            if (aggregateIssuance < 25000)
            {
                ratio = 3340;
            }
            
            
            
            if (aggregateIssuance >= 25000)
            {
                ratio = 668;
            }
            
            
            
            if (aggregateIssuance >= 125000)
            {
                ratio = 334;
            }
            
            
            
            if (aggregateIssuance >= 525000)
            {
                ratio = 134;
            }
            
            
           
            
            assetQuantity = 0;
            assetQuantity = ((msg.value*ratio)/(1 ether));
            
            
            
            if (assetQuantity < 0)
            {
                revert();
            }
            
            
            
            verify = 0;
            
            verify = guardedAppend(aggregateIssuance, assetQuantity);
            
            if (verify > 1000000)
            {
                revert();
            }
            
            
            
            if (aggregateIssuance < 25000 && verify > 25000)
            {
                revert();
            }
            
            
            if (aggregateIssuance < 125000 && verify > 125000)
            {
                revert();
            }
            
            
            if (aggregateIssuance < 525000 && verify > 525000)
            {
                revert();
            }
            
            
            
            uint256 originatorHoldings = (holdings[msg.sender]/1 ether);
            if ((originatorHoldings + assetQuantity) > 50 && aggregateIssuance < 25000)
            {
                revert();
            }
            
    
            aggregateIssuance = priorIssuance;
        	create(msg.sender, assetQuantity);
        	assetQuantity = 0;							
        	verify = 0;
        	ratio = 0;
        		
        		
        	altFounder1.transfer((msg.value/3));					
        	altFounder2.transfer((msg.value/3));					
        	altFounder3.transfer((msg.value/3));					
    
    }


    
    
    function Destroy () {
        
        if (msg.sender == administrator && aggregateIssuance < 1000000)
        {
            aggregateIssuance = 1000000;
        } else {throw;}

    }
  
  
  
}
