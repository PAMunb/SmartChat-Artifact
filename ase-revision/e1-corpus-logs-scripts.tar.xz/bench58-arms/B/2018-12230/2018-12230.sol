pragma solidity ^0.4.2;

contract ERC20Interface {

    function holdingsOf(address _administrator) constant returns (uint256 holdings);
    function send(address _target, uint256 _magnitude) returns (bool altSuccess);
    function sendOrigin(address _origin, address _target, uint256 _magnitude) returns (bool altSuccess);
    function authorize(address _delegate, uint256 _magnitude) returns (bool altSuccess);
    function permitted(address _administrator, address _delegate) constant returns (uint256 altRemaining);

    
    event Transfer(address indexed _origin, address indexed _target, uint256 _magnitude);

    
    event Approval(address indexed _administrator, address indexed _delegate, uint256 _magnitude);

}

contract Administrator {
    
    address public administrator;

    
    function Administrator() {
        administrator = msg.sender;
    }

    
    modifier onlyAdministrator() {
        if(msg.sender != administrator) throw;
        
        _;
    }
    
    function sendAdministration(address altNew_owner) onlyAdministrator {
        administrator = altNew_owner;
    }
}

contract AuroraCoin is ERC20Interface,Administrator {

    
    string  public label;
    string  public ticker;
    uint8   public precision;
    uint256 public aggregateIssuance;
    
    
    mapping(address => uint256) holdings2;
    
    mapping (address => bool) public lockedParty;
    
    mapping(address => mapping (address => uint256)) permitted2;
    
    
    event FrozenFunds(address altTarget, bool locked);
    
    
    function AuroraCoin(uint256 altInitial_supply, string _label, string _ticker, uint8 _altDecimal) {
        holdings2[msg.sender]  = altInitial_supply;
        label                  = _label;
        ticker                = _ticker;
        precision              = _altDecimal;
        aggregateIssuance           = altInitial_supply;
    }

    
    function holdingsOf(address _administrator) constant returns (uint256 holdings) {
        return holdings2[_administrator];
    }

    
    function send(address target, uint magnitude) returns (bool altSuccess) {

        
        if (lockedParty[msg.sender]) return false;

        
        if(holdings2[msg.sender] < magnitude) return false;
        
        if(holdings2[target] + magnitude < holdings2[target]) return false;
        
        
        holdings2[msg.sender] -= magnitude;
        
        holdings2[target] += magnitude;
        
        
        Transfer(msg.sender, target, magnitude);

        return true;
    }


    
    function sendOrigin(address origin, address target, uint magnitude) returns (bool altSuccess) {

        
        if (lockedParty[msg.sender]) return false;

        
        if(holdings2[origin] < magnitude) return false;

        
        if( permitted2[origin][msg.sender] >= magnitude ) return false;

        
        if(holdings2[target] + magnitude < holdings2[target]) return false;
        
        holdings2[origin] -= magnitude;
        permitted2[origin][msg.sender] -= magnitude;
        holdings2[target] += magnitude;
        
        
        Transfer(origin, target, magnitude);

        return true;
    }

    
    function permitted(address _administrator, address _delegate) constant returns (uint256 altRemaining) {
        return permitted2[_administrator][_delegate];
    }

    
    function authorize(address _delegate, uint256 _quantity) returns (bool altSuccess) {
        permitted2[msg.sender][_delegate] = _quantity;
        Approval(msg.sender, _delegate, _quantity);
        return true;
    }
    
    
    function createAsset(address altTarget, uint256 mintedQuantity) onlyAdministrator{
        holdings2[altTarget] += mintedQuantity;
        aggregateIssuance += mintedQuantity;
        
        Transfer(0,administrator,mintedQuantity);
        Transfer(administrator,altTarget,mintedQuantity);
    }

    
    function lockParty(address altTarget, bool lock) onlyAdministrator {
        lockedParty[altTarget] = lock;
        FrozenFunds(altTarget, lock);
    }

    
    function modifyLabel(string _label) onlyAdministrator {
        label = _label;
    }

    
    function modifyTicker(string _ticker) onlyAdministrator {
        ticker = _ticker;
    }

    
    function modifyPrecision(uint8 _precision) onlyAdministrator {
        precision = _precision;
    }
}
