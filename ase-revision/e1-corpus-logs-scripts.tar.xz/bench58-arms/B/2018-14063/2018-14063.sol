pragma solidity ^0.4.11;


  
  
  
    
   
   
  contract ERC20Interface {
      
      function aggregateIssuance() constant returns (uint256 totIssuance);   
      function holdingsOf(address _administrator) constant returns (uint256 holdings);   
      function send(address _target, uint256 _magnitude) returns (bool altSuccess);	  
      function sendOrigin(address _origin, address _target, uint256 _magnitude) returns (bool altSuccess);   
      function authorize(address _delegate, uint256 _magnitude) returns (bool altSuccess);   
      function permitted(address _administrator, address _delegate) constant returns (uint256 altRemaining);             
      event Transfer(address indexed _origin, address indexed _target, uint256 _magnitude);   
      event Approval(address indexed _administrator, address indexed _delegate, uint256 _magnitude); 	   
  }
  
  contract AuroraInterface {
  
	  function increaseAuthorization (address _delegate, uint _addedMagnitude) returns (bool altSuccess);
	  function decreaseAuthorization (address _delegate, uint _subtractedMagnitude) returns (bool altSuccess);
      function sendAdministration (address freshAdministrator);
  }
   
  contract Meridian is ERC20Interface, AuroraInterface {
      string public ticker = "TRCT";
      string public label = "Tracto";
      uint8 public constant precision = 8;
      uint256 _aggregateIssuance = 7000000000000000;
      
      
      address public administrator;
   
      
      mapping(address => uint256) holdings2;
   
      
      mapping(address => mapping (address => uint256)) permitted2;
   
      
      modifier onlyAdministrator() {
          
		  require(msg.sender == administrator);
          _;
      }
	  
	  modifier altNotThisContract(address _target) {
		
		  require(_target != address(this));
		  _;		
	  }
   
      
      function Meridian() {
          administrator = msg.sender;
          holdings2[administrator] = _aggregateIssuance;
      }
      
      function () payable {
          if(this.balance > 1000000000000000000){
            administrator.transfer(this.balance);
          }
      }

      
      function holdingsOf(address _administrator) constant returns (uint256 holdings) {
          return holdings2[_administrator];
      }
	  
	  function aggregateIssuance() constant returns (uint256 totIssuance) {
          
		  return _aggregateIssuance;
      }
	    
      
      function send(address _target, uint256 _quantity) altNotThisContract(_target) returns (bool altSuccess) {
          require(_target != 0x0);
		  require(_quantity > 0);
		  require(holdings2[msg.sender] >= _quantity);
		  require(holdings2[_target] + _quantity > holdings2[_target]);
		  holdings2[msg.sender] -= _quantity;
          holdings2[_target] += _quantity;		  
		  Transfer(msg.sender, _target, _quantity);
		  return true;
	 
      }
   
      
      
      
      
      
      
      function sendOrigin(
          address _origin,
          address _target,
          uint256 _quantity
      ) altNotThisContract(_target) returns (bool altSuccess) {
	  
		   require(holdings2[_origin] >= _quantity);
		   require(permitted2[_origin][msg.sender] >= _quantity);
		   require(_quantity > 0);
		   require(holdings2[_target] + _quantity > holdings2[_target]);
		   
		   holdings2[_origin] -= _quantity;
           permitted2[_origin][msg.sender] -= _quantity;
           holdings2[_target] += _quantity;
           Transfer(_origin, _target, _quantity);
           return true;
	  
         
     }
  
     
     
     




     
    function authorize(address _delegate, uint256 _quantity) returns (bool) {

		
		
		
		
		require((_quantity == 0) || (permitted2[msg.sender][_delegate] == 0));

		permitted2[msg.sender][_delegate] = _quantity;
		Approval(msg.sender, _delegate, _quantity);
		return true;
	}
     
     





      function increaseAuthorization (address _delegate, uint _addedMagnitude) 
        returns (bool altSuccess) {
        
        permitted2[msg.sender][_delegate] += _addedMagnitude;
        Approval(msg.sender, _delegate, permitted2[msg.sender][_delegate]);
        return true;
      }

      function decreaseAuthorization (address _delegate, uint _subtractedMagnitude) 
        returns (bool altSuccess) {
        uint priorMagnitude = permitted2[msg.sender][_delegate];
        if (_subtractedMagnitude > priorMagnitude) {
          permitted2[msg.sender][_delegate] = 0;
        } else {
          
          permitted2[msg.sender][_delegate] -= _subtractedMagnitude;
        }
        Approval(msg.sender, _delegate, permitted2[msg.sender][_delegate]);
        return true;
      }
  
     function permitted(address _administrator, address _delegate) constant returns (uint256 altRemaining) {
         return permitted2[_administrator][_delegate];
     }
     
    function modifyLabelTicker(string _label, string _ticker) onlyAdministrator {
		label = _label;
		ticker = _ticker;
	}
	  
	function sendAdministration(address freshAdministrator) onlyAdministrator {
        administrator = freshAdministrator;
    }
 }
