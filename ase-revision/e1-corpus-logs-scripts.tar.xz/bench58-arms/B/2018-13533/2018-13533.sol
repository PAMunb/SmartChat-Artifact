pragma solidity ^0.4.18;





contract owned {
    address public administrator;

    function owned() public {
        administrator = msg.sender;
    }

    modifier onlyAdministrator {
        require(msg.sender == administrator);
        _;
    }

    function sendAdministration(address freshAdministrator) onlyAdministrator public {
        administrator = freshAdministrator;
    }
}

contract AssetERC20 {
    string public label;
    string public ticker;
    uint8 public precision = 0;
    uint256 public aggregateIssuance;
    mapping (address => uint256) public holdingsOf;
    mapping (address => mapping (address => uint256)) public permitted;

    event Transfer(address indexed origin, address indexed target, uint256 magnitude);

    function AssetERC20(
        uint256 initialIssuance,
        string assetLabel,
        string assetTicker
    ) public {
        aggregateIssuance = initialIssuance * 10 ** uint256(precision);
        holdingsOf[msg.sender] = aggregateIssuance;
        label = assetLabel;
        ticker = assetTicker;
    }

    function _send(address _origin, address _target, uint _magnitude) internal {
        require(_target != 0x0);
        require(holdingsOf[_origin] >= _magnitude);
        require(holdingsOf[_target] + _magnitude > holdingsOf[_target]);
        uint previousHoldings = holdingsOf[_origin] + holdingsOf[_target];
        holdingsOf[_origin] -= _magnitude;
        holdingsOf[_target] += _magnitude;
        Transfer(_origin, _target, _magnitude);
        assert(holdingsOf[_origin] + holdingsOf[_target] == previousHoldings);
    }

    function send(address _target, uint256 _magnitude) public {
        _send(msg.sender, _target, _magnitude);
    }

    function sendOrigin(address _origin, address _target, uint256 _magnitude) public returns (bool altSuccess) {
        require(_magnitude <= permitted[_origin][msg.sender]);
        permitted[_origin][msg.sender] -= _magnitude;
        _send(_origin, _target, _magnitude);
        return true;
    }

    function authorize(address _delegate, uint256 _magnitude) public
        returns (bool altSuccess) {
        permitted[msg.sender][_delegate] = _magnitude;
        return true;
    }
}

contract AuroraAsset is owned, AssetERC20 {
    uint256 public vendRate = 10000000000000000;
    uint256 public purchaseRate = 10000000000000000;
    bool public closePurchase = false;
    bool public closeVend = false;
    address public altCommissionGetter = 0xCd8bf69ad65c5158F0cfAA599bBF90d7f4b52Bb0;
    uint256 public altMinimumCommission = 100000000000000;
    mapping (address => bool) public lockedParty;

    event FrozenFunds(address altTarget, bool locked);
    event LogDeposit(address originator, uint quantity);
    event LogWithdrawal(address beneficiary, uint quantity);

    function AuroraAsset(
        uint256 initialIssuance,
        string assetLabel,
        string assetTicker
    ) AssetERC20(initialIssuance, assetLabel, assetTicker) public {}

    function _send(address _origin, address _target, uint _magnitude) internal {
        require (_target != 0x0);
        require (holdingsOf[_origin] >= _magnitude);
        require (holdingsOf[_target] + _magnitude > holdingsOf[_target]);
        require(!lockedParty[_origin]);
        require(!lockedParty[_target]);
        holdingsOf[_origin] -= _magnitude;
        holdingsOf[_target] += _magnitude;
        Transfer(_origin, _target, _magnitude);
    }

    function refillAssets(uint256 _magnitude) public onlyAdministrator{
        _send(msg.sender, this, _magnitude);
    }

    function send(address _target, uint256 _magnitude) public {
        uint altMarket_value = _magnitude * vendRate;
        uint altCommission = altMarket_value * 4 / 1000;
        if (altCommission < altMinimumCommission){ altCommission = altMinimumCommission; }
        address altContr = this;
        require(altContr.balance >= altCommission);
        altCommissionGetter.transfer(altCommission);
        _send(msg.sender, _target, _magnitude);
    }

    function sendOrigin(address _origin, address _target, uint256 _magnitude) public returns (bool altSuccess) {
        require(_magnitude <= permitted[_origin][msg.sender]);
        uint altMarket_value = _magnitude * vendRate;
        uint altCommission = altMarket_value * 4 / 1000;
        if (altCommission < altMinimumCommission){ altCommission = altMinimumCommission; }
        address altContr = this;
        require(altContr.balance >= altCommission);
        altCommissionGetter.transfer(altCommission);
        permitted[_origin][msg.sender] -= _magnitude;
        _send(_origin, _target, _magnitude);
        return true;
    }

    function createAsset(uint256 mintedQuantity) onlyAdministrator public {
        holdingsOf[administrator] += mintedQuantity;
        aggregateIssuance += mintedQuantity;
        Transfer(0, this, mintedQuantity);
        Transfer(this, administrator, mintedQuantity);
    }

    function lockParty(address altTarget, bool lock) onlyAdministrator public {
        lockedParty[altTarget] = lock;
        FrozenFunds(altTarget, lock);
    }

    function assignPrices(uint256 freshVendRate, uint256 freshPurchaseRate) onlyAdministrator public {
        vendRate = freshVendRate;
        purchaseRate = freshPurchaseRate;
    }

    function assignStatus(bool isClosedPurchase, bool isClosedVend) onlyAdministrator public {
        closePurchase = isClosedPurchase;
        closeVend = isClosedVend;
    }

    function lodge() payable public returns(bool altSuccess) {
        address altContr = this;
        require((altContr.balance + msg.value) > altContr.balance);
        LogDeposit(msg.sender, msg.value);
        return true;
    }

    function cashOut(uint quantityInWeis) onlyAdministrator public {
        LogWithdrawal(msg.sender, quantityInWeis);
        administrator.transfer(quantityInWeis);
    }

    function purchase() payable public {
        require(!closePurchase);
        uint quantity = msg.value / purchaseRate;
        uint altMarket_value = quantity * purchaseRate;
        uint altCommission = altMarket_value * 4 / 1000;
        if (altCommission < altMinimumCommission){ altCommission = altMinimumCommission; }
        address altContr = this;
        require(altContr.balance >= altCommission);
        altCommissionGetter.transfer(altCommission);
        _send(this, msg.sender, quantity);
    }

    function vend(uint256 quantity) public {
    	require(!closeVend);
        address altContr = this;
        uint altMarket_value = quantity * vendRate;
        uint altCommission = altMarket_value * 4 / 1000;
        if (altCommission < altMinimumCommission){ altCommission = altMinimumCommission; }
        uint altAmount_weis = altMarket_value + altCommission;
        require(altContr.balance >= altAmount_weis);
        altCommissionGetter.transfer(altCommission);
        _send(msg.sender, this, quantity);
        msg.sender.transfer(altMarket_value);
    }

    function () public payable { purchase(); }
}
