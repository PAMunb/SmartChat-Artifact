pragma solidity ^0.4.24;





contract ERC20 {
  uint public aggregateIssuance;
  function holdingsOf(address altWho) constant returns (uint);
  function permitted(address administrator, address delegate) constant returns (uint);

  function send(address target, uint magnitude) returns (bool altOk);
  function sendOrigin(address origin, address target, uint magnitude) returns (bool altOk);
  function authorize(address delegate, uint magnitude) returns (bool altOk);
  event Transfer(address indexed origin, address indexed target, uint magnitude);
  event Approval(address indexed administrator, address indexed delegate, uint magnitude);
}






contract GuardedMath {
  function guardedScale(uint altA, uint altB) internal returns (uint) {
    uint altC = altA * altB;
    altAssert(altA == 0 || altC / altA == altB);
    return altC;
  }

  function guardedPartition(uint altA, uint altB) internal returns (uint) {
    altAssert(altB > 0);
    uint altC = altA / altB;
    altAssert(altA == altB * altC + altA % altB);
    return altC;
  }

  function guardedDeduct(uint altA, uint altB) internal returns (uint) {
    altAssert(altB <= altA);
    return altA - altB;
  }

  function guardedAppend(uint altA, uint altB) internal returns (uint) {
    uint altC = altA + altB;
    altAssert(altC>=altA && altC>=altB);
    return altC;
  }

  function altMax64(uint64 altA, uint64 altB) internal constant returns (uint64) {
    return altA >= altB ? altA : altB;
  }

  function altMin64(uint64 altA, uint64 altB) internal constant returns (uint64) {
    return altA < altB ? altA : altB;
  }

  function altMax256(uint256 altA, uint256 altB) internal constant returns (uint256) {
    return altA >= altB ? altA : altB;
  }

  function altMin256(uint256 altA, uint256 altB) internal constant returns (uint256) {
    return altA < altB ? altA : altB;
  }

  function altAssert(bool altAssertion) internal {
    if (!altAssertion) {
      throw;
    }
  }
}









contract StandardAsset is ERC20, GuardedMath {

  
  event Minted(address beneficiary, uint quantity);

  
  mapping(address => uint) holdings;

  
  mapping (address => mapping (address => uint)) permitted2;

  





  modifier altOnlyPayloadSize(uint altSize) {
     if(msg.data.length != altSize + 4) {
       throw;
     }
     _;
  }

  function send(address _target, uint _magnitude) altOnlyPayloadSize(2 * 32) returns (bool altSuccess) {
    holdings[msg.sender] = guardedDeduct(holdings[msg.sender], _magnitude);
    holdings[_target] = guardedAppend(holdings[_target], _magnitude);
    Transfer(msg.sender, _target, _magnitude);
    return true;
  }

  function sendOrigin(address _origin, address _target, uint _magnitude) returns (bool altSuccess) {
    uint _permitted = permitted2[_origin][msg.sender];

    
    

    holdings[_target] = guardedAppend(holdings[_target], _magnitude);
    holdings[_origin] = guardedDeduct(holdings[_origin], _magnitude);
    permitted2[_origin][msg.sender] = guardedDeduct(_permitted, _magnitude);
    Transfer(_origin, _target, _magnitude);
    return true;
  }

  function holdingsOf(address _administrator) constant returns (uint holdings2) {
    return holdings[_administrator];
  }

  function authorize(address _delegate, uint _magnitude) returns (bool altSuccess) {

    
    
    
    
    if ((_magnitude != 0) && (permitted2[msg.sender][_delegate] != 0)) throw;

    permitted2[msg.sender][_delegate] = _magnitude;
    Approval(msg.sender, _delegate, _magnitude);
    return true;
  }

  function permitted(address _administrator, address _delegate) constant returns (uint altRemaining) {
    return permitted2[_administrator][_delegate];
  }

  





  function appendAuthorization(address _delegate, uint _addedMagnitude)
  altOnlyPayloadSize(2 * 32)
  returns (bool altSuccess) {
      uint priorMagnitude = permitted2[msg.sender][_delegate];
      permitted2[msg.sender][_delegate] = guardedAppend(priorMagnitude, _addedMagnitude);
      Approval(msg.sender, _delegate, permitted2[msg.sender][_delegate]);
      return true;
  }

  




  function deductAuthorization(address _delegate, uint _subtractedMagnitude)
  altOnlyPayloadSize(2 * 32)
  returns (bool altSuccess) {

      uint priorVal = permitted2[msg.sender][_delegate];

      if (_subtractedMagnitude > priorVal) {
          permitted2[msg.sender][_delegate] = 0;
      } else {
          permitted2[msg.sender][_delegate] = guardedDeduct(priorVal, _subtractedMagnitude);
      }
      Approval(msg.sender, _delegate, permitted2[msg.sender][_delegate]);
      return true;
  }

}



contract BurnableAsset is StandardAsset {

  address public constant altBURN_ADDRESS = 0;

  
  event Burned(address altBurner, uint burnedQuantity);

  



  function destroy(uint destroyQuantity) {
    address altBurner = msg.sender;
    holdings[altBurner] = guardedDeduct(holdings[altBurner], destroyQuantity);
    aggregateIssuance = guardedDeduct(aggregateIssuance, destroyQuantity);
    Burned(altBurner, destroyQuantity);
  }
}











contract UpgradeAgent {

  uint public originalIssuance;

  
  function altIsUpgradeAgent() public constant returns (bool) {
    return true;
  }

  function upgradeOrigin(address _origin, uint256 _magnitude) public;

}







contract UpgradeableAsset is StandardAsset {

  
  address public altUpgradeMaster;

  
  UpgradeAgent public altUpgradeAgent;

  
  uint256 public aggregateUpgraded;

  








  enum UpgradeState {Unknown, NotAllowed, WaitingForAgent, ReadyToUpgrade, Upgrading}

  


  event Upgrade(address indexed _origin, address indexed _target, uint256 _magnitude);

  


  event UpgradeAgentSet(address altAgent);

  


  function UpgradeableAsset(address _altUpgradeMaster) {
    altUpgradeMaster = _altUpgradeMaster;
  }

  


  function altUpgrade(uint256 magnitude) public {

      UpgradeState altState = fetchUpgradeState();
      if(!(altState == UpgradeState.ReadyToUpgrade || altState == UpgradeState.Upgrading)) {
        
        throw;
      }

      
      if (magnitude == 0) throw;

      holdings[msg.sender] = guardedDeduct(holdings[msg.sender], magnitude);

      
      aggregateIssuance = guardedDeduct(aggregateIssuance, magnitude);
      aggregateUpgraded = guardedAppend(aggregateUpgraded, magnitude);

      
      altUpgradeAgent.upgradeOrigin(msg.sender, magnitude);
      Upgrade(msg.sender, altUpgradeAgent, magnitude);
  }

  


  function assignUpgradeAgent(address altAgent) external {

      if(!altCanUpgrade()) {
        
        throw;
      }

      if (altAgent == 0x0) throw;
      
      if (msg.sender != altUpgradeMaster) throw;
      
      if (fetchUpgradeState() == UpgradeState.Upgrading) throw;

      altUpgradeAgent = UpgradeAgent(altAgent);

      
      if(!altUpgradeAgent.altIsUpgradeAgent()) throw;
      
      if (altUpgradeAgent.originalIssuance() != aggregateIssuance) throw;

      UpgradeAgentSet(altUpgradeAgent);
  }

  


  function fetchUpgradeState() public constant returns(UpgradeState) {
    if(!altCanUpgrade()) return UpgradeState.NotAllowed;
    else if(address(altUpgradeAgent) == 0x00) return UpgradeState.WaitingForAgent;
    else if(aggregateUpgraded == 0) return UpgradeState.ReadyToUpgrade;
    else return UpgradeState.Upgrading;
  }

  




  function assignUpgradeMaster(address altMaster) public {
      if (altMaster == 0x0) throw;
      if (msg.sender != altUpgradeMaster) throw;
      altUpgradeMaster = altMaster;
  }

  


  function altCanUpgrade() public constant returns(bool) {
     return true;
  }

}


contract AuroraAsset is BurnableAsset, UpgradeableAsset {

  string public label;
  string public ticker;
  uint public precision;
  address public administrator;

  
  mapping (address => bool) public createAgents;

  event MintingAgentChanged(address location, bool altState);

  




  function create(address beneficiary, uint quantity) onlyCreateAgent public {
    aggregateIssuance = aggregateIssuance + quantity;
    holdings[beneficiary] = holdings[beneficiary] + quantity;

    
    
    Transfer(0, beneficiary, quantity);
  }

  


  function assignCreateAgent(address location, bool altState) onlyAdministrator public {
    createAgents[location] = altState;
    MintingAgentChanged(location, altState);
  }

  modifier onlyCreateAgent() {
    
    if(!createAgents[msg.sender]) {
        throw;
    }
    _;
  }

  modifier onlyAdministrator() {
    if (msg.sender != administrator) {
      throw;
    }
    _;
  }

  function AuroraAsset(address _administrator, string _label, string _ticker, uint _aggregateIssuance, uint _precision) UpgradeableAsset(_administrator) {
    label = _label;
    ticker = _ticker;
    aggregateIssuance = _aggregateIssuance;
    precision = _precision;

    
    holdings[_administrator] = _aggregateIssuance;
    administrator = _administrator;
  }
}
