pragma solidity ^0.4.11;

contract Asset {
    uint256 public aggregateIssuance;
    function holdingsOf(address _administrator) constant returns (uint256 holdings);
    function send(address _target, uint256 _magnitude) returns (bool altSuccess);
    function sendOrigin(address _origin, address _target, uint256 _magnitude) returns (bool altSuccess);
    function authorize(address _delegate, uint256 _magnitude) returns (bool altSuccess);
    function permitted(address _administrator, address _delegate) constant returns (uint256 altRemaining);
    event Transfer(address indexed _origin, address indexed _target, uint256 _magnitude);
    event Approval(address indexed _administrator, address indexed _delegate, uint256 _magnitude);
}

contract StandardAsset is Asset {
	bool public inactive = false;
    function send(address _target, uint256 _magnitude) returns (bool altSuccess) {
        if (inactive != true && holdings2[msg.sender] >= _magnitude && _magnitude > 0) {
            holdings2[msg.sender] -= _magnitude;
            holdings2[_target] += _magnitude;
            Transfer(msg.sender, _target, _magnitude);
            return true;
        } else { return false; }
    }
    function sendOrigin(address _origin, address _target, uint256 _magnitude) returns (bool altSuccess) {
        if (inactive != true && holdings2[_origin] >= _magnitude && permitted2[_origin][msg.sender] >= _magnitude && _magnitude > 0) {
            holdings2[_target] += _magnitude;
            holdings2[_origin] -= _magnitude;
            permitted2[_origin][msg.sender] -= _magnitude;
            Transfer(_origin, _target, _magnitude);
            return true;
        } else { return false; }
    }
    function holdingsOf(address _administrator) constant returns (uint256 holdings) {
        return holdings2[_administrator];
    }
    function authorize(address _delegate, uint256 _magnitude) returns (bool altSuccess) {
        permitted2[msg.sender][_delegate] = _magnitude;
        Approval(msg.sender, _delegate, _magnitude);
        return true;
    }
    function permitted(address _administrator, address _delegate) constant returns (uint256 altRemaining) {
      return permitted2[_administrator][_delegate];
    }
    mapping (address => uint256) holdings2;
    mapping (address => mapping (address => uint256)) permitted2;
}

contract AuroraAsset is StandardAsset {

    function () {return;}

    string public label = "Nexxus";
    uint8 public precision = 8;
    string public ticker = "NXX";
    address public administrator;

    function AuroraAsset() {
        aggregateIssuance = 31800000000000000;
        administrator = msg.sender;
        holdings2[administrator] = aggregateIssuance;
    }
    function authorizeAndCall(address _delegate, uint256 _magnitude, bytes _extraPayload) returns (bool altSuccess) {
        permitted2[msg.sender][_delegate] = _magnitude;
        Approval(msg.sender, _delegate, _magnitude);
        if(!_delegate.call(bytes4(bytes32(sha3("receiveApproval(address,uint256,address,bytes)"))), msg.sender, _magnitude, this, _extraPayload)) { return; }
        return true;
    }
	function createAsset(uint256 _quantity) {
        if (msg.sender == administrator) {
    		aggregateIssuance += _quantity;
            holdings2[administrator] += _quantity;
    		Transfer(0, administrator, _quantity);
        }
	}
	function deactivateAsset(bool _deactivate) { 
        if (msg.sender == administrator)
			inactive = _deactivate;
    }
}
