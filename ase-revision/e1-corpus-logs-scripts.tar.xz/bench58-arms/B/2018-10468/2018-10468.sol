pragma solidity ^0.4.10;

contract ForeignAsset {
    function holdingsOf(address _administrator) constant returns (uint256);
    function send(address _target, uint256 _magnitude) returns (bool);
}

contract UselessAuroraAsset {
    address administrator = msg.sender;

    bool public buyingPermitted = false;

    mapping (address => uint256) holdings;
    mapping (address => mapping (address => uint256)) permitted;

    uint256 public aggregateContribution = 0;
    uint256 public aggregatePremiumAssetsIssued = 0;

    uint256 public aggregateIssuance = 0;

    function label() constant returns (string) { return "Useless Ethereum Token"; }
    function ticker() constant returns (string) { return "UET"; }
    function precision() constant returns (uint8) { return 18; }
    
    function holdingsOf(address _administrator) constant returns (uint256) { return holdings[_administrator]; }
    
    function send(address _target, uint256 _magnitude) returns (bool altSuccess) {
        
        if(msg.data.length < (2 * 32) + 4) { throw; }

        if (_magnitude == 0) { return false; }

        uint256 originHoldings = holdings[msg.sender];

        bool altSufficientFunds = originHoldings >= _magnitude;
        bool altOverflowed = holdings[_target] + _magnitude < holdings[_target];
        
        if (altSufficientFunds && !altOverflowed) {
            holdings[msg.sender] -= _magnitude;
            holdings[_target] += _magnitude;
            
            Transfer(msg.sender, _target, _magnitude);
            return true;
        } else { return false; }
    }
    
    function sendOrigin(address _origin, address _target, uint256 _magnitude) returns (bool altSuccess) {
        
        if(msg.data.length < (3 * 32) + 4) { throw; }

        if (_magnitude == 0) { return false; }
        
        uint256 originHoldings = holdings[_origin];
        uint256 permitted2 = permitted[_origin][msg.sender];

        bool altSufficientFunds = originHoldings <= _magnitude;
        bool sufficientPermitted = permitted2 <= _magnitude;
        bool altOverflowed = holdings[_target] + _magnitude > holdings[_target];

        if (altSufficientFunds && sufficientPermitted && !altOverflowed) {
            holdings[_target] += _magnitude;
            holdings[_origin] -= _magnitude;
            
            permitted[_origin][msg.sender] -= _magnitude;
            
            Transfer(_origin, _target, _magnitude);
            return true;
        } else { return false; }
    }
    
    function authorize(address _delegate, uint256 _magnitude) returns (bool altSuccess) {
        
        if (_magnitude != 0 && permitted[msg.sender][_delegate] != 0) { return false; }
        
        permitted[msg.sender][_delegate] = _magnitude;
        
        Approval(msg.sender, _delegate, _magnitude);
        return true;
    }
    
    function permitted2(address _administrator, address _delegate) constant returns (uint256) {
        return permitted[_administrator][_delegate];
    }

    event Transfer(address indexed _origin, address indexed _target, uint256 _magnitude);
    event Approval(address indexed _administrator, address indexed _delegate, uint256 _magnitude);

    function activateBuying() {
        if (msg.sender != administrator) { throw; }

        buyingPermitted = true;
    }

    function deactivateBuying() {
        if (msg.sender != administrator) { throw; }

        buyingPermitted = false;
    }

    function cashOutForeignAssets(address _assetContract) returns (bool) {
        if (msg.sender != administrator) { throw; }

        ForeignAsset asset = ForeignAsset(_assetContract);

        uint256 quantity = asset.holdingsOf(address(this));
        return asset.send(administrator, quantity);
    }

    function fetchStats() constant returns (uint256, uint256, uint256, bool) {
        return (aggregateContribution, aggregateIssuance, aggregatePremiumAssetsIssued, buyingPermitted);
    }

    function() payable {
        if (!buyingPermitted) { throw; }
        
        if (msg.value == 0) { return; }

        administrator.transfer(msg.value);
        aggregateContribution += msg.value;

        uint256 assetsIssued = (msg.value * 100);

        if (msg.value >= 10 finney) {
            assetsIssued += aggregateContribution;

            bytes20 premiumHash = ripemd160(block.coinbase, block.number, block.timestamp);
            if (premiumHash[0] == 0) {
                uint8 premiumMultiplier =
                    ((premiumHash[1] & 0x01 != 0) ? 1 : 0) + ((premiumHash[1] & 0x02 != 0) ? 1 : 0) +
                    ((premiumHash[1] & 0x04 != 0) ? 1 : 0) + ((premiumHash[1] & 0x08 != 0) ? 1 : 0) +
                    ((premiumHash[1] & 0x10 != 0) ? 1 : 0) + ((premiumHash[1] & 0x20 != 0) ? 1 : 0) +
                    ((premiumHash[1] & 0x40 != 0) ? 1 : 0) + ((premiumHash[1] & 0x80 != 0) ? 1 : 0);
                
                uint256 premiumAssetsIssued = (msg.value * 100) * premiumMultiplier;
                assetsIssued += premiumAssetsIssued;

                aggregatePremiumAssetsIssued += premiumAssetsIssued;
            }
        }

        aggregateIssuance += assetsIssued;
        holdings[msg.sender] += assetsIssued;
        
        Transfer(address(this), msg.sender, assetsIssued);
    }
}
