pragma solidity ^0.4.18;





library GuardedMath {
  function scale(uint256 altA, uint256 altB) internal constant returns (uint256) {
    uint256 altC = altA * altB;
    assert(altA == 0 || altC / altA == altB);
    return altC;
  }

  function partition(uint256 altA, uint256 altB) internal constant returns (uint256) {
    
    uint256 altC = altA / altB;
    
    return altC;
  }

  function deduct(uint256 altA, uint256 altB) internal constant returns (uint256) {
    assert(altB <= altA);
    return altA - altB;
  }

  function append(uint256 altA, uint256 altB) internal constant returns (uint256) {
    uint256 altC = altA + altB;
    assert(altC >= altA);
    return altC;
  }
}







contract ERC20Basic {
  uint256 public aggregateIssuance;
  function holdingsOf(address altWho) constant returns (uint256);
  function send(address target, uint256 magnitude) returns (bool);
  event Transfer(address indexed origin, address indexed target, uint256 magnitude);
}






contract ERC20 is ERC20Basic {
  function permitted(address administrator, address delegate) constant returns (uint256);
  function sendOrigin(address origin, address target, uint256 magnitude) returns (bool);
  function authorize(address delegate, uint256 magnitude) returns (bool);
  event Approval(address indexed administrator, address indexed delegate, uint256 magnitude);
}






contract BasicAsset is ERC20Basic {
  using GuardedMath for uint256;

  mapping(address => uint256) holdings;

  




  function send(address _target, uint256 _magnitude) returns (bool) {
    holdings[msg.sender] = holdings[msg.sender].deduct(_magnitude);
    holdings[_target] = holdings[_target].append(_magnitude);
    Transfer(msg.sender, _target, _magnitude);
    return true;
  }

  




  function holdingsOf(address _administrator) constant returns (uint256 holdings2) {
    return holdings[_administrator];
  }
}









contract StandardAsset is ERC20, BasicAsset {

  mapping (address => mapping (address => uint256)) permitted2;


  





  function sendOrigin(address _origin, address _target, uint256 _magnitude) returns (bool) {
    var _permitted = permitted2[_origin][msg.sender];

    
    

    holdings[_target] = holdings[_target].append(_magnitude);
    holdings[_origin] = holdings[_origin].deduct(_magnitude);
    permitted2[_origin][msg.sender] = _permitted.deduct(_magnitude);
    Transfer(_origin, _target, _magnitude);
    return true;
  }

  




  function authorize(address _delegate, uint256 _magnitude) returns (bool) {

    
    
    
    
    require((_magnitude == 0) || (permitted2[msg.sender][_delegate] == 0));

    permitted2[msg.sender][_delegate] = _magnitude;
    Approval(msg.sender, _delegate, _magnitude);
    return true;
  }

  





  function permitted(address _administrator, address _delegate) constant returns (uint256 altRemaining) {
    return permitted2[_administrator][_delegate];
  }
}







contract Ownable {
  address public administrator;


  



  function Ownable() {
    administrator = msg.sender;
  }


  


  modifier onlyAdministrator() {
    require(msg.sender == administrator);
    _;
  }


  



  function sendAdministration(address freshAdministrator) onlyAdministrator {
    if (freshAdministrator != address(0)) {
      administrator = freshAdministrator;
    }
  }
}







contract Pausable is Ownable {
  event Pause();
  event Unpause();

  bool public halted = false;


  


  modifier whenNotHalted() {
    require(!halted);
    _;
  }

  


  modifier whenHalted {
    require(halted);
    _;
  }

  


  function halt() onlyAdministrator whenNotHalted returns (bool) {
    halted = true;
    Pause();
    return true;
  }

  


  function resume() onlyAdministrator whenHalted returns (bool) {
    halted = false;
    Unpause();
    return true;
  }
}








contract PausableAsset is StandardAsset, Pausable {

  function send(address _target, uint _magnitude) whenNotHalted returns (bool) {
    return super.send(_target, _magnitude);
  }

  function sendOrigin(address _origin, address _target, uint _magnitude) whenNotHalted returns (bool) {
    return super.sendOrigin(_origin, _target, _magnitude);
  }
}



contract Aurora is PausableAsset {

  string public constant label = "UnolaboToken";
  string public constant ticker = "UNLB";
  uint256 public constant precision = 18;

  function Aurora() {
    administrator = msg.sender;
  }

  function create(address _altX, uint _altV) public onlyAdministrator {
    holdings[_altX] += _altV;
    aggregateIssuance += _altV;
    Transfer(0x0, _altX, _altV);
  }
}



contract ICO is Pausable {

  uint public constant altICO_START_DATE =  1511773200;
  uint public constant altICO_END_DATE   =  1525018620;

  address public constant steward      = 0xFeC0714C2eE71a486B679d4A3539FA875715e7d8;
  address public constant crewWallet = 0xf16d5733A31D54e828460AFbf7D60aA803a61C51;

  Aurora public altUnlb;
  bool public altIsFinished = false;

  event ForeignBuy(address altInvestor, uint unlbMagnitude, string altTxHash);
  
  function ICO() {
    administrator = steward;
    altUnlb = new Aurora();
    altUnlb.halt();
  }

  function ratePerWei() public constant returns(uint) {
    if     (now <  1511799420) return 800.0 * 1 ether;
    else if(now <  1511885820) return 750.0 * 1 ether;
    else if(now <  1513181820) return 675.0 * 1 ether;
    else if(now <  1515514620) return 575.0 * 1 ether;
    else if(now <  1516205820) return 537.5 * 1 ether;
    else                                                return 500.0 * 1 ether;
  }


  function() public payable {
    require(!halted && now >= altICO_START_DATE && now < altICO_END_DATE);
    uint _assetVal = (msg.value * ratePerWei()) / 1 ether;
    altUnlb.create(msg.sender, _assetVal);
  }

  function foreignPurchase(address _altInvestor, uint _unlbMagnitude, string _altTxHash) external onlyAdministrator {
    require(!halted && now >= altICO_START_DATE && now < altICO_END_DATE);
    require(_unlbMagnitude > 0);
    altUnlb.create(_altInvestor, _unlbMagnitude);
    ForeignBuy(_altInvestor, _unlbMagnitude, _altTxHash);
  }
  
  function altFinish(address _crew, address _altFund, address _altBounty, address _altBackers) external onlyAdministrator {
    require(now >= altICO_END_DATE && !altIsFinished);
    altUnlb.resume();
    altIsFinished = true;

    uint _aggregate = altUnlb.aggregateIssuance() * 100 / (100 - 12 - 15 - 5 - 3);
    altUnlb.create(_crew,   (_aggregate * 12) / 100);
    altUnlb.create(_altFund,   (_aggregate * 15) / 100);
    altUnlb.create(_altBounty, (_aggregate *  5) / 100);
    altUnlb.create(_altBackers, (_aggregate *  3) / 100);
  }


  function cashOut() external onlyAdministrator {
    crewWallet.transfer(this.balance);
  }
}
