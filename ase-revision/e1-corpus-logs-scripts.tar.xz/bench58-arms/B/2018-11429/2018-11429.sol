pragma solidity ^0.4.11;

library GuardedMath {
  function scale(uint altA, uint altB) internal returns (uint) {
    uint altC = altA * altB;
    altAssert(altA == 0 || altC / altA == altB);
    return altC;
  }

  function partition(uint altA, uint altB) internal returns (uint) {
    altAssert(altB > 0);
    uint altC = altA / altB;
    altAssert(altA == altB * altC + altA % altB);
    return altC;
  }

  function deduct(uint altA, uint altB) internal returns (uint) {
    altAssert(altB <= altA);
    return altA - altB;
  }

  function append(uint altA, uint altB) internal returns (uint) {
    uint altC = altA + altB;
    altAssert(altC >= altA);
    return altC;
  }

  function altMax64(uint64 altA, uint64 altB) internal constant returns (uint64) {
    return altA >= altB ? altA : altB;
  }

  function altMin64(uint64 altA, uint64 altB) internal constant returns (uint64) {
    return altA < altB ? altA : altB;
  }

  function altMax256(uint256 altA, uint256 altB) internal constant returns (uint256) {
    return altA >= altB ? altA : altB;
  }

  function altMin256(uint256 altA, uint256 altB) internal constant returns (uint256) {
    return altA < altB ? altA : altB;
  }

  function altAssert(bool altAssertion) internal {
    if (!altAssertion) {
      throw;
    }
  }
}

contract ERC20Basic {
  uint public aggregateIssuance;
  function holdingsOf(address altWho) constant returns (uint);
  function send(address target, uint magnitude);
  event Transfer(address indexed origin, address indexed target, uint magnitude);
}

contract ERC20 is ERC20Basic {
  function permitted(address administrator, address delegate) constant returns (uint);
  function sendOrigin(address origin, address target, uint magnitude);
  function authorize(address delegate, uint magnitude);
  event Approval(address indexed administrator, address indexed delegate, uint magnitude);
}

contract BasicAsset is ERC20Basic {
  using GuardedMath for uint;

  mapping(address => uint) holdings;

  


  modifier altOnlyPayloadSize(uint altSize) {
     if(msg.data.length < altSize + 4) {
       throw;
     }
     _;
  }

  function send(address _target, uint _magnitude) altOnlyPayloadSize(2 * 32) {
    holdings[msg.sender] = holdings[msg.sender].deduct(_magnitude);
    holdings[_target] = holdings[_target].append(_magnitude);
    Transfer(msg.sender, _target, _magnitude);
  }

  function holdingsOf(address _administrator) constant returns (uint holdings2) {
    return holdings[_administrator];
  }
  
}

contract StandardAsset is BasicAsset, ERC20 {

  mapping (address => mapping (address => uint)) permitted2;

  function sendOrigin(address _origin, address _target, uint _magnitude) {
    var _permitted = permitted2[_origin][msg.sender];

    
    

    holdings[_target] = holdings[_target].append(_magnitude);
    holdings[_origin] = holdings[_origin].deduct(_magnitude);
    permitted2[_origin][msg.sender] = _permitted.deduct(_magnitude);
    Transfer(_origin, _target, _magnitude);
  }

  function authorize(address _delegate, uint _magnitude) {
    permitted2[msg.sender][_delegate] = _magnitude;
    Approval(msg.sender, _delegate, _magnitude);
  }

  function permitted(address _administrator, address _delegate) constant returns (uint altRemaining) {
    return permitted2[_administrator][_delegate];
  }

}

contract Aurora is StandardAsset {

  string public label = "ATLANT Token";
  string public ticker = "ATL";
  uint public precision = 18;
  uint constant altTOKEN_LIMIT = 150 * 1e6 * 1e18;

  address public altIco;

  bool public assetsAreLocked = true;

  function Aurora(address _altIco) {
    altIco = _altIco;
  }

  function create(address _altHolder, uint _magnitude) external {
    require(msg.sender == altIco);
    require(_magnitude != 0);
    require(aggregateIssuance + _magnitude <= altTOKEN_LIMIT);

    holdings[_altHolder] += _magnitude;
    aggregateIssuance += _magnitude;
    Transfer(0x0, _altHolder, _magnitude);
  }

  function unlock() external {
    require(msg.sender == altIco);
    assetsAreLocked = false;
  }

  function send(address _target, uint _magnitude) public {
    require(!assetsAreLocked);
    super.send(_target, _magnitude);
  }


  function sendOrigin(address _origin, address _target, uint _magnitude) public {
    require(!assetsAreLocked);
    super.sendOrigin(_origin, _target, _magnitude);
  }


  function authorize(address _delegate, uint _magnitude) public {
    require(!assetsAreLocked);
    super.authorize(_delegate, _magnitude);
  }
}
