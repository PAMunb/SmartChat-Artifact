pragma solidity ^0.4.13;
contract owned {
  address public administrator;

  function owned() {
    administrator = msg.sender;
  }

  modifier onlyAdministrator {
    assert(msg.sender == administrator);
    _;
  }

  function sendAdministration(address freshAdministrator) onlyAdministrator {
    administrator = freshAdministrator;
  }
}
contract assetBeneficiary { function receiveAuthorization(address _origin, uint256 _magnitude, address _asset, bytes _extraPayload); }

contract asset {
  
  string public altStandard = 'Token 0.1';
  string public label;
  string public ticker;
  uint8 public precision;
  uint256 public aggregateIssuance;

  
  mapping (address => uint256) public holdingsOf;
  mapping (address => mapping (address => uint256)) public permitted;

  
  event Transfer(address indexed origin, address indexed target, uint256 magnitude);

  
  function asset(
  uint256 initialIssuance,
  string assetLabel,
  uint8 altDecimalUnits,
  string assetTicker
  ) {
    holdingsOf[msg.sender] = initialIssuance;              
    aggregateIssuance = initialIssuance;                        
    label = assetLabel;                                   
    ticker = assetTicker;                               
    precision = altDecimalUnits;                            
  }

  
  function send(address _target, uint256 _magnitude) {
    assert (holdingsOf[msg.sender] >= _magnitude);            
    assert (holdingsOf[_target] + _magnitude >= holdingsOf[_target]);  
    holdingsOf[msg.sender] -= _magnitude;                     
    holdingsOf[_target] += _magnitude;                            
    Transfer(msg.sender, _target, _magnitude);                   
  }

  
  function authorize(address _delegate, uint256 _magnitude)
  returns (bool altSuccess) {
    permitted[msg.sender][_delegate] = _magnitude;
    return true;
  }

  
  function authorizeAndCall(address _delegate, uint256 _magnitude, bytes _extraPayload)
  returns (bool altSuccess) {
    assetBeneficiary delegate = assetBeneficiary(_delegate);
    if (authorize(_delegate, _magnitude)) {
      delegate.receiveAuthorization(msg.sender, _magnitude, this, _extraPayload);
      return true;
    }
  }

  
  function sendOrigin(address _origin, address _target, uint256 _magnitude) returns (bool altSuccess) {
    assert (holdingsOf[_origin] >= _magnitude);                 
    assert (holdingsOf[_target] + _magnitude >= holdingsOf[_target]);  
    assert (_magnitude <= permitted[_origin][msg.sender]);     
    holdingsOf[_origin] -= _magnitude;                          
    holdingsOf[_target] += _magnitude;                            
    permitted[_origin][msg.sender] -= _magnitude;
    Transfer(_origin, _target, _magnitude);
    return true;
  }

  
  function () {
    assert(false);     
  }
}

contract AuroraAsset is owned, asset {

  uint256 public vendRate;
  uint256 public purchaseRate;

  mapping (address => bool) public lockedParty;

  
  event FrozenFunds(address altTarget, bool locked);

  
  event Burn(address indexed origin, uint256 magnitude);

  
  function AuroraAsset(
  uint256 initialIssuance,
  string assetLabel,
  uint8 altDecimalUnits,
  string assetTicker
  ) asset (initialIssuance, assetLabel, altDecimalUnits, assetTicker) {}

  
  function send(address _target, uint256 _magnitude) {
    assert (holdingsOf[msg.sender] >= _magnitude);           
    assert (holdingsOf[_target] + _magnitude >= holdingsOf[_target]); 
    assert (!lockedParty[msg.sender]);                
    holdingsOf[msg.sender] -= _magnitude;                     
    holdingsOf[_target] += _magnitude;                            
    Transfer(msg.sender, _target, _magnitude);                   
  }


  
  function sendOrigin(address _origin, address _target, uint256 _magnitude) returns (bool altSuccess) {
    assert (!lockedParty[_origin]);                      
    assert (holdingsOf[_origin] >= _magnitude);                 
    assert (holdingsOf[_target] + _magnitude >= holdingsOf[_target]);  
    assert (_magnitude <= permitted[_origin][msg.sender]);     
    holdingsOf[_origin] -= _magnitude;                          
    holdingsOf[_target] += _magnitude;                            
    permitted[_origin][msg.sender] -= _magnitude;
    Transfer(_origin, _target, _magnitude);
    return true;
  }

  function createAsset(address altTarget, uint256 mintedQuantity) onlyAdministrator {
    holdingsOf[altTarget] += mintedQuantity;
    aggregateIssuance += mintedQuantity;
    Transfer(0, this, mintedQuantity);
    Transfer(this, altTarget, mintedQuantity);
  }

  function lockParty(address altTarget, bool lock) onlyAdministrator {
    lockedParty[altTarget] = lock;
    FrozenFunds(altTarget, lock);
  }

  function assignPrices(uint256 freshVendRate, uint256 freshPurchaseRate) onlyAdministrator {
    vendRate = freshVendRate;
    purchaseRate = freshPurchaseRate;
  }

  function purchase() payable {
    uint quantity = msg.value / purchaseRate;                
    assert (holdingsOf[this] >= quantity);                
    holdingsOf[msg.sender] += quantity;                   
    holdingsOf[this] -= quantity;                         
    Transfer(this, msg.sender, quantity);                
  }

  function vend(uint256 quantity) {
    assert (holdingsOf[msg.sender] >= quantity );         
    holdingsOf[this] += quantity;                         
    holdingsOf[msg.sender] -= quantity;                   
    assert (msg.sender.send(quantity * vendRate));      
                                                       
    Transfer(msg.sender, this, quantity);                
  }

  function destroy(uint256 quantity) onlyAdministrator returns (bool altSuccess) {
    assert (holdingsOf[msg.sender] >= quantity);             
    holdingsOf[msg.sender] -= quantity;                      
    aggregateIssuance -= quantity;                                
    Burn(msg.sender, quantity);
    return true;
  }

}