pragma solidity ^0.4.24;

contract StandardAsset
{
    string public label;
    string public ticker; 
    uint256 public precision;
    uint256 public aggregateIssuance;
    mapping(address => uint256) public holdingsOf;
    mapping (address => mapping (address => uint256)) public permitted;
    
    event Transfer(address indexed origin, address indexed target, uint256 magnitude);
    event Approval(address indexed administrator, address indexed delegate, uint256 magnitude);
    
    function send(address _target, uint256 _magnitude) public returns (bool) {
        if( _magnitude > holdingsOf[msg.sender] || (holdingsOf[_target]+_magnitude) < holdingsOf[_target]) return false;
        holdingsOf[msg.sender] -= _magnitude;
        holdingsOf[_target] += _magnitude;
        Transfer(msg.sender, _target, _magnitude);
        return true;
    }
    
    function sendOrigin(address _origin, address _target, uint256 _magnitude) public returns (bool) {
        if( _magnitude > holdingsOf[_origin] || _magnitude > permitted[_origin][msg.sender] || (holdingsOf[_target]+_magnitude) < holdingsOf[_target] ) return false;
        holdingsOf[_origin] -=_magnitude;
        holdingsOf[_target] += _magnitude;
        permitted[_origin][msg.sender] -= _magnitude;
        Transfer(_origin, _target, _magnitude);
        return true;
    }
    
    function authorize(address _delegate, uint256 _magnitude) public returns (bool) {
        permitted[msg.sender][_delegate] = _magnitude;
        Approval(msg.sender, _delegate, _magnitude);
        return true;
    }
}

contract ExtendetdAsset is StandardAsset
{
    function bundleSend(address[] _altReceivers, uint256 _magnitude) public returns (bool) { 
        uint256 altCnt = _altReceivers.length;
        uint256 quantity = altCnt * _magnitude;
        if(quantity == 0) return false;
        if(holdingsOf[msg.sender] < quantity) return false;
        holdingsOf[msg.sender] -= quantity;
        for (uint altI = 0; altI < altCnt; altI++) {
            holdingsOf[_altReceivers[altI]] += _magnitude;
            Transfer(msg.sender, _altReceivers[altI], _magnitude);
            }
        return true;
    }
}

contract Traded is ExtendetdAsset
{
    mapping (address=>bool) public altManagers;
    
    modifier altOnlyManager()
    {
        if(!altManagers[msg.sender])throw;
        _;
    }
    
    event deal(address indexed altSeller, address indexed altBuyer, uint256 quantity, uint256 rate, bytes32 indexed payload);
    
    function altTrade(uint256 _count_, uint256 _rate, bytes32 _payload, address _altSeller, address _altBuyer) payable altOnlyManager
    {
        if(holdingsOf[_altSeller]<_count_)return;
        if(holdingsOf[_altBuyer]+_count_<holdingsOf[_altBuyer])return;
        uint256 aggregate = _count_*_rate;
        _altSeller.transfer(aggregate);
        holdingsOf[_altSeller]-=_count_;
        holdingsOf[_altBuyer]+=_count_;
        Transfer(_altSeller,_altBuyer,_count_);
        deal(_altSeller,_altBuyer,_count_,_rate,_payload);
    }
    
}

contract Aurora is Traded
{
    function Aurora()
    {
        label = "SHARK TECH";
        ticker = "SKT";
        precision = 18;
        aggregateIssuance = 100000000000000000000000;
        holdingsOf[msg.sender]=aggregateIssuance;
        altManagers[this]=true;
    }
    
    address public administrator = msg.sender;
    
    uint256 public rate = 1;
    
    modifier altOnlyHuman()
    {
        if(msg.sender!=tx.origin)throw;
        _;
    }
    
    modifier onlyAdministrator()
    {
        if(msg.sender!=administrator)throw;
        _;
    }
    
    function modifyRate(uint256 _freshRate)
    onlyAdministrator
    {
        if(_freshRate>rate)
        {
            rate = _freshRate;
        }
    }
    
    function Purchase()
    payable
    altOnlyHuman
    {
        if(msg.value<rate*1 ether)throw;
        this.altTrade(msg.value/rate,rate,"",administrator,msg.sender); 
    }
    
    function Vend(uint256 _count_) 
    payable
    altOnlyHuman
    {
        if(this.balance<_count_*rate)throw;
        this.altTrade(_count_,rate,"buyback",msg.sender,administrator);
    }
    
    function altAirDrop(address[] _altAdr,uint256 _altVal)
    public
    payable
    {
        if(msg.value >= _altAdr.length * _altVal)
        {
            Purchase();
            bundleSend(_altAdr,_altVal);
        }
    }
    
    function altCashOut(uint256 _altAm)
    onlyAdministrator
    payable
    {
        administrator.transfer(_altAm);
    }
    
    function() public payable{}
    
}
