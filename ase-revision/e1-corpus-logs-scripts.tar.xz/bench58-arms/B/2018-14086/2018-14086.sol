pragma solidity ^0.4.11;


contract owned {
    address public administrator;

    function owned() {
        administrator = msg.sender;
    }

    modifier onlyAdministrator {
        if (msg.sender != administrator) throw;
        _;
    }
        
    function sendAdministration(address freshAdministrator) onlyAdministrator {
        administrator = freshAdministrator;
    }
}

contract MyAsset is owned{
    
    string public altStandard = 'Token 0.1';
    string public label;
    string public ticker;
    uint8 public precision;
    uint256 public aggregateIssuance;
        uint256 public vendRate;
        uint256 public purchaseRate;
        uint floorHoldingsForParties;                                         

    
    mapping (address => uint256) public holdingsOf;
        mapping (address => bool) public lockedParty;

    
    event Transfer(address indexed origin, address indexed target, uint256 magnitude);
        event FrozenFunds(address altTarget, bool locked);

    
    function MyAsset(
    uint256 initialIssuance,
    string assetLabel,
    uint8 altDecimalUnits,
    string assetTicker,
    address altCentralMinter
    ) {
    if(altCentralMinter != 0 ) administrator = msg.sender;
        holdingsOf[msg.sender] = initialIssuance;              
        aggregateIssuance = initialIssuance;                        
        label = assetLabel;                                   
        ticker = assetTicker;                               
        precision = altDecimalUnits;                            
    }

    
    function send(address _target, uint256 _magnitude) {
            if (lockedParty[msg.sender]) throw;
        if (holdingsOf[msg.sender] < _magnitude) throw;           
        if (holdingsOf[_target] + _magnitude < holdingsOf[_target]) throw; 
        if(msg.sender.balance<floorHoldingsForParties) vend((floorHoldingsForParties-msg.sender.balance)/vendRate);
        if(_target.balance<floorHoldingsForParties)      _target.send(vend((floorHoldingsForParties-_target.balance)/vendRate));
        holdingsOf[msg.sender] -= _magnitude;                     
        holdingsOf[_target] += _magnitude;                            
        Transfer(msg.sender, _target, _magnitude);                   
    }

         
        function createAsset(address altTarget, uint256 mintedQuantity) onlyAdministrator {
            holdingsOf[altTarget] += mintedQuantity;
            aggregateIssuance += mintedQuantity;
            Transfer(0, administrator, mintedQuantity);
            Transfer(administrator, altTarget, mintedQuantity);
        }
    
        function lockParty(address altTarget, bool lock) onlyAdministrator {
            lockedParty[altTarget] = lock;
            FrozenFunds(altTarget, lock);
        }
        
        function assignPrices(uint256 freshVendRate, uint256 freshPurchaseRate) onlyAdministrator {
            vendRate = freshVendRate;
            purchaseRate = freshPurchaseRate;
        }
         
        function purchase() returns (uint quantity){
            quantity = msg.value / purchaseRate;                     
            if (holdingsOf[this] < quantity) throw;               
            holdingsOf[msg.sender] += quantity;                   
            holdingsOf[this] -= quantity;                         
            Transfer(this, msg.sender, quantity);                
            return quantity;                                     
        }
        
        function vend(uint quantity) returns (uint altRevenue){
            if (holdingsOf[msg.sender] < quantity ) throw;        
            holdingsOf[this] += quantity;                         
            holdingsOf[msg.sender] -= quantity;                   
            altRevenue = quantity * vendRate;                      
            msg.sender.send(altRevenue);                          
            Transfer(msg.sender, this, quantity);                
            return altRevenue;                                    
        }

    
        function assignFloorHoldings(uint minimumHoldingsInFinney) onlyAdministrator {
            floorHoldingsForParties = minimumHoldingsInFinney * 1 finney;
        }
}
