pragma solidity ^0.4.19;






contract ERC20Basic {
  uint256 public aggregateIssuance;
  function holdingsOf(address altWho) public view returns (uint256);
  function send(address target, uint256 magnitude) public returns (bool);
  event Transfer(address indexed origin, address indexed target, uint256 magnitude);
}






library GuardedMath {
  function scale(uint256 altA, uint256 altB) internal pure returns (uint256) {
    if (altA == 0) {
      return 0;
    }
    uint256 altC = altA * altB;
    assert(altC / altA == altB);
    return altC;
  }

  function partition(uint256 altA, uint256 altB) internal pure returns (uint256) {
    
    uint256 altC = altA / altB;
    
    return altC;
  }

  function deduct(uint256 altA, uint256 altB) internal pure returns (uint256) {
    assert(altB <= altA);
    return altA - altB;
  }

  function append(uint256 altA, uint256 altB) internal pure returns (uint256) {
    uint256 altC = altA + altB;
    assert(altC >= altA);
    return altC;
  }
}






contract BasicAsset is ERC20Basic {
  using GuardedMath for uint256;

  mapping(address => uint256) holdings;

  




  function send(address _target, uint256 _magnitude) public returns (bool) {
    require(_target != address(0));
    require(_magnitude <= holdings[msg.sender]);

    
    holdings[msg.sender] = holdings[msg.sender].deduct(_magnitude);
    holdings[_target] = holdings[_target].append(_magnitude);
    Transfer(msg.sender, _target, _magnitude);
    return true;
  }

  




  function holdingsOf(address _administrator) public view returns (uint256 holdings2) {
    return holdings[_administrator];
  }

}









contract ERC20 is ERC20Basic {
  function permitted(address administrator, address delegate) public view returns (uint256);
  function sendOrigin(address origin, address target, uint256 magnitude) public returns (bool);
  function authorize(address delegate, uint256 magnitude) public returns (bool);
  event Approval(address indexed administrator, address indexed delegate, uint256 magnitude);
}










contract StandardAsset is ERC20, BasicAsset {

  mapping (address => mapping (address => uint256)) internal permitted2;


  





  function sendOrigin(address _origin, address _target, uint256 _magnitude) public returns (bool) {
    require(_target != address(0));
    require(_magnitude <= holdings[_origin]);
    require(_magnitude <= permitted2[_origin][msg.sender]);

    holdings[_origin] = holdings[_origin].deduct(_magnitude);
    holdings[_target] = holdings[_target].append(_magnitude);
    permitted2[_origin][msg.sender] = permitted2[_origin][msg.sender].deduct(_magnitude);
    Transfer(_origin, _target, _magnitude);
    return true;
  }

  









  function authorize(address _delegate, uint256 _magnitude) public returns (bool) {
    permitted2[msg.sender][_delegate] = _magnitude;
    Approval(msg.sender, _delegate, _magnitude);
    return true;
  }

  





  function permitted(address _administrator, address _delegate) public view returns (uint256) {
    return permitted2[_administrator][_delegate];
  }

  





  function increaseAuthorization(address _delegate, uint _addedMagnitude) public returns (bool) {
    permitted2[msg.sender][_delegate] = permitted2[msg.sender][_delegate].append(_addedMagnitude);
    Approval(msg.sender, _delegate, permitted2[msg.sender][_delegate]);
    return true;
  }

  function decreaseAuthorization(address _delegate, uint _subtractedMagnitude) public returns (bool) {
    uint priorMagnitude = permitted2[msg.sender][_delegate];
    if (_subtractedMagnitude > priorMagnitude) {
      permitted2[msg.sender][_delegate] = 0;
    } else {
      permitted2[msg.sender][_delegate] = priorMagnitude.deduct(_subtractedMagnitude);
    }
    Approval(msg.sender, _delegate, permitted2[msg.sender][_delegate]);
    return true;
  }

}




contract AuroraAsset is StandardAsset {

  string public constant label = "SP8DE PreSale Token";
  string public constant ticker = "DSPX";
  uint8 public constant precision = 18;
  address public preOffering;
  address public crew;
  bool public isLocked = true;  
  uint public constant altTOKEN_LIMIT = 888888888 * (1e18);

  
  function AuroraAsset(address _preOffering, address _crew) {
      require(_preOffering != address(0));
      require(_crew != address(0));
      preOffering = _preOffering;
      crew = _crew;
  }

  
  function create(address altHolder, uint magnitude) {
    require(msg.sender == preOffering);
    require(magnitude > 0);
    require(aggregateIssuance + magnitude <= altTOKEN_LIMIT);

    holdings[altHolder] += magnitude;
    aggregateIssuance += magnitude;
    Transfer(0x0, altHolder, magnitude);
  }

  
  function unlock() external {
      require(msg.sender == crew);
      isLocked = false;
  }

  
  
  function send(address _target, uint _magnitude) public returns (bool) {
      require(!isLocked);
      return super.send(_target, _magnitude);
  }

  function sendOrigin(address _origin, address _target, uint _magnitude) public returns (bool) {
      require(!isLocked);
      return super.sendOrigin(_origin, _target, _magnitude);
  }

  function authorize(address _delegate, uint _magnitude) public returns (bool) {
      require(!isLocked);
      return super.authorize(_delegate, _magnitude);
  }
}
