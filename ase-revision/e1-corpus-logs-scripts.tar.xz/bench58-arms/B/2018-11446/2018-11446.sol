pragma solidity ^0.4.13;
contract owned {
    address public administrator;
    mapping (address =>  bool) public altAdmins;

    function owned() {
        administrator = msg.sender;
        altAdmins[msg.sender]=true;
    }

    modifier onlyAdministrator {
        require(msg.sender == administrator);
        _;
    }

    modifier onlySteward   {
        require(altAdmins[msg.sender] == true);
        _;
    }

    function sendAdministration(address freshAdministrator) onlyAdministrator {
        administrator = freshAdministrator;
    }
    function makeSteward(address freshSteward, bool isSteward) onlyAdministrator {
        altAdmins[freshSteward] = isSteward;
    }
}

interface assetBeneficiary {
    function receiveAuthorization(address _origin, uint256 _magnitude, address _asset, bytes _extraPayload);
}

contract Aurora is owned {
    
    string public label;
    string public ticker;
    uint8 public precision;
    uint256 public aggregateIssuance;
    uint256 floorHoldingsForParties;
    bool public participantsCanTrade;
    bool public participantsCanUnlock;

    bool public altIco = true; 
    mapping (address => bool) public steward;


    modifier altNotICO {
        require(steward[msg.sender] || !altIco);
        _;
    }


    
    mapping (address => uint256) public holdingsOf;


    mapping (address => mapping (address => uint256)) public permitted;
    mapping (address =>  bool) public locked;

    mapping (address =>  bool) public altCanTrade; 

    
    event Transfer(address indexed origin, address indexed target, uint256 magnitude);

    
    event Reward(address origin, address target, uint256 magnitude, string payload, uint256 instant);

    
    event Burn(address indexed origin, uint256 magnitude);

    
    event Frozen(address indexed location, bool locked);

    
    event Unlock(address indexed location, address origin, uint256 altVal);

    


    
    

    




    function Aurora() {
        uint256 initialIssuance = 20000000000000000000000000;
        holdingsOf[msg.sender] = initialIssuance ;              
        aggregateIssuance = initialIssuance;                        
        label = "Gold Reward Token";                                   
        ticker = "GRX";                               
        precision = 18;                            
        floorHoldingsForParties = 1000000000000000;
        participantsCanTrade=false;
        participantsCanUnlock=false;
        steward[msg.sender]=true;
        altCanTrade[msg.sender]=true;

    }

    




    function increaseAggregateIssuance (address altTarget,  uint256 altIncreaseBy )  onlyAdministrator {
        holdingsOf[altTarget] += altIncreaseBy;
        aggregateIssuance += altIncreaseBy;
        Transfer(0, administrator, altIncreaseBy);
        Transfer(administrator, altTarget, altIncreaseBy);
    }

    function  participantsCanUnLock(bool altCan) {
        participantsCanUnlock=altCan;
    }

    function assignFloorHoldings(uint minimumHoldingsInWei) onlyAdministrator {
        floorHoldingsForParties = minimumHoldingsInWei;
    }

    




    function sendAndLock (address altTarget,  uint256 quantity )  onlySteward {
        _send(msg.sender, altTarget, quantity);
        lock(altTarget, true);
    }

    




    function _lock (address altTarget, bool altFroze )  internal  {

        locked[altTarget]=altFroze;
        Frozen(altTarget, altFroze);
    }



    




    function lock (address altTarget, bool altFroze )   {
        if(altFroze || (!altFroze && !participantsCanUnlock)) {
            require(steward[msg.sender]);
        }

        _lock(altTarget, altFroze);
    }



    


    function _send(address _origin, address _target, uint _magnitude) internal {
        require(_target != 0x0);                                   

        require(!locked[_origin]);                       
        require(holdingsOf[_origin] >= _magnitude);                
        require(holdingsOf[_target] + _magnitude > holdingsOf[_target]); 
        holdingsOf[_origin] -= _magnitude;                         
        holdingsOf[_target] += _magnitude;                           
        Transfer(_origin, _target, _magnitude);
    }

    







    function send(address _target, uint256 _magnitude) altNotICO {
        require(!locked[msg.sender]);                       
        if (msg.sender.balance  < floorHoldingsForParties) {
            vend((floorHoldingsForParties - msg.sender.balance) * vendRate);
        }
        _send(msg.sender, _target, _magnitude);
    }



    mapping (address => uint256) public aggregateLockedRewardsOf;
    mapping (address => mapping (address => uint256)) public altLockedRewardsOf; 
    mapping (address => mapping (uint32  => address)) public participantRewarders; 
    mapping (address => mapping (address => uint32)) public participantBountyTally; 
    mapping (address => uint32) public participantRewarderTally; 

    
    mapping (address =>  uint256  ) public aggregateBountyIssuedOut;

    







    function bounty(address _target, uint256 _magnitude, bool altLocked, string payload) {
        require(_target != 0x0);
        require(!locked[msg.sender]);                       
        if (msg.sender.balance  < floorHoldingsForParties) {
            vend((floorHoldingsForParties - msg.sender.balance) * vendRate);
        }
        if(!altLocked) {
            _send(msg.sender, _target, _magnitude);
        }else{
            
            require(holdingsOf[msg.sender] >= _magnitude);                
            require(aggregateLockedRewardsOf[_target] + _magnitude > aggregateLockedRewardsOf[_target]); 
            holdingsOf[msg.sender] -= _magnitude;                         
            aggregateLockedRewardsOf[_target] += _magnitude;                           
            altLockedRewardsOf[_target][msg.sender] += _magnitude;
            if(participantBountyTally[_target][msg.sender]==0) {
                participantRewarderTally[_target] += 1;
                participantRewarders[_target][participantRewarderTally[_target]]=msg.sender;
            }
            participantBountyTally[_target][msg.sender]+=1;
            aggregateBountyIssuedOut[msg.sender]+= _magnitude;
            Transfer(msg.sender, _target, _magnitude);
        }

        Reward(msg.sender, _target, _magnitude, payload, now);
    }

    







    function sendBounty(address _target, uint256 _magnitude) {
        require(!locked[msg.sender]);                       
        require(altLockedRewardsOf[msg.sender][_target] >= _magnitude );
        require(aggregateLockedRewardsOf[msg.sender] >= _magnitude);

        if (msg.sender.balance  < floorHoldingsForParties) {
            vend((floorHoldingsForParties - msg.sender.balance) * vendRate);
        }
        aggregateLockedRewardsOf[msg.sender] -= _magnitude;                           
        altLockedRewardsOf[msg.sender][_target] -= _magnitude;
        holdingsOf[_target] += _magnitude;
        Transfer(msg.sender, _target, _magnitude);
    }

    







    function unsealBounty(address location, uint256 _magnitude) {
        require(aggregateLockedRewardsOf[location] > _magnitude);                       
        require(altLockedRewardsOf[location][msg.sender] >= _magnitude );
        if(_magnitude==0) _magnitude=altLockedRewardsOf[location][msg.sender];
        if (msg.sender.balance  < floorHoldingsForParties) {
            vend((floorHoldingsForParties - msg.sender.balance) * vendRate);
        }
        aggregateLockedRewardsOf[location] -= _magnitude;                           
        altLockedRewardsOf[location][msg.sender] -= _magnitude;
        holdingsOf[location] += _magnitude;
        Unlock(location, msg.sender, _magnitude);
    }



    








    function sendOrigin(address _origin, address _target, uint256 _magnitude) returns (bool altSuccess) {
        require(!locked[_origin]);                       
        require(_magnitude <= permitted[_origin][msg.sender]);     
        permitted[_origin][msg.sender] -= _magnitude;
        _send(_origin, _target, _magnitude);
        return true;
    }

    







    function authorize(address _delegate, uint256 _magnitude)
    returns (bool altSuccess) {
        permitted[msg.sender][_delegate] = _magnitude;
        return true;
    }

    








    function authorizeAndCall(address _delegate, uint256 _magnitude, bytes _extraPayload) onlyAdministrator
    returns (bool altSuccess) {
        assetBeneficiary delegate = assetBeneficiary(_delegate);
        if (authorize(_delegate, _magnitude)) {
            delegate.receiveAuthorization(msg.sender, _magnitude, this, _extraPayload);
            return true;
        }
    }

    






    function destroy(uint256 _magnitude) onlyAdministrator returns (bool altSuccess) {
        require(holdingsOf[msg.sender] >= _magnitude);   
        holdingsOf[msg.sender] -= _magnitude;            
        aggregateIssuance -= _magnitude;                      
        Burn(msg.sender, _magnitude);
        return true;
    }

    







    function destroyOrigin(address _origin, uint256 _magnitude)  returns (bool altSuccess) {
        require(holdingsOf[_origin] >= _magnitude);                
        require(_magnitude <= permitted[_origin][msg.sender]);    
        holdingsOf[_origin] -= _magnitude;                         
        permitted[_origin][msg.sender] -= _magnitude;             
        aggregateIssuance -= _magnitude;                              
        Burn(_origin, _magnitude);
        return true;
    }

    











    uint256 public vendRate = 608;
    uint256 public purchaseRate = 760;

    function assignPrices(uint256 freshVendRate, uint256 freshPurchaseRate) onlyAdministrator {
        vendRate = freshVendRate;
        purchaseRate = freshPurchaseRate;
    }
    function assignParticipantsCanTrade(bool altTrade) onlyAdministrator {
        participantsCanTrade=altTrade;
    }
    function assignCanTrade(address location, bool altTrade) onlyAdministrator {
        altCanTrade[location]=altTrade;
    }

    
    function purchase() payable returns (uint256 quantity){
        if(!participantsCanTrade && !altCanTrade[msg.sender]) revert();
        quantity = msg.value * purchaseRate;                    

        require(holdingsOf[this] >= quantity);               
        holdingsOf[msg.sender] += quantity;                  
        holdingsOf[this] -= quantity;                        
        Transfer(this, msg.sender, quantity);               
        return quantity;                                    
    }

    
    function vend(uint256 quantity) returns (uint altRevenue){
        require(!locked[msg.sender]);
        if(!participantsCanTrade && !altCanTrade[msg.sender]) {
            require(floorHoldingsForParties > quantity/vendRate);
        }
        require(holdingsOf[msg.sender] >= quantity);         
        holdingsOf[this] += quantity;                        
        holdingsOf[msg.sender] -= quantity;                  
        altRevenue = quantity / vendRate;
        require(msg.sender.send(altRevenue));                
        Transfer(msg.sender, this, quantity);               
        return altRevenue;                                   
    }

    function() payable {
    }
    event Withdrawn(address indexed target, uint256 magnitude);
    function cashOut(address altTarget, uint256 quantity) onlyAdministrator {
        altTarget.transfer(quantity);
        Withdrawn(altTarget, quantity);
    }

    function assignSteward(address location, bool active) onlyAdministrator {
        steward[location]=active;
    }

    function assignICO(bool active) onlyAdministrator {
        altIco=active;
    }
}