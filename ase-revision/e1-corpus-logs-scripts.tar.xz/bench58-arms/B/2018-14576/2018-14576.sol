
   


pragma solidity ^0.4.21;
contract owned {

  address public administrator;

  function owned() {
    administrator = msg.sender;
  }

  modifier onlyAdministrator {
    if (msg.sender != administrator) throw;
    _;
  }

  function sendAdministration(address freshAdministrator) onlyAdministrator {
    administrator = freshAdministrator;
  }
}

contract assetBeneficiary { 
  function receiveAuthorization(address _origin, uint256 _magnitude, address _asset, bytes _extraPayload);
} 

contract AuroraAsset {

  
  function aggregateIssuance() constant returns (uint256 aggregateIssuance);

  
  
  function holdingsOf(address _administrator) constant returns (uint256 holdings) {}

  
  
  
  
  function send(address _target, uint256 _magnitude) returns (bool altSuccess) {}

  
  
  
  
  
  function sendOrigin(address _origin, address _target, uint256 _magnitude) returns (bool altSuccess) {}

  
  
  
  
  function authorize(address _delegate, uint256 _magnitude) returns (bool altSuccess) {}

  
  
  
  function permitted(address _administrator, address _delegate) constant returns (uint256 altRemaining) {}

  event Transfer(address indexed _origin, address indexed _target, uint256 _magnitude);
  event Approval(address indexed _administrator, address indexed _delegate, uint256 _magnitude);
} 

contract MeridianCobaltAsset is AuroraAsset, owned{

  
  string public altStandard = "SunContract token v1.0";
  string public label = "SunContract";
  string public ticker = "SNC";
  uint8 public precision = 18;
  address public icoContractLocation;
  uint256 public assetLockedUntilBlock;

  
  uint256 issuance = 0;
  mapping (address => uint256) holdings2;
  mapping (address => mapping (address => uint256)) altAllowances;
  mapping (address => bool) altRestrictedAddresses;

  
  event Mint(address indexed _target, uint256 _magnitude);
  event Burn(address indexed _origin, uint256 _magnitude);
  event TokenFrozen(uint256 _lockedUntilBlock, string _altReason);

  
  function MeridianCobaltAsset(address _icoLocation) {
    altRestrictedAddresses[0x0] = true;
    altRestrictedAddresses[_icoLocation] = true;
    altRestrictedAddresses[address(this)] = true;
    icoContractLocation = _icoLocation;
  }

  
  function aggregateIssuance() constant returns (uint256 aggregateIssuance) {
    return issuance;
  }

  
  function holdingsOf(address _administrator) constant returns (uint256 holdings) {
    return holdings2[_administrator];
  }

  
  function send(address _target, uint256 _magnitude) returns (bool altSuccess) {
    if (block.number < assetLockedUntilBlock) throw;    
    if (altRestrictedAddresses[_target]) throw;                
    if (holdings2[msg.sender] < _magnitude) throw;           
    if (holdings2[_target] + _magnitude < holdings2[_target]) throw;  
    holdings2[msg.sender] -= _magnitude;                     
    holdings2[_target] += _magnitude;                            
    Transfer(msg.sender, _target, _magnitude);                  
    return true;
  }

  
  function authorize(address _delegate, uint256 _magnitude) returns (bool altSuccess) {
    if (block.number < assetLockedUntilBlock) throw;    
    altAllowances[msg.sender][_delegate] = _magnitude;          
    Approval(msg.sender, _delegate, _magnitude);             
    return true;
  }

   
  function authorizeAndCall(address _delegate, uint256 _magnitude, bytes _extraPayload) returns (bool altSuccess) {            
    assetBeneficiary delegate = assetBeneficiary(_delegate);              
    authorize(_delegate, _magnitude);                                      
    delegate.receiveAuthorization(msg.sender, _magnitude, this, _extraPayload);  
    return true;     
  }     

  
  function sendOrigin(address _origin, address _target, uint256 _magnitude) returns (bool altSuccess) {      
    if (block.number < assetLockedUntilBlock) throw;    
    if (altRestrictedAddresses[_target]) throw;                
    if (holdings2[_origin] < _magnitude) throw;                
    if (holdings2[_target] + _magnitude < holdings2[_target]) throw;  
    if (_magnitude > altAllowances[_origin][msg.sender]) throw;  
    holdings2[_origin] -= _magnitude;                          
    holdings2[_target] += _magnitude;                            
    altAllowances[_origin][msg.sender] -= _magnitude;            
    Transfer(_origin, _target, _magnitude);                       
    return true;     
  }         

       
  function permitted(address _administrator, address _delegate) constant returns (uint256 altRemaining) {         
    return altAllowances[_administrator][_delegate];
  }         

       
  function createAssets(address _target, uint256 _quantity) {         
    if (msg.sender != icoContractLocation) throw;            
    if (altRestrictedAddresses[_target]) throw;                    
    if (holdings2[_target] + _quantity < holdings2[_target]) throw;     
    issuance += _quantity;                                      
    holdings2[_target] += _quantity;                               
    Mint(_target, _quantity);                                     
    Transfer(0x0, _target, _quantity);                            
  }     
  
  
  function destroyAssets(uint256 _quantity) onlyAdministrator {
    if(holdings2[msg.sender] < _quantity) throw;               
    if(issuance < _quantity) throw;                             

    issuance -= _quantity;                                      
    holdings2[msg.sender] -= _quantity;                        
    Burn(msg.sender, _quantity);                              
    Transfer(msg.sender, 0x0, _quantity);                     
  }

  
  function lockSendsUntil(uint256 _lockedUntilBlock, string _altReason) onlyAdministrator {      
    assetLockedUntilBlock = _lockedUntilBlock;
    TokenFrozen(_lockedUntilBlock, _altReason);
  }

  function isRestrictedLocation(address _querryLocation) constant returns (bool altAnswer){
    return altRestrictedAddresses[_querryLocation];
  }

  
  
  

  
  
  
  

  
  
  
}
