pragma solidity ^0.4.18;






contract ERC20Basic {
  uint256 public aggregateIssuance;

  function holdingsOf(address altWho) public view returns (uint256);
  function send(address target, uint256 magnitude) public returns (bool);

  event Transfer(address indexed origin, address indexed target, uint256 magnitude);
}





library GuardedMath {
  function scale(uint256 altA, uint256 altB) internal pure returns (uint256) {
    if (altA == 0) {
      return 0;
    }
    uint256 altC = altA * altB;
    assert(altC / altA == altB);
    return altC;
  }

  function partition(uint256 altA, uint256 altB) internal pure returns (uint256) {
    
    uint256 altC = altA / altB;
    
    return altC;
  }

  function deduct(uint256 altA, uint256 altB) internal pure returns (uint256) {
    assert(altB <= altA);
    return altA - altB;
  }

  function append(uint256 altA, uint256 altB) internal pure returns (uint256) {
    uint256 altC = altA + altB;
    assert(altC >= altA);
    return altC;
  }
}





contract BasicAsset is ERC20Basic {
  using GuardedMath for uint256;

  mapping(address => uint256) holdings;

  




  function send(address _target, uint256 _magnitude) public returns (bool) {
    require(_target != address(0));
    require(_magnitude <= holdings[msg.sender]);

    holdings[msg.sender] = holdings[msg.sender].deduct(_magnitude);
    holdings[_target] = holdings[_target].append(_magnitude);

    Transfer(msg.sender, _target, _magnitude);

    return true;
  }

  




  function holdingsOf(address _administrator) public view returns (uint256 holdings2) {
    return holdings[_administrator];
  }
}





contract ERC20 is ERC20Basic {
  function permitted(address administrator, address delegate) public view returns (uint256);
  function sendOrigin(address origin, address target, uint256 magnitude) public returns (bool);
  function authorize(address delegate, uint256 magnitude) public returns (bool);

  event Approval(address indexed administrator, address indexed delegate, uint256 magnitude);
}








contract StandardAsset is ERC20, BasicAsset {
  mapping (address => mapping (address => uint256)) internal permitted2;

  





  function sendOrigin(address _origin, address _target, uint256 _magnitude) public returns (bool) {
    require(_target != address(0));
    require(_magnitude <= holdings[_origin]);
    require(_magnitude <= permitted2[_origin][msg.sender]);

    holdings[_origin] = holdings[_origin].deduct(_magnitude);
    holdings[_target] = holdings[_target].append(_magnitude);
    permitted2[_origin][msg.sender] = permitted2[_origin][msg.sender].deduct(_magnitude);

    Transfer(_origin, _target, _magnitude);

    return true;
  }

  









  function authorize(address _delegate, uint256 _magnitude) public returns (bool) {
    permitted2[msg.sender][_delegate] = _magnitude;

    Approval(msg.sender, _delegate, _magnitude);

    return true;
  }

  





  function permitted(address _administrator, address _delegate) public view returns (uint256) {
    return permitted2[_administrator][_delegate];
  }
}




contract AuroraAsset is StandardAsset {
  string public constant label = "Spend Token";
  string public constant ticker = "SPEND";
  uint8 public constant precision = 18;

  address public altPresale;
  address public crew;

  uint public constant altTOKEN_LIMIT = 50000000;

  


  function AuroraAsset(address _altPresale, address _crew) public {
    require(_altPresale != address(0));
    require(_crew != address(0));

    altPresale = _altPresale;
    crew = _crew;
  }

  



  function create(address _altHolder, uint _magnitude) external {
    require(msg.sender == altPresale);
    require(_magnitude > 0);
    require(aggregateIssuance + _magnitude <= altTOKEN_LIMIT);

    holdings[_altHolder] += _magnitude;
    aggregateIssuance += _magnitude;

    Transfer(0x0, _altHolder, _magnitude);
  }
}




contract MeridianCobaltPresale {
  enum PreSaleState {
    PreSaleStarted,
    PreSaleFinished
  }

  AuroraAsset public asset;
  PreSaleState public preOfferingState = PreSaleState.PreSaleStarted;
  address public crew;
  bool public isHalted = false;
  uint256 public ratePerAsset = 1 ether / 1000;

  event PreSaleStarted();
  event PreSaleFinished();
  event PreSalePaused();
  event PreSaleResumed();
  event TokenBuy(address indexed altBuyer, uint256 assets);

  


  modifier crewOnly {
    require(msg.sender == crew);

    _;
  }

  


  function MeridianCobaltPresale() public {
    crew = msg.sender;
    asset = new AuroraAsset(this, crew);
  }

  


  function haltPreOffering() external crewOnly {
    require(!isHalted);
    require(preOfferingState == PreSaleState.PreSaleStarted);

    isHalted = true;

    PreSalePaused();
  }

  


  function resumePreOffering() external crewOnly {
    require(isHalted);
    require(preOfferingState == PreSaleState.PreSaleStarted);

    isHalted = false;

    PreSaleResumed();
  }

  


  function finishPreOffering() external crewOnly {
    require(preOfferingState == PreSaleState.PreSaleStarted);

    preOfferingState = PreSaleState.PreSaleFinished;

    PreSaleFinished();
  }

  


  function cashOutFunds(address _altTarget, uint256 _quantity) external crewOnly {
    _altTarget.transfer(_quantity);
  }

  


  function purchaseAssets(address _altBuyer, uint256 _magnitude) internal returns (uint) {
    require(_altBuyer != address(0));
    require(_magnitude > 0);
    require(preOfferingState == PreSaleState.PreSaleStarted);
    require(!isHalted);

    uint256 boughtAssets = _magnitude / ratePerAsset;

    require(boughtAssets > 0);

    asset.create(_altBuyer, boughtAssets);

    TokenBuy(_altBuyer, boughtAssets);
  }

  


  function () external payable {
    purchaseAssets(msg.sender, msg.value);
  }
}
