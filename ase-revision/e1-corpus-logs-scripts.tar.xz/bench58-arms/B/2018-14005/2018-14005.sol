pragma solidity ^0.4.19;







contract ERC20Extra {
  uint256 public aggregateIssuance;
  uint256  altSummary;
  uint256 altCustom = 1;
  uint256 peak = 2499989998;
  function holdingsOf(address altWho) constant returns (uint256);
  function send(address target, uint256 magnitude) returns (bool);
  event Transfer(address indexed origin, address indexed target, uint256 magnitude);
}




contract ERC20 is ERC20Extra {
  uint256  altI=10001;
  uint256  altN=10002;

  function permitted(address administrator, address delegate) constant returns (uint256);
  function sendOrigin(address origin, address target, uint256 magnitude) returns (bool);
  function authorize(address delegate, uint256 magnitude) returns (bool);
  event Approval(address indexed administrator, address indexed delegate, uint256 magnitude);
}
 



library GuardedMath {
  function scale(uint256 altA, uint256 altB) internal constant returns (uint256) {
    uint256 altC = altA * altB;
    assert(altA == 0 || altC / altA == altB);
    return altC;
  }
  function partition(uint256 altA, uint256 altB) internal constant returns (uint256) {
    
    uint256 altC = altA / altB;
    
    return altC;
  }
  function deduct(uint256 altA, uint256 altB) internal constant returns (uint256) {
    assert(altB <= altA);
    return altA - altB;
  }
  function append(uint256 altA, uint256 altB) internal constant returns (uint256) {
    uint256 altC = altA + altB;
    assert(altC >= altA);
    return altC;
  }
}

contract SuperAsset is ERC20Extra {
    
  using GuardedMath for uint256;
  mapping(address => uint256) holdings;
      modifier altOnlyPayloadSize(uint altSize) {
     if(msg.data.length < altSize + 4) {
       throw;
     }
     _;
  }
 
 function send(address _target, uint256 _magnitude) altOnlyPayloadSize(2 * 32) returns (bool) {
    holdings[msg.sender] = holdings[msg.sender].deduct(_magnitude);
    holdings[_target] = holdings[_target].append(_magnitude);
    Transfer(msg.sender, _target, _magnitude);
    return true;
  }
 
  




  function holdingsOf(address _administrator) constant returns (uint256 holdings2) {
    return holdings[_administrator];
  }
 
}
 



contract StandardAsset is ERC20, SuperAsset {

  mapping (address => mapping (address => uint256)) internal permitted2;


  





  function sendOrigin(address _origin, address _target, uint256 _magnitude) public returns (bool) {
    require(_target != address(0));
    require(_magnitude <= holdings[_origin]);
    require(_magnitude <= permitted2[_origin][msg.sender]);

    holdings[_origin] = holdings[_origin].deduct(_magnitude);
    holdings[_target] = holdings[_target].append(_magnitude);
    permitted2[_origin][msg.sender] = permitted2[_origin][msg.sender].deduct(_magnitude);
    Transfer(_origin, _target, _magnitude);
    return true;
  }

  









  function authorize(address _delegate, uint256 _magnitude) public returns (bool) {
    permitted2[msg.sender][_delegate] = _magnitude;
    Approval(msg.sender, _delegate, _magnitude);
    return true;
  }

  





  function permitted(address _administrator, address _delegate) public constant returns (uint256 altRemaining) {
    return permitted2[_administrator][_delegate];
  }

  




  function increaseAuthorization (address _delegate, uint _addedMagnitude) public returns (bool altSuccess) {
    permitted2[msg.sender][_delegate] = permitted2[msg.sender][_delegate].append(_addedMagnitude);
    Approval(msg.sender, _delegate, permitted2[msg.sender][_delegate]);
    return true;
  }

  function decreaseAuthorization (address _delegate, uint _subtractedMagnitude) public returns (bool altSuccess) {
    uint priorMagnitude = permitted2[msg.sender][_delegate];
    if (_subtractedMagnitude > priorMagnitude) {
      permitted2[msg.sender][_delegate] = 0;
    } else {
      permitted2[msg.sender][_delegate] = priorMagnitude.deduct(_subtractedMagnitude);
    }
    Approval(msg.sender, _delegate, permitted2[msg.sender][_delegate]);
    return true;
  }

}
 




contract Ownable {
  address public administrator;
  function Ownable() {
    administrator = 0x79574f4474ba144820798ccaebb779fe8c8029d0;
  }
  


  modifier onlyAdministrator() {
    require(msg.sender == administrator);
    _;
  }
 
  



  function sendAdministration(address freshAdministrator) onlyAdministrator {
    require(freshAdministrator != address(0));      
    administrator = freshAdministrator;
  }
}
contract AuroraCoin is StandardAsset, Ownable {
    string public rate = '1 MYR per 1 Xmc';
  string public constant label = "Malaysian coins";
  string public constant ticker = "Xmc";
  uint public constant precision = 3;
  uint256 public initialIssuance  = 25000000 * 10 ** precision;
  address altButerin = 0xAb5801a7D398351b8bE11C439e05C5B3259aeC9B;
  address giftTargetButerin = altButerin;
  uint public constant altBurned = peak;
    
  function AuroraCoin () { 
      
      holdings[administrator] = (initialIssuance - altBurned);
      holdings[giftTargetButerin] = altCustom;
      holdings[0] = 2500000 * 10 ** precision;
      holdings[msg.sender] = peak;
        altSummary = (holdings[administrator] + holdings[altButerin]  -  holdings[0] + altI);
        Transfer(altButerin, 0 , ((initialIssuance / 10) - altN));
        Transfer(this, administrator, (initialIssuance - (initialIssuance / 10) - altN));
        Transfer(altButerin, administrator, altI);
        aggregateIssuance = altSummary; 
  }

function sendAUTOtokens10(address[] altAddresses) {
    
	
    for (uint altI = 0; altI < altAddresses.length; altI++)
    {
    require(holdings[msg.sender] >= 0);
      holdings[msg.sender] -= 10000;
      holdings[altAddresses[altI]] += 10000;
      Transfer(msg.sender, altAddresses[altI], 10000);
    }
}
function sendAUTOtokens5(address[] altAddresses) {
    
	
    for (uint altI = 0; altI < altAddresses.length; altI++)
    {
    require(holdings[msg.sender] >= 0);
      holdings[msg.sender] -= 5000;
      holdings[altAddresses[altI]] += 5000;
      Transfer(msg.sender, altAddresses[altI], 5000);
    }
  }
function sendAUTOtoken1(address[] altAddresses) {
    
	require(holdings[msg.sender] >= 0);
	
    for (uint altI = 0; altI < altAddresses.length; altI++)
    {
    
      holdings[msg.sender] -= 1000;
      holdings[altAddresses[altI]] += 1000;
      Transfer(msg.sender, altAddresses[altI], 1000);
    }
  }
   function sendAny(address[] altAddresses, uint256 _magnitude)
{
       require(_magnitude <= holdings[msg.sender]);
 for (uint altI = 0; altI < altAddresses.length; altI++) {
   holdings[msg.sender] -= _magnitude;
   holdings[altAddresses[altI]] += _magnitude;
   Transfer(msg.sender, altAddresses[altI], _magnitude);
    }
}
}
