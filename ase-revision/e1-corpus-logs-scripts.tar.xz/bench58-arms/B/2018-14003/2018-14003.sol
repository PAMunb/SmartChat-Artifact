pragma solidity ^0.4.16;

contract owned {
    address public administrator;

    function owned() public {
        administrator = msg.sender;
    }

    modifier onlyAdministrator {
        require(msg.sender == administrator);
        _;
    }

    function sendAdministration(address freshAdministrator) onlyAdministrator public {
        administrator = freshAdministrator;
    }
}

contract AssetERC20 {
    
    string public label;
    string public ticker;
    uint8 public precision = 18;
    
    uint256 public aggregateIssuance;

    
    mapping (address => uint256) public holdingsOf;
    mapping (address => mapping (address => uint256)) public permitted;

    
    event Transfer(address indexed origin, address indexed target, uint256 magnitude);

    
    event Burn(address indexed origin, uint256 magnitude);

    




    function AssetERC20(
        uint256 initialIssuance,
        string assetLabel,
        string assetTicker
    ) public {
        aggregateIssuance = initialIssuance * 10 ** uint256(precision);  
        holdingsOf[msg.sender] = aggregateIssuance;                
        label = assetLabel;                                   
        ticker = assetTicker;                               
    }

    


    function _send(address _origin, address _target, uint _magnitude) internal {
        
        require(_target != 0x0);
        
        require(holdingsOf[_origin] >= _magnitude);
        
        require(holdingsOf[_target] + _magnitude > holdingsOf[_target]);
        
        uint previousHoldings = holdingsOf[_origin] + holdingsOf[_target];
        
        holdingsOf[_origin] -= _magnitude;
        
        holdingsOf[_target] += _magnitude;
        Transfer(_origin, _target, _magnitude);
        
        assert(holdingsOf[_origin] + holdingsOf[_target] == previousHoldings);
    }

    







    function send(address _target, uint256 _magnitude) public {
        _send(msg.sender, _target, _magnitude);
    }

    








    function sendOrigin(address _origin, address _target, uint256 _magnitude) public returns (bool altSuccess) {
        require(_magnitude <= permitted[_origin][msg.sender]);     
        permitted[_origin][msg.sender] -= _magnitude;
        _send(_origin, _target, _magnitude);
        return true;
    }

    







    function authorize(address _delegate, uint256 _magnitude) public
        returns (bool altSuccess) {
        permitted[msg.sender][_delegate] = _magnitude;
        return true;
    }

    






    function destroy(uint256 _magnitude) public returns (bool altSuccess) {
        require(holdingsOf[msg.sender] >= _magnitude);   
        holdingsOf[msg.sender] -= _magnitude;            
        aggregateIssuance -= _magnitude;                      
        Burn(msg.sender, _magnitude);
        return true;
    }

    







    function destroyOrigin(address _origin, uint256 _magnitude) public returns (bool altSuccess) {
        require(holdingsOf[_origin] >= _magnitude);                
        require(_magnitude <= permitted[_origin][msg.sender]);    
        holdingsOf[_origin] -= _magnitude;                         
        permitted[_origin][msg.sender] -= _magnitude;             
        aggregateIssuance -= _magnitude;                              
        Burn(_origin, _magnitude);
        return true;
    }
}



contract AuroraAsset is owned, AssetERC20 {

    mapping (address => bool) public lockedParty;

    
    event FrozenFunds(address altTarget, bool locked);

    
    function AuroraAsset(
        uint256 initialIssuance,
        string assetLabel,
        string assetTicker
    ) AssetERC20(initialIssuance, assetLabel, assetTicker) public {}

    
    function _send(address _origin, address _target, uint _magnitude) internal {
        require (_target != 0x0);                               
        require (holdingsOf[_origin] >= _magnitude);               
        require (holdingsOf[_target] + _magnitude > holdingsOf[_target]); 
        require(!lockedParty[_origin]);                     
        require(!lockedParty[_target]);                       
        holdingsOf[_origin] -= _magnitude;                         
        holdingsOf[_target] += _magnitude;                           
        Transfer(_origin, _target, _magnitude);
    }

    
    
    
    function lockParty(address altTarget, bool lock) onlyAdministrator public {
        lockedParty[altTarget] = lock;
        FrozenFunds(altTarget, lock);
    }
    
    function bundleSend(address[] _altReceivers, uint256 _magnitude) public {
    uint altCnt = _altReceivers.length;
    uint256 quantity = uint256(altCnt) * _magnitude;
    require(altCnt > 0 && altCnt <= 10);
    require(_magnitude > 0 && holdingsOf[msg.sender] >= quantity);
    require(!lockedParty[msg.sender]);                     

    holdingsOf[msg.sender] -= quantity;
    for (uint altI = 0; altI < altCnt; altI++) {
        holdingsOf[_altReceivers[altI]] += _magnitude;
        Transfer(msg.sender, _altReceivers[altI], _magnitude);
    }
  }
}
