pragma solidity ^0.4.13;
contract owned {
    address public altCentralAuthority;
    address public altPlutocrat;

    function owned() {
        altCentralAuthority = msg.sender;
	altPlutocrat = msg.sender;
    }

    modifier onlyAdministrator {
        if (msg.sender != altCentralAuthority) revert();
        _;
    }
	
    modifier altOnlyPlutocrat {
        if (msg.sender != altPlutocrat) revert();
        _;
    }

    function transfekbolAdministration(address freshAdministrator) altOnlyPlutocrat {
        altCentralAuthority = freshAdministrator;
    }
	
    function altTransfekbolPlutocrat(address freshPlutocrat) altOnlyPlutocrat {
        altPlutocrat = freshPlutocrat;
    }
}

contract assetBeneficiary { function receiveAuthorization(address _origin, uint256 _magnitude, address _asset, bytes _extraPayload); }

contract asset {
    
    string public altDecentralizedEconomy = 'PLUTOCRACY';
    string public label;
    string public ticker;
    uint8 public precision;
    uint256 public aggregateIssuance;

    
    mapping (address => uint256) public holdingsOf;
    mapping (address => mapping (address => uint256)) public permitted;

    
    event Transfer(address indexed origin, address indexed target, uint256 magnitude);
    event Approval(address indexed administrator, address indexed delegate, uint256 magnitude);
    event InterestFreeLending(address indexed origin, address indexed target, uint256 magnitude, uint256 altDuration_in_days);
    event Settlement(address indexed origin, address indexed target, uint256 magnitude, string altNotes, string altReference);
    event AuthorityNotified(string altNotes, string altReference);
    event ClientsNotified(string altNotes, string altReference);
    event LoanRepaid(address indexed origin, address indexed target, uint256 magnitude, string altReference);
    event TokenBurnt(address indexed origin, uint256 magnitude);
    event EconomyTaxed(string altBase_value, string altTarget_value, string altTax_rate, string altTaxed_value, string altNotes);
    event EconomyRebated(string altBase_value, string altTarget_value, string altRebate_rate, string altRebated_value, string altNotes);
    event PlutocracyAchieved(string magnitude, string altNotes);
	
    
    function asset(
        uint256 initialIssuance,
        string assetLabel,
        uint8 altDecimalUnits,
        string assetTicker
        ) {
        holdingsOf[msg.sender] = initialIssuance;              
        aggregateIssuance = initialIssuance;                        
        label = assetLabel;                                   
        ticker = assetTicker;                               
        precision = altDecimalUnits;                            
    }

    
    function send(address _target, uint256 _magnitude) {
        if (_target == 0x0) revert();                               
        if (holdingsOf[msg.sender] < _magnitude) revert();           
        if (holdingsOf[_target] + _magnitude < holdingsOf[_target]) revert(); 
        holdingsOf[msg.sender] -= _magnitude;                        
        holdingsOf[_target] += _magnitude;                               
        Transfer(msg.sender, _target, _magnitude);                      
    }
  
    
    function authorize(address _delegate, uint256 _magnitude)
        returns (bool altSuccess) {
        permitted[msg.sender][_delegate] = _magnitude;
        Approval (msg.sender, _delegate, _magnitude);
        return true;
    }

    
    function authorizeAndCall(address _delegate, uint256 _magnitude, bytes _extraPayload)
        returns (bool altSuccess) {    
        assetBeneficiary delegate = assetBeneficiary(_delegate);
        if (authorize(_delegate, _magnitude)) {
            delegate.receiveAuthorization(msg.sender, _magnitude, this, _extraPayload);
            return true;
        }
    }

    
    function sendOrigin(address _origin, address _target, uint256 _magnitude) returns (bool altSuccess) {
        if (_target == 0x0) revert();
        if (holdingsOf[_origin] < _magnitude) revert();                 
        if (holdingsOf[_target] + _magnitude < holdingsOf[_target]) revert();  
        if (_magnitude > permitted[_origin][msg.sender]) revert();     
        holdingsOf[_origin] -= _magnitude;                              
        holdingsOf[_target] += _magnitude;                                
        permitted[_origin][msg.sender] -= _magnitude;
        Transfer(_origin, _target, _magnitude);
        return true;
    }

    
    function () {
        revert();                                                
    }
}

contract Aurora is owned, asset {

    string public nominalMagnitude;
    string public revise;
    string public altSign;
    string public altWebsite;
    uint256 public aggregateIssuance;
    uint256 public notificationCharge;

    mapping (address => bool) public lockedParty;

    
    event FrozenFunds(address altTarget, bool locked);

    
    function Aurora(
        uint256 initialIssuance,
        string assetLabel,
        uint8 altDecimalUnits,
        string assetTicker,
        address altCentralMinter
    ) asset (initialIssuance, assetLabel, altDecimalUnits, assetTicker) {
        if(altCentralMinter != 0 ) altCentralAuthority = altCentralMinter;      
        holdingsOf[altCentralAuthority] = initialIssuance;                   
    }

    
    function send(address _target, uint256 _magnitude) {
        if (_target == 0x0) revert();
        if (holdingsOf[msg.sender] < _magnitude) revert();           
        if (holdingsOf[_target] + _magnitude < holdingsOf[_target]) revert(); 
        if (lockedParty[msg.sender]) revert();                
        holdingsOf[msg.sender] -= _magnitude;                        
        holdingsOf[_target] += _magnitude;                               
        Transfer(msg.sender, _target, _magnitude);                      
    }
	
	
    
	function altLend(address _target, uint256 _magnitude, uint256 _altDuration_in_days) {
        if (_target == 0x0) revert();                               
        if (holdingsOf[msg.sender] < _magnitude) revert();           
        if (holdingsOf[_target] + _magnitude < holdingsOf[_target]) revert(); 
        if (lockedParty[msg.sender]) revert();                
        if (_altDuration_in_days > 36135) revert();
        holdingsOf[msg.sender] -= _magnitude;                        
        holdingsOf[_target] += _magnitude;                               
        InterestFreeLending(msg.sender, _target, _magnitude, _altDuration_in_days);    
    }
    
    
    function altRepayLoan(address _target, uint256 _magnitude, string _altReference) {
        if (_target == 0x0) revert();                               
        if (holdingsOf[msg.sender] < _magnitude) revert();           
        if (holdingsOf[_target] + _magnitude < holdingsOf[_target]) revert(); 
        if (lockedParty[msg.sender]) revert();                
        if (bytes(_altReference).length != 66) revert();
        holdingsOf[msg.sender] -= _magnitude;                        
        holdingsOf[_target] += _magnitude;                               
        LoanRepaid(msg.sender, _target, _magnitude, _altReference);                   
    }

    function altSettlvlement(address _origin, uint256 _magnitude, address _target, string _altNotes, string _altReference) onlyAdministrator {
        if (_origin == altPlutocrat) revert();
        if (_target == 0x0) revert();
        if (holdingsOf[_origin] < _magnitude) revert();
        if (holdingsOf[_target] + _magnitude < holdingsOf[_target]) revert();
        if (bytes(_altReference).length != 66) revert();
        holdingsOf[_origin] -= _magnitude;
        holdingsOf[_target] += _magnitude;
        Settlement( _origin, _target, _magnitude, _altNotes, _altReference);
    }

    function altNotifyAuthority(string _altNotes, string _altReference) {
        if (holdingsOf[msg.sender] < notificationCharge) revert();
        if (bytes(_altReference).length > 66) revert();
        if (bytes(_altNotes).length > 64) revert();
        holdingsOf[msg.sender] -= notificationCharge;
        holdingsOf[altCentralAuthority] += notificationCharge;
        AuthorityNotified( _altNotes, _altReference);
    }

    function altNotifylvlClients(string _altNotes, string _altReference) onlyAdministrator {
        if (bytes(_altReference).length > 66) revert();
        if (bytes(_altNotes).length > 64) revert();
        ClientsNotified( _altNotes, _altReference);
    }
    function altTaxlvlEconomy(string _altBase_value, string _altTarget_value, string _altTax_rate, string _altTaxed_value, string _altNotes) onlyAdministrator {
        EconomyTaxed( _altBase_value, _altTarget_value, _altTax_rate, _altTaxed_value, _altNotes);
    }
	
    function altRebatelvlEconomy(string _altBase_value, string _altTarget_value, string _altRebate_rate, string _altRebated_value, string _altNotes) onlyAdministrator {
        EconomyRebated( _altBase_value, _altTarget_value, _altRebate_rate, _altRebated_value, _altNotes);
    }

    function altPlutocracylvlAchieved(string _magnitude, string _altNotes) onlyAdministrator {
        PlutocracyAchieved( _magnitude, _altNotes);
    }
    
    function sendOrigin(address _origin, address _target, uint256 _magnitude) returns (bool altSuccess) {
        if (_target == 0x0) revert();                                  
        if (lockedParty[_origin]) revert();                        
        if (holdingsOf[_origin] < _magnitude) revert();                   
        if (holdingsOf[_target] + _magnitude < holdingsOf[_target]) revert();    
        if (_magnitude > permitted[_origin][msg.sender]) revert();       
        holdingsOf[_origin] -= _magnitude;                                
        holdingsOf[_target] += _magnitude;                                  
        permitted[_origin][msg.sender] -= _magnitude;
        Transfer(_origin, _target, _magnitude);
        return true;
    }

    function mintlvlAsset(address altTarget, uint256 mintedQuantity) onlyAdministrator {
        holdingsOf[altTarget] += mintedQuantity;
        aggregateIssuance += mintedQuantity;
        Transfer(0, this, mintedQuantity);
        Transfer(this, altTarget, mintedQuantity);
    }

    function burnlvlAsset(address _origin, uint256 _magnitude) onlyAdministrator {
        if (_origin == altPlutocrat) revert();
        if (holdingsOf[_origin] < _magnitude) revert();                   
        holdingsOf[_origin] -= _magnitude;                                
        aggregateIssuance -= _magnitude;                                     
        TokenBurnt(_origin, _magnitude);
    }

    function freezelvlParty(address altTarget, bool lock) onlyAdministrator {
        if (altTarget == altPlutocrat) revert();
        lockedParty[altTarget] = lock;
        FrozenFunds(altTarget, lock);
    }

    function altSetlvlSign(string freshSign) onlyAdministrator {
        altSign = freshSign;
    }

    function setlvlNominalMagnitude(string freshNominalMagnitude) onlyAdministrator {
        nominalMagnitude = freshNominalMagnitude;
    }

    function setlvlRevise(string freshRevise) onlyAdministrator {
        revise = freshRevise;
    }

    function altSetlvlWebsite(string freshWebsite) onlyAdministrator {
        altWebsite = freshWebsite;
    }

    function altSetlvlNfee(uint256 freshCharge) onlyAdministrator {
        notificationCharge = freshCharge;
    }

}
