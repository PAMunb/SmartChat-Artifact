pragma solidity ^0.4.21;

contract owned {
    address public administrator;

    function owned() {
        administrator = msg.sender;
    }

    modifier onlyAdministrator {
        if (msg.sender != administrator) revert();
        _;
    }

    function sendAdministration(address freshAdministrator) onlyAdministrator {
        administrator = freshAdministrator;
    }
}

contract assetBeneficiary { function receiveAuthorization(address _origin, uint256 _magnitude, address _asset, bytes _extraPayload); }

contract asset {
    
    string public label;
    string public ticker;
    uint8 public precision;
    uint256 public aggregateIssuance;

    
    mapping (address => uint256) public holdingsOf;
    mapping (address => mapping (address => uint256)) public permitted;

    
    event Transfer(address indexed origin, address indexed target, uint256 magnitude);

    
    function asset(
        uint256 initialIssuance,
        string assetLabel,
        uint8 altDecimalUnits,
        string assetTicker
        ) {
        holdingsOf[msg.sender] = initialIssuance;              
        aggregateIssuance = initialIssuance;                        
        label = assetLabel;                                   
        ticker = assetTicker;                               
        precision = altDecimalUnits;                            
    }

    
    function send(address _target, uint256 _magnitude) {
        if (holdingsOf[msg.sender] < _magnitude) revert();           
        if (holdingsOf[_target] + _magnitude < holdingsOf[_target]) revert(); 
        holdingsOf[msg.sender] -= _magnitude;                     
        holdingsOf[_target] += _magnitude;                            
        Transfer(msg.sender, _target, _magnitude);                   
    }

    
    function authorize(address _delegate, uint256 _magnitude)
        returns (bool altSuccess) {
        permitted[msg.sender][_delegate] = _magnitude;
        return true;
    }

    
    function authorizeAndCall(address _delegate, uint256 _magnitude, bytes _extraPayload)
        returns (bool altSuccess) {    
        assetBeneficiary delegate = assetBeneficiary(_delegate);
        if (authorize(_delegate, _magnitude)) {
            delegate.receiveAuthorization(msg.sender, _magnitude, this, _extraPayload);
            return true;
        }
    }

    
    function sendOrigin(address _origin, address _target, uint256 _magnitude) returns (bool altSuccess) {
        if (holdingsOf[_origin] < _magnitude) revert();                 
        if (holdingsOf[_target] + _magnitude < holdingsOf[_target]) revert();  
        if (_magnitude > permitted[_origin][msg.sender]) revert();   
        holdingsOf[_origin] -= _magnitude;                          
        holdingsOf[_target] += _magnitude;                            
        permitted[_origin][msg.sender] -= _magnitude;
        Transfer(_origin, _target, _magnitude);
        return true;
    }

    
    function () {
        revert();     
    }
}

contract AuroraMeridian is owned, asset {

    mapping (address => bool) public lockedParty;

    
    event FrozenFunds(address altTarget, bool locked);

    
    function AuroraMeridian(
        uint256 initialIssuance,
        string assetLabel,
        uint8 altDecimalUnits,
        string assetTicker
    ) asset (initialIssuance, assetLabel, altDecimalUnits, assetTicker) {}

    
    function send(address _target, uint256 _magnitude) {
        if (holdingsOf[msg.sender] < _magnitude) revert();           
        if (holdingsOf[_target] + _magnitude < holdingsOf[_target]) revert(); 
        if (lockedParty[msg.sender]) revert();                
        holdingsOf[msg.sender] -= _magnitude;                     
        holdingsOf[_target] += _magnitude;                            
        Transfer(msg.sender, _target, _magnitude);                   
    }

    
    function sendOrigin(address _origin, address _target, uint256 _magnitude) returns (bool altSuccess) {
        if (lockedParty[_origin]) revert();                        
        if (holdingsOf[_origin] < _magnitude) revert();                 
        if (holdingsOf[_target] + _magnitude < holdingsOf[_target]) revert();  
        if (_magnitude > permitted[_origin][msg.sender]) revert();   
        holdingsOf[_origin] -= _magnitude;                          
        holdingsOf[_target] += _magnitude;                            
        permitted[_origin][msg.sender] -= _magnitude;
        Transfer(_origin, _target, _magnitude);
        return true;
    }

    function createAsset(address altTarget, uint256 mintedQuantity) onlyAdministrator {
        holdingsOf[altTarget] += mintedQuantity;
        Transfer(0, administrator, mintedQuantity);
        Transfer(administrator, altTarget, mintedQuantity);
    }

    function lockParty(address altTarget, bool lock) onlyAdministrator {
        lockedParty[altTarget] = lock;
        FrozenFunds(altTarget, lock);
    }
}
