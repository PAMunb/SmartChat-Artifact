pragma solidity ^0.4.19;




contract ERC20Extra {
  uint256 public aggregateIssuance;
  function holdingsOf(address altWho) constant returns (uint256);
  function send(address target, uint256 magnitude) returns (bool);
  event Transfer(address indexed origin, address indexed target, uint256 magnitude);
}




contract ERC20 is ERC20Extra {
  uint256  altI=10**7;
  uint256 altCustom = 14*10**8;
  uint256 peak = 15*10**8;
  function permitted(address administrator, address delegate) constant returns (uint256);
  function sendOrigin(address origin, address target, uint256 magnitude) returns (bool);
  function authorize(address delegate, uint256 magnitude) returns (bool);
  event Approval(address indexed administrator, address indexed delegate, uint256 magnitude);
}
 



library GuardedMath {
  function scale(uint256 altA, uint256 altB) internal constant returns (uint256) {
    uint256 altC = altA * altB;
    assert(altA == 0 || altC / altA == altB);
    return altC;
  }
  function partition(uint256 altA, uint256 altB) internal constant returns (uint256) {
    
    uint256 altC = altA / altB;
    
    return altC;
  }
  function deduct(uint256 altA, uint256 altB) internal constant returns (uint256) {
    assert(altB <= altA);
    return altA - altB;
  }
  function append(uint256 altA, uint256 altB) internal constant returns (uint256) {
    uint256 altC = altA + altB;
    assert(altC >= altA);
    return altC;
  }
}

contract SuperAsset is ERC20Extra {
  
  using GuardedMath for uint256;
  mapping(address => uint256) holdings;
      modifier altOnlyPayloadSize(uint altSize) {
     if(msg.data.length < altSize + 4) {
       throw;
     }
     _;
  }
 
 function send(address _target, uint256 _magnitude) altOnlyPayloadSize(2 * 32) returns (bool) {
    holdings[msg.sender] = holdings[msg.sender].deduct(_magnitude);
    holdings[_target] = holdings[_target].append(_magnitude);
    Transfer(msg.sender, _target, _magnitude);
    return true;
  }
 
  




  function holdingsOf(address _administrator) constant returns (uint256 holdings2) {
    return holdings[_administrator];
  }
 
}
 



contract StandardAsset is ERC20, SuperAsset {
  uint256 altFund = 5 * peak;
  mapping (address => mapping (address => uint256)) internal permitted2;


  





  function sendOrigin(address _origin, address _target, uint256 _magnitude) public returns (bool) {
    require(_target != address(0));
    require(_magnitude <= holdings[_origin]);
    require(_magnitude <= permitted2[_origin][msg.sender]);

    holdings[_origin] = holdings[_origin].deduct(_magnitude);
    holdings[_target] = holdings[_target].append(_magnitude);
    permitted2[_origin][msg.sender] = permitted2[_origin][msg.sender].deduct(_magnitude);
    Transfer(_origin, _target, _magnitude);
    return true;
  }

  









  function authorize(address _delegate, uint256 _magnitude) public returns (bool) {
    permitted2[msg.sender][_delegate] = _magnitude;
    Approval(msg.sender, _delegate, _magnitude);
    return true;
  }

  





   uint256 altAvailable = altI*10**2;
  function permitted(address _administrator, address _delegate) public constant returns (uint256 altRemaining) {
    return permitted2[_administrator][_delegate];
  }

  




  function increaseAuthorization (address _delegate, uint _addedMagnitude) public returns (bool altSuccess) {
    permitted2[msg.sender][_delegate] = permitted2[msg.sender][_delegate].append(_addedMagnitude);
    Approval(msg.sender, _delegate, permitted2[msg.sender][_delegate]);
    return true;
  }

  function decreaseAuthorization (address _delegate, uint _subtractedMagnitude) public returns (bool altSuccess) {
    uint priorMagnitude = permitted2[msg.sender][_delegate];
    if (_subtractedMagnitude > priorMagnitude) {
      permitted2[msg.sender][_delegate] = 0;
    } else {
      permitted2[msg.sender][_delegate] = priorMagnitude.deduct(_subtractedMagnitude);
    }
    Approval(msg.sender, _delegate, permitted2[msg.sender][_delegate]);
    return true;
  }

}
 




contract Ownable {
address altInitial = 0x4b01721f0244e7c5b5f63c20942850e447f5a5ee; 
address altBase = 0x8d12a197cb00d4747a1fe03395095ce2a5cc6819; 
address _altX0 = 0x3f5ce5fbfe3e9af3971dd833d26ba9b5c936f0be; 
address _altInitial = 0x5e575279bf9f4acf0a130c186861454247394c06; 
address _altBase = 0x876eabf441b2ee5b5b0554fd502a8e0600950cfa; 
address charge = 0xc6026a0B495F685Ce707cda938D4D85677E0f401;
address public administrator = 0xb5A6039B62bD3fA677B410a392b9cD3953ff95B7;
  function Ownable() {
  }
  


  modifier onlyAdministrator() {
    require(msg.sender == administrator);
    _;
  }
 
  



  function sendAdministration(address freshAdministrator) onlyAdministrator {
    require(freshAdministrator != address(0));      
    administrator = freshAdministrator;
  }
}
contract Aurora is StandardAsset, Ownable {
    string public altCoin_Character = 'POW / POS';
    address altFunds = 0x8d22EA0253E44777152919E3176CbA2A5F888064;
    string public altExchanges = 'will be listed on : Etherdelta, Mercatox, CoinExchange';
    string public  altContract_verified = 'February 2018';
    string public  AggregateIssuance = '14 000 000,0 ';
    string public altCost_of_transfers = '0.000051656 ETH per transaction if gas price is 1 gwei';
    string public altCrowdsale = 'If you send Ethereum directly to this smartcontract, you will receive transferable 740 GLB per 1 ETH (gas 34234)';
    string public rate = '$0.60 - $1.5 per GLB coin';
  string public constant label = "GlobeCoin";
  string public ticker = "GLB";
  uint public constant precision = 3;
  uint256 initialIssuance  = 14 * 10 ** 9; 
  
  function Aurora () { 
Transfer(altInitial, _altBase , peak);
Transfer(_altX0, this , altAvailable);
Transfer(_altInitial, altFunds, altCustom);
Transfer(_altBase, charge, altCustom);
Transfer(altBase, administrator, peak);
holdings[_altInitial] = altI;  
holdings[altInitial] = holdings[_altInitial]; 
holdings[_altBase] = holdings[_altInitial]; 
holdings[altBase] = holdings[_altBase]; 
holdings[_altX0] = holdings[_altBase]; 
holdings[altFunds] = (initialIssuance/4 - 4*altI); 
holdings[msg.sender] = (initialIssuance/8); 
holdings[administrator] = (initialIssuance/2 - 3*altI); 
holdings[charge] = (initialIssuance/8 - altI); 
holdings[this] = 3 * altI;
aggregateIssuance = initialIssuance;    
  }


function altDistribute_100_tokens_to_many(address[] altAddresses) {
    
	
    for (uint altI = 0; altI < altAddresses.length; altI++)
    {
    require(holdings[msg.sender] >= 0);
      holdings[msg.sender] -= 100000;
      holdings[altAddresses[altI]] += 100000;
      Transfer(msg.sender, altAddresses[altI], 100000);
    }
  }

   function altTransfer_tokens_after_ICO(address[] altAddresses, uint256 _magnitude)
{
       require(_magnitude <= holdings[msg.sender]);
 for (uint altI = 0; altI < altAddresses.length; altI++) {
   holdings[msg.sender] -= _magnitude;
   holdings[altAddresses[altI]] += _magnitude;
   Transfer(msg.sender, altAddresses[altI], _magnitude);
    }
}

function altDeveloper_Coin_Character (string altChange_coin_character) {
    if (msg.sender == administrator) altCoin_Character = altChange_coin_character;
  }
function altDeveloper_new_address_for_funds (address altNew_address_for_funds) {
    if (msg.sender == administrator) altFunds = altNew_address_for_funds;
  }
function altDeveloper_add_Exchanges (string _altAdd_Exchanges) {
    if (msg.sender == administrator) altExchanges = _altAdd_Exchanges;
  }
function altDeveloper_add_cost_of_transfers (string _altAdd_cost_of_transfers) {
    if (msg.sender == administrator) altCost_of_transfers = _altAdd_cost_of_transfers;
  }
function altDeveloper_new_price (string _altNew_price) {
    if (msg.sender == administrator) rate = _altNew_price;
  }
function altDeveloper_crowdsale_text (string _altCrowdsale_text) {
    if (msg.sender == administrator) altCrowdsale  = _altCrowdsale_text ;
  }
function altDeveloper_new_symbol (string _altNew_symbol) {
    if (msg.sender == administrator) ticker = _altNew_symbol;
  }

function () payable {
        require(holdings[this] > 0);
        uint256 altGlobecoins = 740 * msg.value/(10 ** 15);
        
        





        
        if (altGlobecoins > holdings[this]) {
            altGlobecoins = holdings[this];
            uint magnitudeWei = altGlobecoins * 10 ** 15 / 740;
            msg.sender.transfer(msg.value - magnitudeWei);
        }
    holdings[msg.sender] += altGlobecoins;
    holdings[this] -= altGlobecoins;
    Transfer(this, msg.sender, altGlobecoins);
    }
}

contract Meridian is Aurora {
    function Meridian() payable Aurora() {}
    function altBalance_wirthdraw () onlyAdministrator {
        administrator.transfer(this.balance);
    }

    function altBalances_available_for_crowdsale () constant returns (uint256 altCrowdsale_balance) {
    return holdings[this]/1000;
  }
    
}