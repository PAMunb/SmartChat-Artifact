

pragma solidity ^0.4.15;

contract Asset {
    
    
    uint256 public aggregateIssuance;

    
    
    function holdingsOf(address _administrator) public constant returns (uint256 holdings);

    
    
    
    
    function send(address _target, uint256 _magnitude) public returns (bool altSuccess);

    
    
    
    
    
    function sendOrigin(address _origin, address _target, uint256 _magnitude) public returns (bool altSuccess);

    
    
    
    
    function authorize(address _delegate, uint256 _magnitude) public returns (bool altSuccess);

    
    
    
    function permitted(address _administrator, address _delegate) public constant returns (uint256 altRemaining);

    event Transfer(address indexed _origin, address indexed _target, uint256 _magnitude);
    event Approval(address indexed _administrator, address indexed _delegate, uint256 _magnitude);
}

contract Owned {

    
    
    modifier onlyAdministrator() {
        require(msg.sender == administrator);
        _;
    }

    address public administrator;

    
    function Owned() public {
        administrator = msg.sender;
    }

    address freshAdministrator=0x0;

    event OwnerUpdate(address _prevAdministrator, address _freshAdministrator);

    
    function modifyAdministrator(address _freshAdministrator) public onlyAdministrator {
        require(_freshAdministrator != administrator);
        freshAdministrator = _freshAdministrator;
    }

    
    function acceptAdministration() public{
        require(msg.sender == freshAdministrator);
        OwnerUpdate(administrator, freshAdministrator);
        administrator = freshAdministrator;
        freshAdministrator = 0x0;
    }
}

contract Controlled is Owned{

    function Controlled() public {
       assignExclude(msg.sender);
    }

    
    bool public sendActive = false;

    
    bool sealFlag=true;
    mapping(address => bool) altLocked;
    mapping(address => bool) altExclude;

    function activateSend(bool _activate) public onlyAdministrator{
        sendActive=_activate;
    }

    function deactivateSeal(bool _activate) public onlyAdministrator returns (bool altSuccess){
        sealFlag=_activate;
        return true;
    }

    function appendSeal(address _location) public onlyAdministrator returns (bool altSuccess){
        require(_location!=msg.sender);
        altLocked[_location]=true;
        return true;
    }

    function assignExclude(address _location) public onlyAdministrator returns (bool altSuccess){
        altExclude[_location]=true;
        return true;
    }

    function dropSeal(address _location) public onlyAdministrator returns (bool altSuccess){
        altLocked[_location]=false;
        return true;
    }

    modifier sendPermitted(address _location) {
        if (!altExclude[_location]) {
            assert(sendActive);
            if(sealFlag){
                assert(!altLocked[_location]);
            }
        }
        
        _;
    }

}

contract StandardAsset is Asset,Controlled {

    function send(address _target, uint256 _magnitude) public sendPermitted(msg.sender) returns (bool altSuccess) {
        
        
        
        if (holdings2[msg.sender] >= _magnitude && holdings2[_target] + _magnitude > holdings2[_target]) {
            holdings2[msg.sender] -= _magnitude;
            holdings2[_target] += _magnitude;
            Transfer(msg.sender, _target, _magnitude);
            return true;
        } else { return false; }
    }

    function sendOrigin(address _origin, address _target, uint256 _magnitude) public sendPermitted(_origin) returns (bool altSuccess) {
        
        if (holdings2[_origin] >= _magnitude && permitted2[_origin][msg.sender] >= _magnitude && holdings2[_target] + _magnitude > holdings2[_target]) {
            holdings2[_target] += _magnitude;
            holdings2[_origin] -= _magnitude;
            permitted2[_origin][msg.sender] -= _magnitude;
            Transfer(_origin, _target, _magnitude);
            return true;
        } else { return false; }
    }

    function holdingsOf(address _administrator) public constant returns (uint256 holdings) {
        return holdings2[_administrator];
    }

    function authorize(address _delegate, uint256 _magnitude) public returns (bool altSuccess) {
        permitted2[msg.sender][_delegate] = _magnitude;
        Approval(msg.sender, _delegate, _magnitude);
        return true;
    }

    function permitted(address _administrator, address _delegate) public constant returns (uint256 altRemaining) {
      return permitted2[_administrator][_delegate];
    }

    mapping (address => uint256) holdings2;
    mapping (address => mapping (address => uint256)) permitted2;
}

contract Aurora is StandardAsset {

    function () public {
        revert();
    }

    string public label = "SmartMesh Token";                   
    uint8 public precision = 18;                
    string public ticker = "SMT";                 
    string public altVersion = 'v0.1';       
    uint256 public allocateFinishInstant;

    
    
    mapping(address => uint256) altNonces;

    function Aurora() public {
        allocateFinishInstant = now + 1 days;
    }

    










    function sendProxy(address _origin, address _target, uint256 _magnitude, uint256 _chargeSmt,
        uint8 _altV,bytes32 _altR, bytes32 _altS) public sendPermitted(_origin) returns (bool){

        if(holdings2[_origin] < _chargeSmt + _magnitude) revert();

        uint256 altNonce = altNonces[_origin];
        bytes32 altH = keccak256(_origin,_target,_magnitude,_chargeSmt,altNonce);
        if(_origin != ecrecover(altH,_altV,_altR,_altS)) revert();

        if(holdings2[_target] + _magnitude < holdings2[_target]
            || holdings2[msg.sender] + _chargeSmt < holdings2[msg.sender]) revert();
        holdings2[_target] += _magnitude;
        Transfer(_origin, _target, _magnitude);

        holdings2[msg.sender] += _chargeSmt;
        Transfer(_origin, msg.sender, _chargeSmt);

        holdings2[_origin] -= _magnitude + _chargeSmt;
        altNonces[_origin] = altNonce + 1;
        return true;
    }

    









    function authorizeProxy(address _origin, address _delegate, uint256 _magnitude,
        uint8 _altV,bytes32 _altR, bytes32 _altS) public returns (bool altSuccess) {

        uint256 altNonce = altNonces[_origin];
        bytes32 altHash = keccak256(_origin,_delegate,_magnitude,altNonce);
        if(_origin != ecrecover(altHash,_altV,_altR,_altS)) revert();
        permitted2[_origin][_delegate] = _magnitude;
        Approval(_origin, _delegate, _magnitude);
        altNonces[_origin] = altNonce + 1;
        return true;
    }


    



    function fetchNonce(address _location) public constant returns (uint256){
        return altNonces[_location];
    }

    
    function authorizeAndCall(address _delegate, uint256 _magnitude, bytes _extraPayload) public returns (bool altSuccess) {
        permitted2[msg.sender][_delegate] = _magnitude;
        Approval(msg.sender, _delegate, _magnitude);

        
        
        
        if(!_delegate.call(bytes4(bytes32(keccak256("receiveApproval(address,uint256,address,bytes)"))), msg.sender, _magnitude, this, _extraPayload)) { revert(); }
        return true;
    }

    
    function authorizeAndCallcode(address _delegate, uint256 _magnitude, bytes _extraPayload) public returns (bool altSuccess) {
        permitted2[msg.sender][_delegate] = _magnitude;
        Approval(msg.sender, _delegate, _magnitude);

        
        if(!_delegate.call(_extraPayload)) { revert(); }
        return true;
    }

    
    
    
    function allocateAssets(address[] _administrators, uint256[] _altValues) public onlyAdministrator {

        if(allocateFinishInstant < now) revert();
        if(_administrators.length != _altValues.length) revert();

        for(uint256 altI = 0; altI < _administrators.length ; altI++){
            address target = _administrators[altI];
            uint256 magnitude = _altValues[altI];
            if(aggregateIssuance + magnitude <= aggregateIssuance || holdings2[target] + magnitude <= holdings2[target]) revert();
            aggregateIssuance += magnitude;
            holdings2[target] += magnitude;
        }
    }
}