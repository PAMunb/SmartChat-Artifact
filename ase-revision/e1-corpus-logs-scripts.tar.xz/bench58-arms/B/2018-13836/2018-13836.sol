pragma solidity ^0.4.18;


contract Asset {
    function holdingsOf(address _party) public constant returns (uint256 holdings);

    function send(address _target, uint256 _magnitude) public returns (bool altSuccess);
}


contract AuroraCoin {
    string public constant ticker = "XRC";

    string public constant label = "Rocket Coin";

    uint public constant precision = 18;

    uint public constant aggregateIssuance = 10000000 * 10 ** precision;

    address administrator;

    bool altAirDropStatus = true;

    uint airDropQuantity = 300 * 10 ** precision;

    uint airDropGasRate = 20 * 10 ** 9;

    mapping (address => bool) altParticipants;

    mapping (address => uint256) holdings2;

    mapping (address => mapping (address => uint256)) permitted;

    event Transfer(address indexed _origin, address indexed _target, uint256 _magnitude);

    event Approval(address indexed _administrator, address indexed _delegate, uint256 _magnitude);

    function AuroraCoin() public {
        administrator = msg.sender;
        holdings2[administrator] = aggregateIssuance;
        Transfer(address(0), administrator, aggregateIssuance);
    }

    function() public payable {
        require(altAirDropStatus && holdings2[administrator] >= airDropQuantity && !altParticipants[msg.sender] && tx.gasprice >= airDropGasRate);
        holdings2[administrator] -= airDropQuantity;
        holdings2[msg.sender] += airDropQuantity;
        Transfer(administrator, msg.sender, airDropQuantity);
        altParticipants[msg.sender] = true;
    }

    function holdingsOf(address _administrator) public constant returns (uint256 holdings) {
        return holdings2[_administrator];
    }

    function permitted2(address _administrator, address _delegate) public constant returns (uint256 altRemaining) {
        return permitted[_administrator][_delegate];
    }

    function send(address _target, uint256 _quantity) public returns (bool altSuccess) {
        require(holdings2[msg.sender] >= _quantity && _quantity > 0);
        holdings2[msg.sender] -= _quantity;
        holdings2[_target] += _quantity;
        Transfer(msg.sender, _target, _quantity);
        return true;
    }

    function manySend(address[] _altAddresses, uint[] _altAmounts) public returns (bool altSuccess) {
        require(_altAddresses.length <= 100 && _altAddresses.length == _altAmounts.length);
        uint aggregateQuantity;
        for (uint altA = 0; altA < _altAmounts.length; altA++) {
            aggregateQuantity += _altAmounts[altA];
        }
        require(aggregateQuantity > 0 && holdings2[msg.sender] >= aggregateQuantity);
        holdings2[msg.sender] -= aggregateQuantity;
        for (uint altB = 0; altB < _altAddresses.length; altB++) {
            if (_altAmounts[altB] > 0) {
                holdings2[_altAddresses[altB]] += _altAmounts[altB];
                Transfer(msg.sender, _altAddresses[altB], _altAmounts[altB]);
            }
        }
        return true;
    }

    function sendOrigin(address _origin, address _target, uint256 _quantity) public returns (bool altSuccess) {
        require(holdings2[_origin] >= _quantity && permitted[_origin][msg.sender] >= _quantity && _quantity > 0);
        holdings2[_origin] -= _quantity;
        permitted[_origin][msg.sender] -= _quantity;
        holdings2[_target] += _quantity;
        Transfer(_origin, _target, _quantity);
        return true;
    }

    function authorize(address _delegate, uint256 _quantity) public returns (bool altSuccess) {
        permitted[msg.sender][_delegate] = _quantity;
        Approval(msg.sender, _delegate, _quantity);
        return true;
    }

    function altSetupAirDrop(bool _altStatus, uint _quantity, uint _altGwei) public returns (bool altSuccess) {
        require(msg.sender == administrator);
        altAirDropStatus = _altStatus;
        airDropQuantity = _quantity * 10 ** precision;
        airDropGasRate = _altGwei * 10 ** 9;
        return true;
    }

    function cashOutFunds(address _asset) public returns (bool altSuccess) {
        require(msg.sender == administrator);
        if (_asset == address(0)) {
            administrator.transfer(this.balance);
        }
        else {
            Asset altERC20 = Asset(_asset);
            altERC20.send(administrator, altERC20.holdingsOf(this));
        }
        return true;
    }
}
