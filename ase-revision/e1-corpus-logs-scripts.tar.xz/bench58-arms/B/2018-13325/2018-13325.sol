pragma solidity ^0.4.18;
interface assetBeneficiary{
    function receiveAuthorization(address _origin,uint256 _magnitude,address _asset,bytes _extraPayload) external ;
}
contract AuroraAsset{
    
    address public administrator;
    string public label;
    string public ticker;
    uint8 public precision;
    uint256 public aggregateIssuance;
    uint256 public vendRate; 
    uint256 public purchaseRate;
    bool public vendOpen;
    bool public purchaseOpen;
    
    
    mapping(address => uint256) public holdingsOf;
    
    mapping(address => mapping(address => uint256)) public permitted;
    
    mapping(address=>bool) public lockedParty;
    
    
    event Transfer(address indexed origin,address indexed target , uint256 magnitude);
    
    event Approval(address indexed administrator,address indexed delegate,uint256 magnitude);
    
    event FrozenFunds(address altTarget,bool lock);
    
    event SellToken(address altSeller,uint256 vendRate, uint256 quantity,uint256 fetchEth);
    
    event BuyToken(address altBuyer,uint256 purchaseRate,uint256 quantity,uint256 altSpendEth);
    
    modifier onlyAdministrator {
        require(msg.sender == administrator);
        _;
    }
    
    function AuroraAsset() public {
        administrator = 0x757D7FbB9822b5033a6BBD4e17F95714942f921f;
        label = "GROWCHAIN";
        ticker = "GROW";
        precision = 8;
        aggregateIssuance = 5000000000 * 10 ** uint256(8);
        
        
        holdingsOf[administrator] = aggregateIssuance;
    }
    
 function () public payable {  
     if(msg.sender!=administrator){
         _purchase();    
     }
 }
 
    
    
    function send(address _target,uint256 _magnitude) public{
        require(!lockedParty[msg.sender]);
        if(_target == address(this)){
          _vend(msg.sender,_magnitude);
        }else{
            _send(msg.sender,_target,_magnitude);
        }
    }
    
    
    function sendOrigin(address _origin,address _target,uint256 _magnitude) public returns (bool altSuccess){
        
        require(!lockedParty[_origin]&&!lockedParty[msg.sender]);
        require(_magnitude<=permitted[_origin][msg.sender]);
        
        permitted[_origin][msg.sender] -= _magnitude;
        if(_target == address(this)){
            _vend(_origin,_magnitude);
        }else
        {
            _send(_origin,_target,_magnitude);
        }
        
        return true;
    }
    
    
    
    
    
    function authorize(address _delegate,uint256 _magnitude) public returns (bool altSuccess){
        require(!lockedParty[msg.sender]);
        permitted[msg.sender][_delegate] = _magnitude;
        return true;
    }
    
    function authorizeAndCall(address _delegate,uint256 _magnitude,bytes _extraPayload)
    public returns (bool altSuccess){
        require(!lockedParty[msg.sender]);
        assetBeneficiary delegate = assetBeneficiary(_delegate);
        if(authorize(_delegate,_magnitude)){
            delegate.receiveAuthorization(msg.sender,_magnitude,this,_extraPayload);
            return true;
        }
    }
    
    
    
    function lockParty(address altTarget,bool lock)  onlyAdministrator public{
        require(altTarget!=administrator);
        lockedParty[altTarget] = lock;
        FrozenFunds(altTarget,lock);
    }
    
    function sendAdministration(address freshAdministrator) onlyAdministrator public{
        _send(administrator,freshAdministrator,holdingsOf[administrator]);
        administrator = freshAdministrator;
    }
    
    function assignPrices(uint256 freshVendRate,uint256 freshPurchaseRate) onlyAdministrator public{
        vendRate = freshVendRate;
        purchaseRate = freshPurchaseRate;
    }
    
    function assignPurchaseOpen(bool freshPurchaseOpen) onlyAdministrator public{
        require(purchaseRate>0);
        purchaseOpen = freshPurchaseOpen;
    }
    
    function assignVendOpen(bool freshVendOpen) onlyAdministrator public{
        require(vendRate>0);
        vendOpen = freshVendOpen;
    }
    
    function sendEth(uint256 quantity) onlyAdministrator public{
        msg.sender.transfer(quantity*10**uint256(18));
    }
    
    
 
    function _send(address _origin,address _target, uint256 _magnitude) internal {
        
        require(_target != 0x0);
        require(holdingsOf[_origin] >= _magnitude);
        require(holdingsOf[_target] + _magnitude >holdingsOf[_target]);
        uint256 previousHoldings = holdingsOf[_origin]+holdingsOf[_target];
        
        holdingsOf[_origin] -= _magnitude;
        holdingsOf[_target] += _magnitude;
        
        Transfer(_origin,_target,_magnitude);
        assert(holdingsOf[_origin]+holdingsOf[_target] == previousHoldings);
    }
 
    function _purchase() internal returns (uint256 quantity){
        require(purchaseOpen);
        require(purchaseRate>0);
        require(msg.value>0);
        quantity = msg.value / purchaseRate;                    
        _send(administrator,msg.sender,quantity);
        BuyToken(msg.sender,purchaseRate,quantity,msg.value);
        return quantity;                                    
    }
    
    
    function _vend(address _origin,uint256 quantity) internal returns (uint256 altRevenue){
        require(vendOpen);
        require(!lockedParty[_origin]);
        require(quantity>0);
        require(vendRate>0);
        require(_origin!=administrator);
        _send(_origin,administrator,quantity);
        altRevenue = quantity * vendRate;
        _origin.transfer(altRevenue);                     
        SellToken(_origin,vendRate,quantity,altRevenue);
        return altRevenue;                                   
    }
}
