pragma solidity ^0.4.18;






library GuardedMath {
  function scale(uint256 altA, uint256 altB) internal pure returns (uint256) {
    if (altA == 0) {
      return 0;
    }
    uint256 altC = altA * altB;
    assert(altC / altA == altB);
    return altC;
  }

  function partition(uint256 altA, uint256 altB) internal pure returns (uint256) {
    
    uint256 altC = altA / altB;
    
    return altC;
  }

  function deduct(uint256 altA, uint256 altB) internal pure returns (uint256) {
    assert(altB <= altA);
    return altA - altB;
  }

  function append(uint256 altA, uint256 altB) internal pure returns (uint256) {
    uint256 altC = altA + altB;
    assert(altC >= altA);
    return altC;
  }
}







contract ERC20Basic {
  uint256 public aggregateIssuance;
  function holdingsOf(address altWho) public view returns (uint256);
  function send(address target, uint256 magnitude) public returns (bool);
  event Transfer(address indexed origin, address indexed target, uint256 magnitude);
}






contract BasicAsset is ERC20Basic {
  using GuardedMath for uint256;

  mapping(address => uint256) holdings;

  




  function send(address _target, uint256 _magnitude) public returns (bool) {
    require(_target != address(0));
    require(_magnitude <= holdings[msg.sender]);

    
    holdings[msg.sender] = holdings[msg.sender].deduct(_magnitude);
    holdings[_target] = holdings[_target].append(_magnitude);
    Transfer(msg.sender, _target, _magnitude);
    return true;
  }

  




  function holdingsOf(address _administrator) public view returns (uint256 holdings2) {
    return holdings[_administrator];
  }

}







contract ERC20 is ERC20Basic {
  function permitted(address administrator, address delegate) public view returns (uint256);
  function sendOrigin(address origin, address target, uint256 magnitude) public returns (bool);
  function authorize(address delegate, uint256 magnitude) public returns (bool);
  event Approval(address indexed administrator, address indexed delegate, uint256 magnitude);
}










contract StandardAsset is ERC20, BasicAsset {

  mapping (address => mapping (address => uint256)) internal permitted2;


  





  function sendOrigin(address _origin, address _target, uint256 _magnitude) public returns (bool) {
    require(_target != address(0));
    require(_magnitude <= holdings[_origin]);
    require(_magnitude <= permitted2[_origin][msg.sender]);

    holdings[_origin] = holdings[_origin].deduct(_magnitude);
    holdings[_target] = holdings[_target].append(_magnitude);
    permitted2[_origin][msg.sender] = permitted2[_origin][msg.sender].deduct(_magnitude);
    Transfer(_origin, _target, _magnitude);
    return true;
  }

  









  function authorize(address _delegate, uint256 _magnitude) public returns (bool) {
    permitted2[msg.sender][_delegate] = _magnitude;
    Approval(msg.sender, _delegate, _magnitude);
    return true;
  }

  





  function permitted(address _administrator, address _delegate) public view returns (uint256) {
    return permitted2[_administrator][_delegate];
  }

  





  function increaseAuthorization(address _delegate, uint _addedMagnitude) public returns (bool) {
    permitted2[msg.sender][_delegate] = permitted2[msg.sender][_delegate].append(_addedMagnitude);
    Approval(msg.sender, _delegate, permitted2[msg.sender][_delegate]);
    return true;
  }

  function decreaseAuthorization(address _delegate, uint _subtractedMagnitude) public returns (bool) {
    uint priorMagnitude = permitted2[msg.sender][_delegate];
    if (_subtractedMagnitude > priorMagnitude) {
      permitted2[msg.sender][_delegate] = 0;
    } else {
      permitted2[msg.sender][_delegate] = priorMagnitude.deduct(_subtractedMagnitude);
    }
    Approval(msg.sender, _delegate, permitted2[msg.sender][_delegate]);
    return true;
  }

}



contract RelocationAgent {
  function relocateOrigin(address _origin, uint _magnitude) public;
}




contract AuroraAsset is StandardAsset {

  string public constant label = "SP8DE Token";
  string public constant ticker = "SPX";
  uint8 public constant precision = 18;
  address public altIco;
  
  bool public isLocked = true;  
  uint public constant altTOKEN_LIMIT = 8888888888 * (1e18);

  
  address public relocationMaster;
  address public relocationAgent;
  uint public aggregateMigrated;

  event Migrate(address indexed _origin, address indexed _target, uint _magnitude);
  
  
  function AuroraAsset(address _altIco, address _relocationMaster) public {
    require(_altIco != 0);
    altIco = _altIco;
    relocationMaster = _relocationMaster;
  }

  
  function create(address altHolder, uint magnitude) public {
    require(msg.sender == altIco);
    require(magnitude > 0);
    require(aggregateIssuance + magnitude <= altTOKEN_LIMIT);

    holdings[altHolder] += magnitude;
    aggregateIssuance += magnitude;
    Transfer(0x0, altHolder, magnitude);
  }

  
  function unlock() public {
      require(msg.sender == altIco);
      isLocked = false;
  }

  
  
  function send(address _target, uint _magnitude) public returns (bool) {
    require(_target != address(0));
    require(!isLocked);
    return super.send(_target, _magnitude);
  }

  function sendOrigin(address _origin, address _target, uint _magnitude) public returns (bool) {
    require(!isLocked);
    return super.sendOrigin(_origin, _target, _magnitude);
  }

  function authorize(address _delegate, uint _magnitude) public returns (bool) {
    require(!isLocked);
    return super.authorize(_delegate, _magnitude);
  }

  
  function relocate(uint magnitude) external {
    require(relocationAgent != 0);
    require(magnitude > 0);
    require(magnitude <= holdings[msg.sender]);

    holdings[msg.sender] -= magnitude;
    aggregateIssuance -= magnitude;
    aggregateMigrated += magnitude;
    RelocationAgent(relocationAgent).relocateOrigin(msg.sender, magnitude);
    Migrate(msg.sender, relocationAgent, magnitude);
  }

  
  function assignRelocationAgent(address _altAgent) external {
    require(relocationAgent == 0);
    require(msg.sender == relocationMaster);
    relocationAgent = _altAgent;
  }

  function assignRelocationMaster(address _altMaster) external {
    require(msg.sender == relocationMaster);
    require(_altMaster != 0);
    relocationMaster = _altMaster;
  }
}




contract MeridianIco {
  
  uint public constant altTOKENS_FOR_SALE = 3655555558 * 1e18;
  uint public constant altTOKENS_FOUNDATION = 1777777778 * 1e18;
  
  uint assetsSold = 0;
  
  
  AuroraAsset public asset;
  address public crew;
  address public altIcoAgent;
  address public relocationMaster;
  
  modifier crewOnly {require(msg.sender == crew); _;}
  modifier altIcoAgentOnly {require(msg.sender == altIcoAgent); _;}
  
  bool public isHalted = false;
  enum IcoState { Created, IcoStarted, IcoFinished }
  IcoState public altIcoState = IcoState.Created;

  event IcoStarted();
  event IcoFinished();
  event IcoPaused();
  event IcoResumed();
  event TokenBuy(address indexed altBuyer, uint256 assets, uint256 altFactor, string tx);
  event TokenBuyPresale(address indexed altBuyer, uint256 assets, uint256 altFactor, string tx);
  event TokenWin(address indexed altBuyer, uint256 assets, uint256 altJackpot);

  function MeridianIco(address _crew, address _altIcoAgent, address _relocationMaster) public {
    require(_crew != address(0) && _altIcoAgent != address(0) && _relocationMaster != address(0));  
    relocationMaster = _relocationMaster;
    crew = _crew;
    altIcoAgent = _altIcoAgent;
    asset = new AuroraAsset(this, relocationMaster);
  }

  function beginIco() external crewOnly {
    require(altIcoState == IcoState.Created);
    altIcoState = IcoState.IcoStarted;
    IcoStarted();
  }

  function altFinishIco(address altFoundation, address altOther) external crewOnly {
    require(altFoundation != address(0));
    require(altOther != address(0));

    require(altIcoState == IcoState.IcoStarted);
    altIcoState = IcoState.IcoFinished;
    
    uint256 quantityWithFoundation = GuardedMath.append(asset.aggregateIssuance(), altTOKENS_FOUNDATION);
    if (quantityWithFoundation > asset.altTOKEN_LIMIT()) {
      uint256 foundationTargetCreate = asset.altTOKEN_LIMIT() - asset.aggregateIssuance();
      if (foundationTargetCreate > 0) {
        asset.create(altFoundation, foundationTargetCreate);
      }
    } else {
        asset.create(altFoundation, altTOKENS_FOUNDATION);

        uint mintedAssets = asset.aggregateIssuance();
    
        uint altRemaining = asset.altTOKEN_LIMIT() - mintedAssets;
        if (altRemaining > 0) {
          asset.create(altOther, altRemaining);
        }
    }

    asset.unlock();
    IcoFinished();
  }

  function haltIco() external crewOnly {
    require(!isHalted);
    require(altIcoState == IcoState.IcoStarted);
    isHalted = true;
    IcoPaused();
  }

  function altResumeIco() external crewOnly {
    require(isHalted);
    require(altIcoState == IcoState.IcoStarted);
    isHalted = false;
    IcoResumed();
  }

  function convertPresaleAssets(address altBuyer, uint256 assets, uint256 altFactor, string altTxHash) external altIcoAgentOnly returns (uint) {
    require(altBuyer != address(0));
    require(assets > 0);
    require(soundState());

    uint256 assetsTargetVend = GuardedMath.append(assetsSold, assets);
    require(assetsTargetVend <= altTOKENS_FOR_SALE);
    assetsSold = assetsTargetVend;            

    asset.create(altBuyer, assets);
    TokenBuyPresale(altBuyer, assets, altFactor, altTxHash);
  }

  function creditJackpotAssets(address altBuyer, uint256 assets, uint256 altJackpot) external altIcoAgentOnly returns (uint) {
    require(altBuyer != address(0));
    require(assets > 0);
    require(soundState());

    asset.create(altBuyer, assets);
    TokenWin(altBuyer, assets, altJackpot);
  }

  function purchaseAssets(address altBuyer, uint256 assets, uint256 altFactor, string altTxHash) external altIcoAgentOnly returns (uint) {
    require(altBuyer != address(0));
    require(assets > 0);
    require(soundState());

    uint256 assetsTargetVend = GuardedMath.append(assetsSold, assets);
    require(assetsTargetVend <= altTOKENS_FOR_SALE);
    assetsSold = assetsTargetVend;            

    asset.create(altBuyer, assets);
    TokenBuy(altBuyer, assets, altFactor, altTxHash);
  }

  function soundState() internal view returns (bool) {
    return altIcoState == IcoState.IcoStarted && !isHalted;
  }
}
