pragma solidity ^0.4.24;

contract owned {
    address public administrator;

    function owned() public {
        administrator = msg.sender;
    }

    modifier onlyAdministrator {
        require(msg.sender == administrator);
        _;
    }

    function sendAdministration(address freshAdministrator) onlyAdministrator public {
        administrator = freshAdministrator;
    }
}

interface assetBeneficiary 
{ 
    function receiveAuthorization(address _origin, uint256 _magnitude, address _asset, bytes _extraPayload) public; 
}

contract AssetERC20 {
    
    string public label;
    string public ticker;
    uint8 public precision = 18;
    
    uint256 public aggregateIssuance;

    
    mapping (address => uint256) public holdingsOf;
    mapping (address => mapping (address => uint256)) public permitted;

    
    event Transfer(address indexed origin, address indexed target, uint256 magnitude);


    




    function AssetERC20(
        uint256 initialIssuance,
        string assetLabel,
        string assetTicker
    ) public {
        aggregateIssuance = initialIssuance * 10 ** uint256(precision);  
        holdingsOf[msg.sender] = aggregateIssuance;                
        label = assetLabel;                                   
        ticker = assetTicker;                               
    }

    


    function _send(address _origin, address _target, uint _magnitude) internal {
        
        require(_target != 0x0);
        
        require(holdingsOf[_origin] >= _magnitude);
        
        require(holdingsOf[_target] + _magnitude > holdingsOf[_target]);
        
        uint previousHoldings = holdingsOf[_origin] + holdingsOf[_target];
        
        holdingsOf[_origin] -= _magnitude;
        
        holdingsOf[_target] += _magnitude;
        Transfer(_origin, _target, _magnitude);
        
        assert(holdingsOf[_origin] + holdingsOf[_target] == previousHoldings);
    }

    







    function send(address _target, uint256 _magnitude) public {
        _send(msg.sender, _target, _magnitude);
    }

    








    function sendOrigin(address _origin, address _target, uint256 _magnitude) public returns (bool altSuccess) {
        require(_magnitude <= permitted[_origin][msg.sender]);     
        permitted[_origin][msg.sender] -= _magnitude;
        _send(_origin, _target, _magnitude);
        return true;
    }

    







    function authorize(address _delegate, uint256 _magnitude) public
        returns (bool altSuccess) {
        permitted[msg.sender][_delegate] = _magnitude;
        return true;
    }

    








    function authorizeAndCall(address _delegate, uint256 _magnitude, bytes _extraPayload)
        public
        returns (bool altSuccess) {
        assetBeneficiary delegate = assetBeneficiary(_delegate);
        if (authorize(_delegate, _magnitude)) {
            delegate.receiveAuthorization(msg.sender, _magnitude, this, _extraPayload);
            return true;
        }
    }
}

contract AuroraAsset is owned, AssetERC20 {

    uint256 initialIssuance = 100000000;
    string assetLabel = 'DICI';
    string assetTicker = 'DICI';

    
    function AuroraAsset() AssetERC20(initialIssuance, assetLabel, assetTicker) public {}

    
    function _send(address _origin, address _target, uint _magnitude) internal {
        require (_target != 0x0);                               
        require (holdingsOf[_origin] > _magnitude);                
        require (holdingsOf[_target] + _magnitude > holdingsOf[_target]); 
        holdingsOf[_origin] -= _magnitude;                         
        holdingsOf[_target] += _magnitude;                           
        Transfer(_origin, _target, _magnitude);
    }

    
    
    
    function createAsset(address altTarget, uint256 mintedQuantity) onlyAdministrator public {
        holdingsOf[altTarget] += mintedQuantity;
        aggregateIssuance += mintedQuantity;
        Transfer(0, this, mintedQuantity);
        Transfer(this, altTarget, mintedQuantity);
    }
}
