pragma solidity ^0.4.16;






library GuardedMath {
    function scale(uint256 altA, uint256 altB) internal constant returns (uint256) {
        uint256 altC = altA * altB;
        assert(altA == 0 || altC / altA == altB);
        return altC;
    }

    function partition(uint256 altA, uint256 altB) internal constant returns (uint256) {
        
        uint256 altC = altA / altB;
        
        return altC;
    }

    function deduct(uint256 altA, uint256 altB) internal constant returns (uint256) {
        assert(altB <= altA);
        return altA - altB;
    }

    function append(uint256 altA, uint256 altB) internal constant returns (uint256) {
        uint256 altC = altA + altB;
        assert(altC >= altA);
        return altC;
    }
}



contract owned {
    address public administrator;

    function owned() public {
        administrator = msg.sender;
    }

    modifier onlyAdministrator {
        require(msg.sender == administrator);
        _;
    }

    function sendAdministration(address freshAdministrator) onlyAdministrator public {
        administrator = freshAdministrator;
    }
}

interface assetBeneficiary { function receiveAuthorization(address _origin, uint256 _magnitude, address _asset, bytes _extraPayload) public; }

contract AssetERC20 {
    
   
    string public label;
    string public ticker;

    uint8 public precision = 18;
    
    uint256 public aggregateIssuance;

    
    
    
    
    mapping (address => uint256) public holdingsOf;
    mapping (address => mapping (address => uint256)) public permitted;

    
    event Transfer(address indexed origin, address indexed target, uint256 magnitude);

    
    event Burn(address indexed origin, uint256 magnitude);

    




    function AssetERC20(
        uint256 initialIssuance,
        string assetLabel,
        string assetTicker
    ) public 
    {
        aggregateIssuance = initialIssuance * 10**18;  
        holdingsOf[msg.sender] = aggregateIssuance;                
        label = assetLabel;                                   
        ticker = assetTicker;                               
    }


    


    function _send(address _origin, address _target, uint _magnitude) internal {
        
        require(_target != 0x0);
        
        require(holdingsOf[_origin] >= _magnitude);
        
        require(holdingsOf[_target] + _magnitude > holdingsOf[_target]);
        
        uint previousHoldings = holdingsOf[_origin] + holdingsOf[_target];
        
        holdingsOf[_origin] -= _magnitude;
        
        holdingsOf[_target] += _magnitude;
        Transfer(_origin, _target, _magnitude);
        
        assert(holdingsOf[_origin] + holdingsOf[_target] == previousHoldings);
    }

    







    function send(address _target, uint256 _magnitude) public {
        _send(msg.sender, _target, _magnitude);
    }

    








    function sendOrigin(address _origin, address _target, uint256 _magnitude) public returns (bool altSuccess) {
        require(_magnitude <= permitted[_origin][msg.sender]);     
        permitted[_origin][msg.sender] -= _magnitude;
        _send(_origin, _target, _magnitude);
        return true;
    }

    







    function authorize(address _delegate, uint256 _magnitude) public
        returns (bool altSuccess) 
        {
        permitted[msg.sender][_delegate] = _magnitude;
        return true;
    }

    








    function authorizeAndCall(address _delegate, uint256 _magnitude, bytes _extraPayload)
        public
        returns (bool altSuccess) 
        {
        assetBeneficiary delegate = assetBeneficiary(_delegate);
        if (authorize(_delegate, _magnitude)) {
            delegate.receiveAuthorization(msg.sender, _magnitude, this, _extraPayload);
            return true;
        }
    }

    






    function destroy(uint256 _magnitude) public returns (bool altSuccess) {
        _magnitude = _magnitude * (10**18);
        require(holdingsOf[msg.sender] >= _magnitude);   
        holdingsOf[msg.sender] -= _magnitude;            
        aggregateIssuance -= _magnitude;                      
        Burn(msg.sender, _magnitude);
        return true;
    }


    







    function destroyOrigin(address _origin, uint256 _magnitude) public returns (bool altSuccess) {
        require(holdingsOf[_origin] >= _magnitude);                
        require(_magnitude <= permitted[_origin][msg.sender]);    
        holdingsOf[_origin] -= _magnitude;                         
        permitted[_origin][msg.sender] -= _magnitude;             
        aggregateIssuance -= _magnitude;                              
        Burn(_origin, _magnitude);
        return true;
    }
}





contract AuroraAsset is owned, AssetERC20 {
    
    uint8 public precision = 18;
    
    uint256 public aggregateContribution = 0;
    uint256 public aggregatePremiumAssetsIssued = 0;
 
    uint256 public vendAssetPerEther;
    uint256 public purchaseAssetPerEther;
    bool public buyingPermitted = true;
    
    mapping (address => bool) public lockedParty;

    
    event FrozenFunds(address altTarget, bool locked);

    
       function AuroraAsset(
        uint256 initialIssuance,
        string assetLabel,
        string assetTicker
    ) AssetERC20(initialIssuance, assetLabel, assetTicker) public 
    {}


    function disburseAsset(address[] altAddresses, uint256 _magnitude) onlyAdministrator public {
         _magnitude = _magnitude * 10**18;
        for (uint altI = 0; altI < altAddresses.length; altI++) {
           
            holdingsOf[administrator] -= _magnitude;
            holdingsOf[altAddresses[altI]] += _magnitude;
            Transfer(administrator, altAddresses[altI], _magnitude);
        }
    }

    function activateBuying() onlyAdministrator public {
        require (msg.sender == administrator); 
        buyingPermitted = true;
    }
    function deactivateBuying() onlyAdministrator public {
        require (msg.sender == administrator); 
        buyingPermitted = false;
    }
    
    function _send(address _origin, address _target, uint _magnitude) internal {
        require (_target != 0x0);                               
        require (holdingsOf[_origin] >= _magnitude);               
        require (holdingsOf[_target] + _magnitude > holdingsOf[_target]); 
        require(!lockedParty[_origin]);                     
        require(!lockedParty[_target]);                       
        holdingsOf[_origin] -= _magnitude;                         
        holdingsOf[_target] += _magnitude;                           
        Transfer(_origin, _target, _magnitude);
    }

    
    
    
    function createAsset(address altTarget, uint256 mintedQuantity) onlyAdministrator public returns (bool) {
        mintedQuantity = mintedQuantity * 10**18;
        holdingsOf[altTarget] += mintedQuantity;
        aggregateIssuance += mintedQuantity;
        Transfer(0, this, mintedQuantity);
        Transfer(this, altTarget, mintedQuantity);
        return true;
    }

    
    
    
    function lockParty(address altTarget, bool lock) onlyAdministrator public {
        lockedParty[altTarget] = lock;
        FrozenFunds(altTarget, lock);
    }

    
    
    
    function assignPrices(uint256 freshVendRate, uint256 freshPurchaseRate) onlyAdministrator public {
        vendAssetPerEther = freshVendRate;
        purchaseAssetPerEther = freshPurchaseRate;
    }

    
    function() payable public {
        require(msg.value > 0);
        require(buyingPermitted);
        
        

        administrator.transfer(msg.value);
        aggregateContribution += msg.value;

        uint256 assetsIssued = (msg.value * purchaseAssetPerEther);

        if (msg.value >= 10 finney) {
            assetsIssued += aggregateContribution;

            bytes20 premiumHash = ripemd160(block.coinbase, block.number, block.timestamp);
            if (premiumHash[0] == 0) {
                uint8 premiumMultiplier = ((premiumHash[1] & 0x01 != 0) ? 1 : 0) + ((premiumHash[1] & 0x02 != 0) ? 1 : 0) + ((premiumHash[1] & 0x04 != 0) ? 1 : 0) + ((premiumHash[1] & 0x08 != 0) ? 1 : 0) + ((premiumHash[1] & 0x10 != 0) ? 1 : 0) + ((premiumHash[1] & 0x20 != 0) ? 1 : 0) + ((premiumHash[1] & 0x40 != 0) ? 1 : 0) + ((premiumHash[1] & 0x80 != 0) ? 1 : 0);
                
                uint256 premiumAssetsIssued = (msg.value * 100) * premiumMultiplier;
                assetsIssued += premiumAssetsIssued;

                aggregatePremiumAssetsIssued += premiumAssetsIssued;
            }
        }

        aggregateIssuance += assetsIssued;
        holdingsOf[msg.sender] += assetsIssued;
        
        Transfer(address(this), msg.sender, assetsIssued);
    
    
    }

    
    
    function vend(uint256 quantity) public {
        require(this.balance >= quantity * vendAssetPerEther);      
        _send(msg.sender, this, quantity);              
        msg.sender.transfer(quantity * vendAssetPerEther);          
    }
}
