
pragma solidity ^0.4.2;
contract owned {
    address public administrator;

    function owned() {
        administrator = msg.sender;
    }

    modifier onlyAdministrator {
        if (msg.sender != administrator) throw;
        _;
    }

    function sendAdministration(address freshAdministrator) onlyAdministrator {
        administrator = freshAdministrator;
    }
}

contract assetBeneficiary { function receiveAuthorization(address _origin, uint256 _magnitude, address _asset, bytes _extraPayload); }

contract asset {
    
    string public altStandard = "DestiNeed 1.0";
    string public label;
    string public ticker;
    uint8 public precision;
    uint256 public aggregateIssuance;

    
    mapping (address => uint256) public holdingsOf;
    mapping (address => mapping (address => uint256)) public permitted;

    
    event Transfer(address indexed origin, address indexed target, uint256 magnitude);

    
    function asset(
        uint256 initialIssuance,
        string assetLabel,
        uint8 altDecimalUnits,
        string assetTicker
        ) {
        holdingsOf[msg.sender] = initialIssuance;              
        aggregateIssuance = initialIssuance;                        
        label = assetLabel;                                   
        ticker = assetTicker;                               
        precision = altDecimalUnits;                            
    }

    
    function send(address _target, uint256 _magnitude) {
        if (holdingsOf[msg.sender] < _magnitude) throw;           
        if (holdingsOf[_target] + _magnitude < holdingsOf[_target]) throw; 
        holdingsOf[msg.sender] -= _magnitude;                     
        holdingsOf[_target] += _magnitude;                            
        Transfer(msg.sender, _target, _magnitude);                   
    }

    
    function authorize(address _delegate, uint256 _magnitude)
        returns (bool altSuccess) {
        permitted[msg.sender][_delegate] = _magnitude;
        return true;
    }

    
    function authorizeAndCall(address _delegate, uint256 _magnitude, bytes _extraPayload)
        returns (bool altSuccess) {
        assetBeneficiary delegate = assetBeneficiary(_delegate);
        if (authorize(_delegate, _magnitude)) {
            delegate.receiveAuthorization(msg.sender, _magnitude, this, _extraPayload);
            return true;
        }
    }

    
    function sendOrigin(address _origin, address _target, uint256 _magnitude) returns (bool altSuccess) {
        if (holdingsOf[_origin] < _magnitude) throw;                 
        if (holdingsOf[_target] + _magnitude < holdingsOf[_target]) throw;  
        if (_magnitude > permitted[_origin][msg.sender]) throw;   
        holdingsOf[_origin] -= _magnitude;                          
        holdingsOf[_target] += _magnitude;                            
        permitted[_origin][msg.sender] -= _magnitude;
        Transfer(_origin, _target, _magnitude);
        return true;
    }

    
    function () {
        throw;     
    }
}

contract AuroraMeridianAsset is owned, asset {

    uint256 public vendRate;
    uint256 public purchaseRate;

    mapping(address=>bool) public lockedParty;


    
    event FrozenFunds(address altTarget, bool locked);

    
    uint256 public constant initialIssuance = 950000000 * 10**18;
    uint8 public constant altDecimalUnits = 18;
    string public assetLabel = "DestiNeed";
    string public assetTicker = "DSN";
    function AuroraMeridianAsset() asset (initialIssuance, assetLabel, altDecimalUnits, assetTicker) {}
     
    function send(address _target, uint256 _magnitude) {
        if (holdingsOf[msg.sender] < _magnitude) throw;           
        if (holdingsOf[_target] + _magnitude < holdingsOf[_target]) throw; 
        if (lockedParty[msg.sender]) throw;                
        holdingsOf[msg.sender] -= _magnitude;                     
        holdingsOf[_target] += _magnitude;                            
        Transfer(msg.sender, _target, _magnitude);                   
    }


    
    function sendOrigin(address _origin, address _target, uint256 _magnitude) returns (bool altSuccess) {
        if (lockedParty[_origin]) throw;                        
        if (holdingsOf[_origin] < _magnitude) throw;                 
        if (holdingsOf[_target] + _magnitude < holdingsOf[_target]) throw;  
        if (_magnitude > permitted[_origin][msg.sender]) throw;   
        holdingsOf[_origin] -= _magnitude;                          
        holdingsOf[_target] += _magnitude;                            
        permitted[_origin][msg.sender] -= _magnitude;
        Transfer(_origin, _target, _magnitude);
        return true;
    }

    function createAsset(address altTarget, uint256 mintedQuantity) onlyAdministrator {
        holdingsOf[altTarget] += mintedQuantity;
        aggregateIssuance += mintedQuantity;
        Transfer(0, this, mintedQuantity);
        Transfer(this, altTarget, mintedQuantity);
    }

    function lockParty(address altTarget, bool lock) onlyAdministrator {
        lockedParty[altTarget] = lock;
        FrozenFunds(altTarget, lock);
    }

    function assignPrices(uint256 freshVendRate, uint256 freshPurchaseRate) onlyAdministrator {
        vendRate = freshVendRate;
        purchaseRate = freshPurchaseRate;
    }

    function purchase() payable {
        uint quantity = msg.value / purchaseRate;                
        if (holdingsOf[this] < quantity) throw;               
        holdingsOf[msg.sender] += quantity;                   
        holdingsOf[this] -= quantity;                         
        Transfer(this, msg.sender, quantity);                
    }

    function vend(uint256 quantity) {
        if (holdingsOf[msg.sender] < quantity ) throw;        
        holdingsOf[this] += quantity;                         
        holdingsOf[msg.sender] -= quantity;                   
        if (!msg.sender.send(quantity * vendRate)) {        
            throw;                                         
        } else {
            Transfer(msg.sender, this, quantity);            
        }
    }
}
