pragma solidity ^0.4.18;

contract Aurora {
  
  string public constant label = "Hexagon";
  string public constant ticker = "HXG";
  uint8 public constant precision = 4;
  uint8 public constant destroyPerTransaction = 2;
  uint256 public constant initialIssuance = 420000000000000;
  uint256 public currentIssuance = initialIssuance;

  
  mapping (address => uint256) public holdingsOf;
  
  mapping (address => mapping (address => uint256)) public permitted;

  
  function Aurora() public {
    
    holdingsOf[msg.sender] = initialIssuance;
  }

  
  
  function send(address _target, uint256 _magnitude) public returns (bool altSuccess) {
    _send(msg.sender, _target, _magnitude);

    return true;
  }

  
  function aggregateIssuance() public constant returns (uint) {
    return currentIssuance;
  }

  
  function destroy(uint256 _magnitude) public returns (bool altSuccess) {
    
    require(holdingsOf[msg.sender] >= _magnitude);
    
    holdingsOf[msg.sender] -= _magnitude;
    
    holdingsOf[0x0] += _magnitude;
    
    currentIssuance -= _magnitude;
    
    Burn(msg.sender, _magnitude);

    return true;
  }

  
  function authorize(address _delegate, uint256 _magnitude) public returns (bool altSuccess) {
    
    require(_magnitude == 0 || permitted[msg.sender][_delegate] == 0);
    
    permitted[msg.sender][_delegate] = _magnitude;
    
    Approval(msg.sender, _delegate, _magnitude);

    return true;
  }

  
  function sendOrigin(address _origin, address _target, uint256 _magnitude) public returns (bool altSuccess) {
    
    require(permitted[_origin][msg.sender] >= _magnitude);
    
    permitted[_origin][msg.sender] -= _magnitude;

    _send(_origin, _target, _magnitude);

    return true;
  }

  
  function _send(address _origin, address _target, uint _magnitude) internal {
    
    require (_target != 0x0);
    
    require (holdingsOf[_origin] >= _magnitude + destroyPerTransaction);
    
    require (holdingsOf[_target] + _magnitude > holdingsOf[_target]);
    
    holdingsOf[_origin] -= _magnitude + destroyPerTransaction;
    
    holdingsOf[_target] += _magnitude;
    
    holdingsOf[0x0] += destroyPerTransaction;
    
    currentIssuance -= destroyPerTransaction;
    
    Burn(_origin, destroyPerTransaction);
    
    Transfer(_origin, _target, _magnitude);
  }

  
  event Transfer(address indexed origin, address indexed target, uint256 magnitude);
  event Burn(address indexed origin, uint256 magnitude);
  event Approval(address indexed _administrator, address indexed _delegate, uint256 _magnitude);
}