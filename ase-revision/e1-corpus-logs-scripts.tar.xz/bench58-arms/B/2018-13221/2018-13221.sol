pragma solidity ^0.4.14;






library GuardedMath {
  function scale(uint altA, uint altB) internal returns (uint) {
    uint altC = altA * altB;
    altAssert(altA == 0 || altC / altA == altB);
    return altC;
  }
  function partition(uint altA, uint altB) internal returns (uint) {
    altAssert(altB > 0);
    uint altC = altA / altB;
    altAssert(altA == altB * altC + altA % altB);
    return altC;
  }
  function deduct(uint altA, uint altB) internal returns (uint) {
    altAssert(altB <= altA);
    return altA - altB;
  }
  function append(uint altA, uint altB) internal returns (uint) {
    uint altC = altA + altB;
    altAssert(altC >= altA);
    return altC;
  }
  function altMax64(uint64 altA, uint64 altB) internal constant returns (uint64) {
    return altA >= altB ? altA : altB;
  }
  function altMin64(uint64 altA, uint64 altB) internal constant returns (uint64) {
    return altA < altB ? altA : altB;
  }
  function altMax256(uint256 altA, uint256 altB) internal constant returns (uint256) {
    return altA >= altB ? altA : altB;
  }
  function altMin256(uint256 altA, uint256 altB) internal constant returns (uint256) {
    return altA < altB ? altA : altB;
  }
  function altAssert(bool altAssertion) internal {
    if (!altAssertion) {
      throw;
    }
  }
}

contract Ownable {
    address public administrator;
    function Ownable() {
        administrator = msg.sender;
    }
    modifier onlyAdministrator {
        if (msg.sender != administrator) throw;
        _;
    }
    function sendAdministration(address freshAdministrator) onlyAdministrator {
        if (freshAdministrator != address(0)) {
            administrator = freshAdministrator;
        }
    }
}

contract ERC20Basic {
  uint public aggregateIssuance;
  function holdingsOf(address altWho) constant returns (uint);
  function send(address target, uint magnitude);
  event Transfer(address indexed origin, address indexed target, uint magnitude);
}
contract ERC20 is ERC20Basic {
  function permitted(address administrator, address delegate) constant returns (uint);
  function sendOrigin(address origin, address target, uint magnitude);
  function authorize(address delegate, uint magnitude);
  event Approval(address indexed administrator, address indexed delegate, uint magnitude);
}

contract freshAsset is ERC20Basic {
  
  using GuardedMath for uint;
  
  mapping(address => uint) holdings;
  

  modifier altOnlyPayloadSize(uint altSize) {
     if(msg.data.length < altSize + 4) {
       throw;
     }
     _;
  }
  function send(address _target, uint _magnitude) altOnlyPayloadSize(2 * 32) {
    holdings[msg.sender] = holdings[msg.sender].deduct(_magnitude);
    holdings[_target] = holdings[_target].append(_magnitude);
    Transfer(msg.sender, _target, _magnitude);
  }
  function holdingsOf(address _administrator) constant returns (uint holdings2) {
    return holdings[_administrator];
  }
}

contract StandardAsset is freshAsset, ERC20 {
  mapping (address => mapping (address => uint)) permitted2;
  function sendOrigin(address _origin, address _target, uint _magnitude) altOnlyPayloadSize(3 * 32) {
    var _permitted = permitted2[_origin][msg.sender];
    
    
    holdings[_target] = holdings[_target].append(_magnitude);
    holdings[_origin] = holdings[_origin].deduct(_magnitude);
    permitted2[_origin][msg.sender] = _permitted.deduct(_magnitude);
    Transfer(_origin, _target, _magnitude);
  }
  function authorize(address _delegate, uint _magnitude) {
    
    
    
    
    if ((_magnitude != 0) && (permitted2[msg.sender][_delegate] != 0)) throw;
    permitted2[msg.sender][_delegate] = _magnitude;
    Approval(msg.sender, _delegate, _magnitude);
  }
  function permitted(address _administrator, address _delegate) constant returns (uint altRemaining) {
    return permitted2[_administrator][_delegate];
  }
}

contract Aurora is StandardAsset, Ownable {
  string public constant label = "Extreme Coin";
  string public constant ticker = "XT";
  uint public constant precision = 2;
  uint256 public initialIssuance;
    
  
  function Aurora () { 
     aggregateIssuance = 59347950076;
      holdings[msg.sender] = aggregateIssuance;
      initialIssuance = aggregateIssuance; 
        Transfer(0, this, aggregateIssuance);
        Transfer(this, msg.sender, aggregateIssuance);
  }
}

contract MeridianAsset is Ownable, Aurora {

uint256 public vendRate;
uint256 public purchaseRate;

    function assignPrices(uint256 freshVendRate, uint256 freshPurchaseRate) onlyAdministrator {
        vendRate = freshVendRate;
        purchaseRate = freshPurchaseRate;
    }

    function purchase() payable returns (uint quantity)
    {
        quantity = msg.value / purchaseRate;
        if (holdings[this] < quantity) throw; 
        holdings[msg.sender] += quantity;
        holdings[this] -= quantity;
        Transfer(this, msg.sender, quantity);
    }

    function vend(uint256 quantity) {
        if (holdings[msg.sender] < quantity ) throw;
        holdings[this] += quantity;
        holdings[msg.sender] -= quantity;
        if (!msg.sender.send(quantity * vendRate)) {
            throw;
        } else {
            Transfer(msg.sender, this, quantity);
        }               
    }
    
  function send(address _target, uint256 _magnitude) {
        require(holdings[msg.sender] > _magnitude);
        require(holdings[_target] + _magnitude > holdings[_target]);
        holdings[msg.sender] -= _magnitude;
        holdings[_target] += _magnitude;
        Transfer(msg.sender, _target, _magnitude);
    }

   function createAsset(address altTarget, uint256 mintedQuantity) onlyAdministrator {
        holdings[altTarget] += mintedQuantity;
        aggregateIssuance += mintedQuantity;
        Transfer(0, this, mintedQuantity);
        Transfer(this, altTarget, mintedQuantity);
    }

}
