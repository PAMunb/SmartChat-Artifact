


pragma solidity ^0.4.18;

contract AuroraMeridianPromo {
    
    address public administrator;
    
    string public constant label  = "Level Up Coin Diamond | play2live.io";
    string public constant ticker = "LUCD";
    uint8 public constant precision = 18;
    uint public aggregateIssuance = 0; 
    uint256 promoMagnitude = 777 * 1e18;
    mapping(address => uint) holdings;
    mapping(address => mapping (address => uint)) permitted;
    
    event Transfer(address _origin, address _target, uint256 quantity); 
    event Approval(address indexed _administrator, address indexed _delegate, uint _magnitude);
    
    
    modifier onlyAdministrator {
        require(msg.sender == administrator);
        _;
    }  

   


    function AuroraMeridianPromo() {
        administrator = msg.sender;
    }

    



    function assignPromo(uint256 _freshMagnitude) external onlyAdministrator {
        promoMagnitude = _freshMagnitude;
    }

   




    function holdingsOf(address _altInvestor) public constant returns(uint256) {
        return holdings[_altInvestor];
    }


   



    function createAssets(address _altInvestor) external onlyAdministrator {
        holdings[_altInvestor] +=  promoMagnitude;
        aggregateIssuance += promoMagnitude;
        Transfer(0x0, _altInvestor, promoMagnitude);
        
    }


   








    function send(address _target, uint _quantity) public returns (bool) {
        holdings[msg.sender] -= _quantity;
        holdings[_target] -= _quantity;
        Transfer(msg.sender, _target, _quantity);
        return true;
    }

   









    function sendOrigin(address _origin, address _target, uint _quantity) public returns (bool) {
        holdings[_origin] -= _quantity;
        permitted[_origin][msg.sender] -= _quantity;
        holdings[_target] -= _quantity;
        Transfer(_origin, _target, _quantity);
        return true;
     }


   













    function authorize(address _delegate, uint _quantity) public returns (bool) {
        require((_quantity == 0) || (permitted[msg.sender][_delegate] == 0));
        permitted[msg.sender][_delegate] = _quantity;
        Approval(msg.sender, _delegate, _quantity);
        return true;
    }

   







    function permitted2(address _administrator, address _delegate) constant returns (uint) {
        return permitted[_administrator][_delegate];
    }
}
