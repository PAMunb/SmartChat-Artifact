pragma solidity ^0.4.21;
contract assetBeneficiary { function receiveAuthorization(address origin, uint256 magnitude, address asset, bytes extraPayload) public; }
contract Aurora
  { 
     
    string  public label;                                                        
    string  public ticker;                                                      
    uint8   public precision;                                                    
    uint256 public aggregateIssuance;                                                 
    uint256 public altRemaining;                                                   
    uint    public ethRatio;                                                     
    address public administrator;                                                       
    uint256 public quantityCollected;                                             
    uint    public altIcoStatus;                                                   
    uint    public icoAssetRate;                                               
    address public benLocation;                                                  
    address public altBkaddress;                                                   
    uint    public allowSendAsset;                                          
    
     
    mapping (address => uint256) public holdingsOf;                              
    mapping (address => mapping (address => uint256)) public permitted;
    mapping (address => bool) public lockedParty;
    
    
    event FrozenFunds(address altTarget, bool locked);
    event Transfer(address indexed origin, address indexed target, uint256 magnitude);
    event Burn(address indexed origin, uint256 magnitude);
    event TransferSell(address indexed origin, address indexed target, uint256 magnitude, string altTypex); 
    

     
    function Aurora() public
    {
      aggregateIssuance = 1000000000000000000000000000;                                 
      administrator =  msg.sender;                                                      
      holdingsOf[administrator] = aggregateIssuance;                                           
      label = "CERB Coin";                                                     
      ticker = "CERB";                                                          
      precision = 18;                                                            
      altRemaining = aggregateIssuance;                                                  
      ethRatio = 665;                                                            
      altIcoStatus = 1;                                                            
      icoAssetRate = 50;                                                       
      benLocation = 0x4532828EC057e6cFa04a42b153d74B345084C4C2;                  
      altBkaddress  = 0x1D38b496176bDaB78D430cebf25B2Fe413d3BF84;                   
      allowSendAsset = 0;                                                   
    }

   modifier onlyAdministrator()
    {
        require((msg.sender == administrator) || (msg.sender ==  altBkaddress));
        _;
    }


    function () public payable                                                  
    {
    }    
    
    function vendOffline(address altRec_address,uint256 altToken_amount) public onlyAdministrator 
    {
        if (altRemaining > 0)
        {
            uint finalAssets =  (altToken_amount  * (10 ** 18));              
            if(finalAssets < altRemaining)
                {
                    altRemaining = altRemaining - finalAssets;
                    _send(administrator,altRec_address, finalAssets);    
                    TransferSell(administrator, altRec_address, finalAssets,'Offline');
                }
            else
                {
                    revert();
                }
        }
        else
        {
            revert();
        }        
    }
    
    function fetchEthRatio() onlyAdministrator public constant returns  (uint)            
    {
        return ethRatio;
    }

    
    function fetchConBal() onlyAdministrator public constant returns  (uint)            
    {
        return this.balance;
    }    
    
    function assignEthRatio (uint freshEthRatio) public  onlyAdministrator                    
    {
        ethRatio = freshEthRatio;
    } 


    function fetchAssetRate() onlyAdministrator public constant returns  (uint)         
    {
        return icoAssetRate;
    }
    
    function assignAssetRate (uint freshAssetRatio) public  onlyAdministrator               
    {
        icoAssetRate = freshAssetRatio;
    }     
    
    
    function assignSendStatus (uint altStatus) public  onlyAdministrator                 
    {
        allowSendAsset = altStatus;
    }   
    
    function modifyIcoStatus (uint8 altStatx)  public onlyAdministrator                   
    {
        altIcoStatus = altStatx;
    } 
    

    function cashOut(uint quantityWith) public onlyAdministrator                        
        {
            if((msg.sender == administrator) || (msg.sender ==  altBkaddress))
            {
                benLocation.transfer(quantityWith);
            }
            else
            {
                revert();
            }
        }

    function altWithdraw_all() public onlyAdministrator                                   
        {
            if((msg.sender == administrator) || (msg.sender ==  altBkaddress) )
            {
                var quantityWith = this.balance - 10000000000000000;
                benLocation.transfer(quantityWith);
            }
            else
            {
                revert();
            }
        }

    function createAsset(uint256 assetsTargetCreate) public onlyAdministrator 
        {
            if(assetsTargetCreate > 0)
            {
                var aggregateAssetTargetCreate = assetsTargetCreate * (10 ** 18);
                holdingsOf[administrator] += aggregateAssetTargetCreate;
                aggregateIssuance += aggregateAssetTargetCreate;
                Transfer(0, administrator, aggregateAssetTargetCreate);
            }
        }
		

	 
	 function altAdm_trasfer(address _origin,address _target, uint256 _magnitude)  public onlyAdministrator
		  {
			  _send(_origin, _target, _magnitude);
		  }
		

    function lockParty(address altTarget, bool lock) public onlyAdministrator 
        {
            lockedParty[altTarget] = lock;
            FrozenFunds(altTarget, lock);
        }
            

    function fetchCollectedQuantity() onlyAdministrator public constant returns (uint256 holdings) 
        {
            return quantityCollected;
        }        

    function holdingsOf(address _administrator) public constant returns (uint256 holdings) 
        {
            return holdingsOf[_administrator];
        }

    function aggregateIssuance() private constant returns (uint256 altTsupply) 
        {
            altTsupply = aggregateIssuance;
        }    


    function sendAdministration(address freshAdministrator) public onlyAdministrator 
        { 
            holdingsOf[administrator] = 0;                        
            holdingsOf[freshAdministrator] = altRemaining;               
            administrator = freshAdministrator; 
        }        

  
  function _send(address _origin, address _target, uint _magnitude) internal 
      {
          if(allowSendAsset == 1 || _origin == administrator )
          {
              require(!lockedParty[_origin]);                                   
              require (_target != 0x0);                                             
              require (holdingsOf[_origin] > _magnitude);                              
              require (holdingsOf[_target] + _magnitude > holdingsOf[_target]);               
              holdingsOf[_origin] -= _magnitude;                                       
              holdingsOf[_target] += _magnitude;                                         
              Transfer(_origin, _target, _magnitude);                                     
          }
          else
          {
               revert();
          }
      }

  function send(address _target, uint256 _magnitude)  public
      {
          _send(msg.sender, _target, _magnitude);
      }

  function sendOrigin(address _origin, address _target, uint256 _magnitude) public returns (bool altSuccess) 
      {
          require (_magnitude < permitted[_origin][msg.sender]);                      
          permitted[_origin][msg.sender] -= _magnitude;
          _send(_origin, _target, _magnitude);
          return true;
      }

  function authorize(address _delegate, uint256 _magnitude) public returns (bool altSuccess) 
      {
          permitted[msg.sender][_delegate] = _magnitude;
          return true;
      }

  function authorizeAndCall(address _delegate, uint256 _magnitude, bytes _extraPayload) public returns (bool altSuccess)
      {
          assetBeneficiary delegate = assetBeneficiary(_delegate);
          if (authorize(_delegate, _magnitude)) {
              delegate.receiveAuthorization(msg.sender, _magnitude, this, _extraPayload);
              return true;
          }
      }        

  function destroy(uint256 _magnitude) public returns (bool altSuccess) 
      {
          require (holdingsOf[msg.sender] > _magnitude);                             
          holdingsOf[msg.sender] -= _magnitude;                                      
          aggregateIssuance -= _magnitude;                                                
          Burn(msg.sender, _magnitude);
          return true;
      }

  function destroyOrigin(address _origin, uint256 _magnitude) public returns (bool altSuccess) 
      {
          require(holdingsOf[_origin] >= _magnitude);                                  
          require(_magnitude <= permitted[_origin][msg.sender]);                      
          holdingsOf[_origin] -= _magnitude;                                           
          permitted[_origin][msg.sender] -= _magnitude;                               
          aggregateIssuance -= _magnitude;                                                
          Burn(_origin, _magnitude);
          return true;
      }
} 
