#!/bin/bash
# Wait for batch 1 (GPT seeds) to finish, then start batch 2 (Llama seeds + Smartian control),
# so the machine does not sit idle between them.
cd ~/e1
while pgrep -u "$(id -un)" -f "run-campaigns.py --arms" > /dev/null; do sleep 120; done
echo "batch 1 finished at $(date); starting batch 2"
exec ./run-campaigns.py --arms bench58-arms --seeds seeds --out /tmp/rba2-e1/campaigns \
  --models Llama3.3-70B,smartian-dfa --cores 0-31 --mems 0
